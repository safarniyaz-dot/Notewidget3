package com.example.notewidget

import java.util.Calendar

/**
 * اگر در متن یادداشت صوتی کلمه‌ی «آلارم» و بعد یا قبل از آن ساعتی گفته شده باشد،
 * زمان آلارم را برمی‌گرداند. مثال‌ها:
 * «آلارم ساعت هشت و نیم صبح»، «آلارم ۸:۳۰ فردا»، «آلارم ده دقیقه دیگر»،
 * «ساعت پنج عصر آلارم بگذار»، «آلارم ربع به هشت».
 */
object VoiceAlarm {
    private val keywords = setOf("الارم", "alarm")
    private val units = mapOf(
        "صفر" to 0, "یک" to 1, "دو" to 2, "سه" to 3, "چهار" to 4, "پنج" to 5,
        "شش" to 6, "شیش" to 6, "هفت" to 7, "هشت" to 8, "نه" to 9
    )
    private val teens = mapOf(
        "ده" to 10, "یازده" to 11, "دوازده" to 12, "سیزده" to 13, "چهارده" to 14,
        "پانزده" to 15, "شانزده" to 16, "هفده" to 17, "هجده" to 18, "نوزده" to 19
    )
    private val tens = mapOf("بیست" to 20, "سی" to 30, "چهل" to 40, "پنجاه" to 50)
    private val hmRegex = Regex("^(\\d{1,2}):(\\d{2})$")

    private class Num(val value: Int, val next: Int, val hm: Int = -1)
    private class Parsed(val h: Int, val m: Int, val rel: Int = -1)

    private fun normalize(s: String): List<String> {
        val sb = StringBuilder()
        for (c0 in s) {
            if (c0 in 'ً'..'ٟ') continue            // اعراب
            val c = when (c0) {
                'ي' -> 'ی'
                'ك' -> 'ک'
                'آ', 'أ', 'إ' -> 'ا'
                'ة' -> 'ه'
                in '۰'..'۹' -> '0' + (c0 - '۰')
                in '٠'..'٩' -> '0' + (c0 - '٠')
                else -> c0
            }
            if (c.isLetterOrDigit() || c == ':') sb.append(c.lowercaseChar()) else sb.append(' ')
        }
        return sb.toString().split(' ').filter { it.isNotEmpty() }
    }

    private fun num(t: List<String>, i: Int): Num? {
        if (i < 0 || i >= t.size) return null
        val w = t[i]
        hmRegex.matchEntire(w)?.let { return Num(it.groupValues[1].toInt(), i + 1, it.groupValues[2].toInt()) }
        if (w.length <= 2 && w.all { it.isDigit() }) return Num(w.toInt(), i + 1)
        units[w]?.let { return Num(it, i + 1) }
        teens[w]?.let { return Num(it, i + 1) }
        tens[w]?.let { base ->
            if (i + 2 < t.size && t[i + 1] == "و") {
                val u = units[t[i + 2]]
                if (u != null && u > 0) return Num(base + u, i + 3)
            }
            return Num(base, i + 1)
        }
        return null
    }

    /** دقیقه‌ی بعد از ساعت: «و نیم»، «و ربع»، «و سی دقیقه». */
    private fun minutes(t: List<String>, j: Int): Int {
        if (j < t.size && t[j] == "و" && j + 1 < t.size) {
            val x = t[j + 1]
            if (x == "نیم" || x == "نیمه") return 30
            if (x == "ربع") return 15
            val m = num(t, j + 1)
            if (m != null && m.hm < 0 && m.value in 0..59) return m.value
        } else if (j < t.size && t[j] == "نیم") {
            return 30
        } else if (j < t.size && t[j].length == 2 && t[j].all { it.isDigit() } && t[j].toInt() in 0..59) {
            return t[j].toInt()
        }
        return 0
    }

    private fun minus(h: Int, d: Int): Parsed {
        val tot = ((h * 60 - d) % 1440 + 1440) % 1440
        return Parsed(tot / 60, tot % 60)
    }

    private fun scan(t: List<String>, needSaat: Boolean): Parsed? {
        // «۱۰ دقیقه دیگر» / «۲ ساعت بعد»
        for (i in t.indices) {
            val a = num(t, i) ?: continue
            val u = t.getOrNull(a.next)
            val w = t.getOrNull(a.next + 1)
            if ((u == "دقیقه" || u == "ساعت") && (w == "دیگه" || w == "دیگر" || w == "بعد")) {
                return Parsed(0, 0, if (u == "دقیقه") a.value else a.value * 60)
            }
        }
        val saat = t.indexOf("ساعت")
        if (needSaat && saat < 0) return null
        val start = if (saat >= 0) saat + 1 else 0
        for (i in start until t.size) {
            if (t[i] == "ربع" && t.getOrNull(i + 1) == "به") {
                val h = num(t, i + 2)
                if (h != null && h.value in 1..24) return minus(h.value, 15)
            }
            val a = num(t, i) ?: continue
            if (a.hm >= 0) {
                if (a.value in 0..23 && a.hm in 0..59) return Parsed(a.value, a.hm)
                continue
            }
            if (t.getOrNull(a.next) == "دقیقه" && t.getOrNull(a.next + 1) == "به") {
                val h = num(t, a.next + 2)
                if (h != null && h.value in 1..24 && a.value in 1..59) return minus(h.value, a.value)
            }
            if (a.value !in 0..24) continue
            return Parsed(a.value % 24, minutes(t, a.next))
        }
        return null
    }

    /** زمان آلارم (میلی‌ثانیه) یا null اگر در متن آلارمی نبود. */
    fun parse(text: String, now: Long): Long? {
        val t = normalize(text)
        val k = t.indexOfFirst { it in keywords }
        if (k < 0) return null

        val after = t.subList(k + 1, minOf(t.size, k + 13))
        val before = t.subList(maxOf(0, k - 8), k)
        val pr: Parsed = scan(after, false) ?: scan(before, true) ?: return null
        if (pr.rel >= 0) return now + pr.rel * 60_000L

        val near = t.subList(maxOf(0, k - 8), minOf(t.size, k + 15))
        val pm = near.contains("عصر") || near.contains("بعدازظهر") ||
                near.indices.any { near[it] == "بعد" && near.getOrNull(it + 1) == "از" && near.getOrNull(it + 2) == "ظهر" }
        val noon = !pm && near.contains("ظهر")
        val night = near.contains("شب") || near.contains("امشب")
        val am = near.contains("صبح") || near.contains("بامداد")
        val tomorrow = near.contains("فردا")
        val dayAfter = tomorrow && (near.contains("پس") || near.contains("پسفردا"))
        val dayOff = if (dayAfter) 2 else if (tomorrow) 1 else 0

        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        fun at(h: Int): Long {
            val c = cal.clone() as Calendar
            c.add(Calendar.DAY_OF_MONTH, dayOff)
            c.set(Calendar.HOUR_OF_DAY, h)
            c.set(Calendar.MINUTE, pr.m)
            return c.timeInMillis
        }

        val h = pr.h
        val result: Long
        if (h > 12 || h == 0) {
            result = at(h)
        } else if (pm) {
            result = at(if (h < 12) h + 12 else 12)
        } else if (noon) {
            result = at(if (h in 1..5) h + 12 else h)
        } else if (night) {
            result = at(if (h == 12) 0 else if (h >= 6) h + 12 else h)
        } else if (am) {
            result = at(if (h == 12) 0 else h)
        } else if (dayOff > 0) {
            result = at(h)                       // «فردا ساعت ۸» ← صبح
        } else {
            // بدون مشخص بودن صبح/عصر: نزدیک‌ترین زمان آینده
            val a = at(h % 12)
            val b = at(h % 12 + 12)
            result = listOf(a, b).filter { it > now }.minOrNull() ?: (a + 24 * 3600_000L)
            return result
        }
        return if (result <= now && dayOff == 0) result + 24 * 3600_000L else result
    }
}
