package com.example.notewidget

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONObject
import org.vosk.Recognizer
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.Executors

/** تبدیل فایل WAV (۱۶ کیلوهرتز، مونو) به متن، در پس‌زمینه و کاملاً آفلاین (Vosk یا Whisper). */
object Transcriber {
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    const val PLACEHOLDER = "🎤 در حال تبدیل صدا به متن…"
    const val PLAIN = "🎤 یادداشت صوتی"
    private const val FAILED = "🎤 یادداشت صوتی (تبدیل به متن ناموفق بود)"
    private const val EMPTY = "🎤 یادداشت صوتی (متنی تشخیص داده نشد)"

    fun canTranscribe(path: String) = path.endsWith(".wav", ignoreCase = true)

    fun start(ctx: Context, noteId: Long, wavPath: String, onDone: ((Boolean) -> Unit)? = null) {
        val app = ctx.applicationContext
        exec.execute {
            var ok: Boolean
            var text = ""
            try {
                text = run(app, wavPath).trim()
                ok = true
            } catch (e: Throwable) {
                ok = false
            }
            if (NoteStore.get(app, noteId) != null) {
                NoteStore.updateText(app, noteId, if (!ok) FAILED else if (text.isEmpty()) EMPTY else text)
                NoteStore.updateTranscript(app, noteId, text)
                if (ok && text.isNotEmpty()) applyVoiceAlarm(app, noteId, text)
                WidgetUpdater.refresh(app)
            }
            if (onDone != null) main.post { onDone(ok) }
        }
    }

    /** اگر در متن «آلارم» و ساعت آمده بود، آلارم یادداشت را برای همان زمان می‌گذارد. */
    private fun applyVoiceAlarm(app: Context, noteId: Long, text: String) {
        val t = VoiceAlarm.parse(text, System.currentTimeMillis()) ?: return
        NoteStore.setAlarm(app, noteId, t)
        AlarmScheduler.schedule(app, noteId, t)
        main.post {
            Toast.makeText(app, "آلارم تنظیم شد: " + Jalali.formatLong(t), Toast.LENGTH_LONG).show()
        }
    }

    private fun run(ctx: Context, wavPath: String): String {
        val engine = Stt.current(ctx)
        return if (engine.isWhisper) runWhisper(ctx, engine, wavPath) else runVosk(ctx, wavPath)
    }

    private fun runWhisper(ctx: Context, engine: Engine, wavPath: String): String {
        val f = File(wavPath)
        val bytes = f.length() - 44
        if (bytes <= 0) return ""
        val samples = FloatArray((bytes / 2).toInt())
        RandomAccessFile(f, "r").use { raf ->
            raf.seek(44)
            val buf = ByteArray(64 * 1024)
            var idx = 0
            while (idx < samples.size) {
                val n = raf.read(buf)
                if (n <= 0) break
                var i = 0
                while (i + 1 < n && idx < samples.size) {
                    val v = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)
                    samples[idx++] = v.toShort() / 32768f
                    i += 2
                }
            }
        }
        return WhisperLib.transcribe(Stt.whisperFile(ctx, engine).absolutePath, samples, "fa", 4)
            ?: throw RuntimeException("whisper failed")
    }

    private fun runVosk(ctx: Context, wavPath: String): String {
        val model = SpeechModel.get(ctx)
        val sb = StringBuilder()
        fun add(json: String) {
            val t = JSONObject(json).optString("text", "").trim()
            if (t.isNotEmpty()) {
                if (sb.isNotEmpty()) sb.append(' ')
                sb.append(t)
            }
        }
        Recognizer(model, 16000f).use { rec ->
            RandomAccessFile(File(wavPath), "r").use { raf ->
                raf.seek(44)   // رد شدن از سرآیند WAV
                val buf = ByteArray(8000)
                while (true) {
                    val n = raf.read(buf)
                    if (n <= 0) break
                    if (rec.acceptWaveForm(buf, n)) add(rec.result)
                }
                add(rec.finalResult)
            }
        }
        return sb.toString()
    }
}
