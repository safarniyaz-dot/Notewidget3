package com.example.notewidget

import android.content.Context
import java.io.File

/** موتورهای تبدیل صدا به متن که کاربر می‌تواند انتخاب کند. */
enum class Engine(val id: String, val title: String, val note: String, val mb: Int) {
    VOSK("vosk", "Vosk فارسی", "سریع و سبک", 53),
    W_TINY("tiny", "Whisper Tiny", "سریع، دقت کم", 75),
    W_BASE("base", "Whisper Base", "دقت متوسط", 142),
    W_SMALL("small", "Whisper Small", "دقت بهتر، کندتر", 466);

    val isWhisper get() = this != VOSK
}

object Stt {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun current(ctx: Context): Engine {
        val id = prefs(ctx).getString("stt_engine", Engine.VOSK.id)
        return Engine.values().firstOrNull { it.id == id } ?: Engine.VOSK
    }

    fun setCurrent(ctx: Context, e: Engine) {
        prefs(ctx).edit().putString("stt_engine", e.id).apply()
    }

    fun whisperFile(ctx: Context, e: Engine) = File(File(ctx.filesDir, "whisper"), "ggml-${e.id}.bin")

    private fun whisperUrl(e: Engine) =
        "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-${e.id}.bin"

    fun isReady(ctx: Context, e: Engine): Boolean =
        if (e.isWhisper) whisperFile(ctx, e).length() > 1_000_000L else SpeechModel.isReady(ctx)

    /** آیا موتور انتخاب‌شده آماده‌ی کار است؟ */
    fun isReady(ctx: Context): Boolean = isReady(ctx, current(ctx))

    /** دانلود مدل (روی نخ پس‌زمینه). */
    fun download(ctx: Context, e: Engine, onProgress: (Int) -> Unit) {
        if (e.isWhisper) {
            Downloader.fetch(whisperUrl(e), whisperFile(ctx, e), 0, 100, onProgress)
        } else {
            SpeechModel.download(ctx, onProgress)
        }
    }
}

/** پل به کتابخانه‌ی بومی whisper.cpp (فقط روی arm64). */
object WhisperLib {
    init {
        System.loadLibrary("whisperjni")
    }

    @JvmStatic
    external fun transcribe(modelPath: String, audio: FloatArray, lang: String, threads: Int): String?
}
