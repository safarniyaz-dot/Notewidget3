package com.example.notewidget

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var soundBtn: Button
    private lateinit var colorBtn: Button
    private lateinit var oldBtn: Button
    private lateinit var speechBtn: Button
    private lateinit var fontBtn: Button
    private lateinit var voiceAlarmBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 96, 48, 48)
        }

        root.addView(TextView(this).apply {
            text = "ویجت یادداشت با آلارم شمسی\n\n" +
                    "۱. روی صفحه اصلی گوشی نگه دارید و «ویجت‌ها» را بزنید.\n" +
                    "۲. ویجت «taghva.nazm» را به صفحه اصلی بکشید.\n" +
                    "۳. روی «افزودن یادداشت…» بزنید و یادداشت بنویسید.\n" +
                    "۴. برای ویرایش یادداشت، روی متن آن بزنید.\n" +
                    "۵. با آیکن میکروفون بالای ویجت، یادداشت صوتی ضبط کنید. برای تبدیل خودکار صدا به متن، یک بار مدل (Vosk یا Whisper) را دانلود کنید. اگر در صحبتتان بگویید «آلارم ساعت هشت و نیم صبح»، آلارم همان ساعت خودکار تنظیم می‌شود.\n" +
                    "۶. با آیکن ساعت کنار هر یادداشت، آلارم شمسی تنظیم کنید؛ برای یادداشت صوتی، همان صدا در آلارم پخش می‌شود."
            textSize = 16f
            setLineSpacing(8f, 1f)
        })

        fun addButton(label: String, onClick: () -> Unit): Button {
            val b = Button(this).apply {
                text = label
                setOnClickListener { onClick() }
            }
            root.addView(b)
            return b
        }

        addButton("افزودن یادداشت") {
            startActivity(Intent(this, AddNoteActivity::class.java))
        }

        addButton("ضبط یادداشت صوتی") {
            startActivity(Intent(this, VoiceNoteActivity::class.java))
        }

        addButton("افزودن ویجت به صفحه اصلی") {
            val m = AppWidgetManager.getInstance(this)
            if (m.isRequestPinAppWidgetSupported) {
                m.requestPinAppWidget(ComponentName(this, NoteWidgetProvider::class.java), null, null)
            } else {
                Toast.makeText(this, "ویجت را از منوی ویجت‌ها اضافه کنید", Toast.LENGTH_LONG).show()
            }
        }

        // رنگ ویجت
        colorBtn = addButton("") { pickColor() }
        refreshColorLabel()

        // انتخاب صدای آلارم
        soundBtn = addButton("") { pickSound() }
        refreshSoundLabel()

        // مدل آفلاین تبدیل صدا به متن
        speechBtn = addButton("") { pickEngine() }
        refreshSpeechLabel()

        fontBtn = addButton("") { pickFont() }
        fontBtn.text = "اندازه‌ی فونت یادداشت‌ها: " + FontPrefs.label(this)

        voiceAlarmBtn = addButton("") { pickVoiceAlarm() }
        voiceAlarmBtn.text = "آلارم یادداشت صوتی: " + VoiceAlarmMode.label(this)

        addButton("تست آلارم (۱۰ ثانیه دیگر)") { testAlarm() }

        // فقط وقتی نسخه‌ی قدیمی برنامه (با شناسه‌ی دیگر) روی گوشی مانده باشد دیده می‌شود
        oldBtn = addButton("حذف نسخه قدیمی برنامه (تکراری)") {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$OLD_PACKAGE")))
        }
        oldBtn.visibility = View.GONE

        addButton("تنظیمات اعلان (برای آلارم)") {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        }

        addButton("نمایش آلارم روی صفحه (روشن کنید)") {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                Toast.makeText(this, "این تنظیم در گوشی شما پیدا نشد", Toast.LENGTH_LONG).show()
            }
        }

        if (Build.VERSION.SDK_INT >= 34) {
            addButton("اجازه آلارم تمام‌صفحه") {
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (e: Exception) {
                    Toast.makeText(this, "این تنظیم در گوشی شما پیدا نشد", Toast.LENGTH_LONG).show()
                }
            }
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        oldBtn.visibility = if (isInstalled(OLD_PACKAGE)) View.VISIBLE else View.GONE
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    // ---------- تبدیل صدا به متن (آفلاین) ----------

    private fun refreshSpeechLabel() {
        val e = Stt.current(this)
        speechBtn.text = "تبدیل صدا به متن: " + e.title +
                (if (Stt.isReady(this, e)) " ✓" else " (دانلود نشده)")
    }

    private fun pickEngine() {
        val engines = Engine.values()
        val cur = Stt.current(this)
        val names = engines.map { e ->
            val state = when {
                Stt.isReady(this, e) && e == cur -> "  ✓ فعال"
                Stt.isReady(this, e) -> "  (دانلود شده)"
                else -> "  ⬇ دانلود"
            }
            e.title + " — " + e.note + " (" + Jalali.digits(e.mb.toString()) + " مگابایت)" + state
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("موتور تبدیل صدا به متن")
            .setItems(names) { _, which ->
                val e = engines[which]
                if (e.isWhisper && !Build.SUPPORTED_64_BIT_ABIS.contains("arm64-v8a")) {
                    Toast.makeText(this, "Whisper فقط روی گوشی‌های ۶۴ بیتی کار می‌کند", Toast.LENGTH_LONG).show()
                } else if (Stt.isReady(this, e)) {
                    Stt.setCurrent(this, e)
                    refreshSpeechLabel()
                } else {
                    downloadEngine(e)
                }
            }
            .setNegativeButton("بستن", null)
            .show()
    }

    private fun downloadEngine(e: Engine) {
        val tv = TextView(this).apply {
            text = "در حال دانلود… ۰٪\nلطفاً اینترنت را قطع نکنید."
            setPadding(48, 32, 48, 16)
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("دانلود " + e.title)
            .setView(tv)
            .setCancelable(false)
            .create()
        dlg.show()
        Thread {
            var err: String? = null
            try {
                Stt.download(applicationContext, e) { p ->
                    runOnUiThread {
                        tv.text = "در حال " + (if (p >= 90 && !e.isWhisper) "آماده‌سازی" else "دانلود") + "… " +
                                Jalali.digits(p.toString()) + "٪\nلطفاً اینترنت را قطع نکنید."
                    }
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            runOnUiThread {
                dlg.dismiss()
                if (err == null) {
                    Stt.setCurrent(this, e)
                    Toast.makeText(this, e.title + " آماده شد و فعال است.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "دانلود ناموفق بود: $err", Toast.LENGTH_LONG).show()
                }
                refreshSpeechLabel()
            }
        }.start()
    }

    // ---------- اندازه‌ی فونت و صدای آلارم یادداشت صوتی ----------

    private fun pickFont() {
        val names = FontPrefs.presets.map { it.first + " (" + Jalali.digits(it.second.toString()) + ")" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("اندازه‌ی فونت یادداشت‌ها")
            .setItems(names) { _, which ->
                FontPrefs.save(this, FontPrefs.presets[which].second)
                WidgetUpdater.refresh(this)
                fontBtn.text = "اندازه‌ی فونت یادداشت‌ها: " + FontPrefs.label(this)
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun pickVoiceAlarm() {
        val names = arrayOf("پخش صدای خود یادداشت صوتی", "پخش آلارم گوشی (همان صدای آلارم انتخاب‌شده)")
        AlertDialog.Builder(this)
            .setTitle("آلارم یادداشت‌های صوتی")
            .setItems(names) { _, which ->
                VoiceAlarmMode.save(this, which == 0)
                voiceAlarmBtn.text = "آلارم یادداشت صوتی: " + VoiceAlarmMode.label(this)
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // ---------- رنگ ویجت ----------

    private fun refreshColorLabel() {
        colorBtn.text = "رنگ ویجت: " + WidgetThemes.label(this)
    }

    private fun applyColor(color: Int) {
        WidgetThemes.save(this, color)
        WidgetUpdater.applyTheme(this)
        refreshColorLabel()
    }

    private fun pickColor() {
        val names = WidgetThemes.presets.map { it.first }.toMutableList()
        names.add("رنگ دلخواه (کد HEX)…")
        AlertDialog.Builder(this)
            .setTitle("رنگ ویجت")
            .setItems(names.toTypedArray()) { _, which ->
                if (which < WidgetThemes.presets.size) {
                    applyColor(WidgetThemes.presets[which].second)
                } else {
                    askHexColor()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun askHexColor() {
        val et = EditText(this).apply {
            hint = "مثلاً #1E3A5F"
            inputType = InputType.TYPE_CLASS_TEXT
            setText("#")
            setSelection(1)
            setPadding(48, 32, 48, 32)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("رنگ دلخواه")
            .setMessage("کد رنگ را به صورت #RRGGBB وارد کنید.")
            .setView(et)
            .setPositiveButton("اعمال", null)
            .setNegativeButton("انصراف", null)
            .create()
        dialog.show()
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            try {
                val c = Color.parseColor(et.text.toString().trim())
                applyColor(c)
                dialog.dismiss()
            } catch (e: Exception) {
                Toast.makeText(this, "کد رنگ درست نیست", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- صدای آلارم ----------

    private fun refreshSoundLabel() {
        soundBtn.text = "صدای آلارم: " + SoundPrefs.label(this)
    }

    private fun pickSound() {
        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "صدای آلارم")
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, SoundPrefs.resolve(this@MainActivity))
        }
        startActivityForResult(i, REQ_SOUND)
    }

    /** یک یادداشت آزمایشی می‌سازد و آلارمش را برای ۱۰ ثانیه بعد می‌گذارد. */
    private fun testAlarm() {
        val n = NoteStore.add(this, "تست آلارم")
        val t = System.currentTimeMillis() + 10_000L
        NoteStore.setAlarm(this, n.id, t)
        AlarmScheduler.schedule(this, n.id, t)
        WidgetUpdater.refresh(this)
        Toast.makeText(this, "۱۰ ثانیه دیگر آلارم می‌زند", Toast.LENGTH_SHORT).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SOUND && resultCode == RESULT_OK && data != null) {
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            SoundPrefs.save(this, uri)
            refreshSoundLabel()
        }
    }

    companion object {
        private const val REQ_SOUND = 21
        private const val OLD_PACKAGE = "com.example.notewidget"
    }
}
