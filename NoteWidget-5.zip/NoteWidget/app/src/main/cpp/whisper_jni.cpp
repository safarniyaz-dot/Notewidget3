#include <jni.h>
#include <string>
#include <vector>
#include "whisper.h"

// تبدیل صدا (float 16kHz mono) به متن با whisper.cpp
extern "C" JNIEXPORT jstring JNICALL
Java_com_example_notewidget_WhisperLib_transcribe(
        JNIEnv *env, jclass, jstring modelPath, jfloatArray audio, jstring lang, jint threads) {
    const char *mp = env->GetStringUTFChars(modelPath, nullptr);
    struct whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    struct whisper_context *ctx = whisper_init_from_file_with_params(mp, cp);
    env->ReleaseStringUTFChars(modelPath, mp);
    if (ctx == nullptr) return nullptr;

    const char *lg = env->GetStringUTFChars(lang, nullptr);
    std::string language(lg);
    env->ReleaseStringUTFChars(lang, lg);

    struct whisper_full_params p = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    p.print_realtime = false;
    p.print_progress = false;
    p.print_timestamps = false;
    p.print_special = false;
    p.translate = false;
    p.language = language.c_str();
    p.n_threads = threads;
    p.no_context = true;
    p.single_segment = false;

    jsize n = env->GetArrayLength(audio);
    jfloat *data = env->GetFloatArrayElements(audio, nullptr);
    int rc = whisper_full(ctx, p, data, (int) n);
    env->ReleaseFloatArrayElements(audio, data, JNI_ABORT);

    std::string out;
    if (rc == 0) {
        int segs = whisper_full_n_segments(ctx);
        for (int i = 0; i < segs; i++) {
            const char *t = whisper_full_get_segment_text(ctx, i);
            if (t != nullptr) out += t;
        }
    }
    whisper_free(ctx);
    if (rc != 0) return nullptr;
    return env->NewStringUTF(out.c_str());
}
