package com.example.notewidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

object WidgetUpdater {
    /** فقط لیست یادداشت‌ها را دوباره می‌سازد. */
    fun refresh(ctx: Context) {
        val m = AppWidgetManager.getInstance(ctx)
        val ids = m.getAppWidgetIds(ComponentName(ctx, NoteWidgetProvider::class.java))
        m.notifyAppWidgetViewDataChanged(ids, R.id.list)
    }

    /** بعد از تغییر رنگ: کل ویجت (قاب + لیست) دوباره ساخته می‌شود. */
    fun applyTheme(ctx: Context) {
        val m = AppWidgetManager.getInstance(ctx)
        val ids = m.getAppWidgetIds(ComponentName(ctx, NoteWidgetProvider::class.java))
        for (id in ids) m.updateAppWidget(id, NoteWidgetProvider.buildViews(ctx, id))
        m.notifyAppWidgetViewDataChanged(ids, R.id.list)
    }
}

class NoteWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, buildViews(ctx, id))
    }

    override fun onDeleted(ctx: Context, ids: IntArray) {
        for (id in ids) Boards.clearWidget(ctx, id)
    }

    companion object {
        fun buildViews(ctx: Context, widgetId: Int): RemoteViews {
            val t = WidgetThemes.current(ctx)
            val rv = RemoteViews(ctx.packageName, R.layout.widget_notes)
            val board = Boards.boardOf(ctx, widgetId)
            rv.setTextViewText(
                R.id.add,
                if (board == 0) "افزودن یادداشت…" else "افزودن به «" + Boards.name(ctx, board) + "»…"
            )

            val svc = Intent(ctx, NoteWidgetService::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                data = Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
            }
            rv.setRemoteAdapter(R.id.list, svc)
            rv.setEmptyView(R.id.list, R.id.empty)

            // رنگ‌ها
            rv.setInt(R.id.root, "setBackgroundColor", t.bg)
            rv.setInt(R.id.add_bar, "setBackgroundColor", t.row)
            rv.setTextColor(R.id.add, t.sub)
            rv.setInt(R.id.btn_mic, "setColorFilter", t.text)
            rv.setInt(R.id.thick_line, "setBackgroundColor", t.accent)
            rv.setTextColor(R.id.empty, t.sub)

            // کلیک روی دکمه‌ها و متن هر ردیف (حذف / آلارم / ویرایش / انجام شد)
            // NEW_TASK + CLEAR_TASK: صفحه در تسک جدا باز می‌شود (صفحه‌ی دیگری پشتش نمی‌ماند)
            val newTask = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            val template = PendingIntent.getActivity(
                ctx, widgetId * 10, Intent(ctx, ItemActionActivity::class.java).addFlags(newTask),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            rv.setPendingIntentTemplate(R.id.list, template)

            // کلیک روی «افزودن یادداشت…»
            val add = PendingIntent.getActivity(
                ctx, widgetId * 10 + 1,
                Intent(ctx, AddNoteActivity::class.java).addFlags(newTask).putExtra("board", board),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.add, add)

            // کلیک روی میکروفون: ضبط یادداشت صوتی
            val mic = PendingIntent.getActivity(
                ctx, widgetId * 10 + 2,
                Intent(ctx, VoiceNoteActivity::class.java).addFlags(newTask).putExtra("board", board),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.btn_mic, mic)
            return rv
        }
    }
}
