package com.example.notewidget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** بعد از روشن شدن گوشی یا آپدیت برنامه، آلارم‌ها دوباره تنظیم می‌شوند (آپدیت آلارم‌های قبلی را پاک می‌کند). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val now = System.currentTimeMillis()
        NoteStore.all(ctx).forEach { n ->
            if (n.alarm > now) {
                AlarmScheduler.schedule(ctx, n.id, n.alarm)
            } else if (n.alarm > 0 && n.repeat != 0 && n.rmin >= 0) {
                val next = Repeat.next(n.repeat, n.rmin, now)
                NoteStore.setAlarm(ctx, n.id, next)
                AlarmScheduler.schedule(ctx, n.id, next)
            }
        }
        WidgetUpdater.refresh(ctx)
    }
}
