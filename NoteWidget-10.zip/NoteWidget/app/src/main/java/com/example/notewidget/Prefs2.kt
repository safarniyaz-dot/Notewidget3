package com.example.notewidget

import android.content.Context

/** اندازه‌ی فونت متن یادداشت‌ها در ویجت. */
object FontPrefs {
    val presets = listOf(
        "کوچک" to 14, "متوسط" to 16, "بزرگ (پیش‌فرض)" to 18,
        "درشت" to 21, "خیلی درشت" to 24, "بسیار درشت" to 28
    )
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun sp(ctx: Context): Int = prefs(ctx).getInt("font_sp", 18)
    fun save(ctx: Context, sp: Int) = prefs(ctx).edit().putInt("font_sp", sp).apply()
    fun label(ctx: Context): String {
        val v = sp(ctx)
        return presets.firstOrNull { it.second == v }?.first ?: Jalali.digits(v.toString())
    }
}

/** صدای آلارم یادداشت‌های صوتی: صدای خود یادداشت یا آلارم گوشی. */
object VoiceAlarmMode {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
    fun useVoice(ctx: Context): Boolean = prefs(ctx).getBoolean("alarm_use_voice", true)
    fun save(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("alarm_use_voice", v).apply()
    fun label(ctx: Context) = if (useVoice(ctx)) "صدای خود یادداشت" else "آلارم گوشی"
}
