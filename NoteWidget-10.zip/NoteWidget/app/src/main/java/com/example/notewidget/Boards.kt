package com.example.notewidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Board(val id: Int, val name: String)

/**
 * «لیست‌ها»: هر ویجت یک لیست جدا را نشان می‌دهد؛ یادداشت‌هایی که از همان ویجت اضافه می‌شوند
 * به همان لیست می‌روند. لیست ۰ همان لیست پیش‌فرض است.
 */
object Boards {
    const val DEFAULT_NAME = "یادداشت‌ها"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("boards", Context.MODE_PRIVATE)

    private fun custom(ctx: Context): List<Board> {
        val arr = JSONArray(prefs(ctx).getString("data", "[]") ?: "[]")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Board(o.getInt("id"), o.getString("name"))
        }
    }

    private fun saveCustom(ctx: Context, list: List<Board>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name)) }
        prefs(ctx).edit().putString("data", arr.toString()).apply()
    }

    fun all(ctx: Context): List<Board> = listOf(Board(0, DEFAULT_NAME)) + custom(ctx)

    fun name(ctx: Context, id: Int): String = all(ctx).firstOrNull { it.id == id }?.name ?: DEFAULT_NAME

    @Synchronized
    fun add(ctx: Context, name: String): Board {
        val list = custom(ctx)
        val b = Board((list.maxOfOrNull { it.id } ?: 0) + 1, name)
        saveCustom(ctx, list + b)
        return b
    }

    @Synchronized
    fun rename(ctx: Context, id: Int, name: String) {
        saveCustom(ctx, custom(ctx).map { if (it.id == id) it.copy(name = name) else it })
    }

    /** لیست حذف می‌شود؛ یادداشت‌هایش به لیست پیش‌فرض می‌روند. */
    @Synchronized
    fun delete(ctx: Context, id: Int) {
        if (id == 0) return
        NoteStore.moveBoard(ctx, id, 0)
        saveCustom(ctx, custom(ctx).filter { it.id != id })
    }

    fun boardOf(ctx: Context, widgetId: Int): Int {
        val id = prefs(ctx).getInt("w$widgetId", 0)
        return if (all(ctx).any { it.id == id }) id else 0
    }

    fun setWidgetBoard(ctx: Context, widgetId: Int, board: Int) {
        prefs(ctx).edit().putInt("w$widgetId", board).apply()
    }

    fun clearWidget(ctx: Context, widgetId: Int) {
        prefs(ctx).edit().remove("w$widgetId").apply()
    }

    fun toJson(ctx: Context): JSONArray {
        val arr = JSONArray()
        custom(ctx).forEach { arr.put(JSONObject().put("id", it.id).put("name", it.name)) }
        return arr
    }

    /** لیست‌هایی را که در گوشی نیستند از پشتیبان اضافه می‌کند. */
    @Synchronized
    fun fromJson(ctx: Context, arr: JSONArray?) {
        if (arr == null) return
        val have = custom(ctx)
        val extra = mutableListOf<Board>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val id = o.getInt("id")
            if (id != 0 && have.none { it.id == id } && extra.none { it.id == id }) {
                extra.add(Board(id, o.getString("name")))
            }
        }
        if (extra.isNotEmpty()) saveCustom(ctx, have + extra)
    }
}
