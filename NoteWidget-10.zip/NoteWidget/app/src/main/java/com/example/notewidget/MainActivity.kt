package com.example.notewidget

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    // رنگ‌های صفحه
    private val cBg = 0xFFF3F4F9.toInt()
    private val cCard = Color.WHITE
    private val cText = 0xFF1B1F3A.toInt()
    private val cSub = 0xFF70758F.toInt()
    private val cAccent = 0xFF3B4590.toInt()
    private val cGold = 0xFFD9A441.toInt()
    private val cLine = 0xFFE8EAF2.toInt()

    private lateinit var content: LinearLayout
    private lateinit var colorSub: TextView
    private lateinit var fontSub: TextView
    private lateinit var soundSub: TextView
    private lateinit var voiceAlarmSub: TextView
    private lateinit var speechSub: TextView
    private lateinit var oldRow: View

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        actionBar?.hide()
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = 0xFF2E3560.toInt()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(cBg)
        }
        root.addView(header())

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(28))
        }
        root.addView(content)
        buildContent()

        setContentView(ScrollView(this).apply {
            setBackgroundColor(cBg)
            addView(root)
        })
    }

    override fun onResume() {
        super.onResume()
        oldRow.visibility = if (isInstalled(OLD_PACKAGE)) View.VISIBLE else View.GONE
        refreshSpeechLabel()
    }

    // ---------- ساخت صفحه ----------

    private fun header(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(22), dp(16), dp(26))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF2E3560.toInt(), 0xFF171A30.toInt())
            ).apply { cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dp(26).toFloat(), dp(26).toFloat(), dp(26).toFloat(), dp(26).toFloat()) }
        }
        box.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher)
            layoutParams = LinearLayout.LayoutParams(dp(76), dp(76))
        })
        box.addView(TextView(this).apply {
            text = "taghva nazm"
            textSize = 22f
            setTextColor(cGold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        })
        box.addView(TextView(this).apply {
            text = "یادداشت، یادداشت صوتی و آلارم شمسی"
            textSize = 13f
            setTextColor(0xCCFFFFFF.toInt())
            gravity = Gravity.CENTER
        })
        return box
    }

    private fun buildContent() {
        // --- شروع سریع ---
        val quick = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        quick.addView(tile("📝", "یادداشت جدید") {
            startActivity(Intent(this, AddNoteActivity::class.java))
        }, tileLp(0))
        quick.addView(tile("🎤", "یادداشت صوتی") {
            startActivity(Intent(this, VoiceNoteActivity::class.java))
        }, tileLp(dp(10)))
        quick.addView(tile("🧩", "افزودن ویجت") { addWidget() }, tileLp(dp(10)))
        content.addView(quick)

        // --- پرسش از یادداشت‌ها ---
        card(topMargin = 14) {
            row("🔎", "از یادداشت‌هایم بپرس", "جواب را از میان یادداشت‌هایتان پیدا می‌کند (آفلاین)") {
                startActivity(Intent(this, AskActivity::class.java))
            }
        }

        // --- ظاهر ---
        section("ظاهر")
        card {
            colorSub = row("🎨", "رنگ ویجت") { pickColor() }
            divider()
            fontSub = row("🔠", "اندازه‌ی فونت یادداشت‌ها") { pickFont() }
            divider()
            row("🗂", "لیست‌ها و ویجت‌های جدا", "هر ویجت می‌تواند لیست خودش را نشان بدهد") { showBoards() }
        }
        refreshColorLabel()
        fontSub.text = FontPrefs.label(this)

        // --- آلارم و صدا ---
        section("آلارم و صدا")
        card {
            soundSub = row("🔔", "صدای آلارم") { pickSound() }
            divider()
            voiceAlarmSub = row("🎙", "آلارم یادداشت‌های صوتی") { pickVoiceAlarm() }
            divider()
            row("⏱", "تست آلارم", "۱۰ ثانیه‌ی دیگر یک آلارم آزمایشی می‌زند") { testAlarm() }
        }
        refreshSoundLabel()
        voiceAlarmSub.text = VoiceAlarmMode.label(this)

        // --- تبدیل صدا به متن ---
        section("تبدیل صدا به متن (آفلاین)")
        card {
            speechSub = row("📝", "مدل تشخیص گفتار فارسی") { downloadSpeechModel() }
            divider()
            info(
                "اگر بگویید «آلارم سه شنبه ۱۹ آبان ساعت ۱۲ و ۳۰ دقیقه»، «آلارم فردا ساعت هشت»، " +
                        "«آلارم سه شنبه ها ساعت ۱۲ و نیم» یا «آلارم هر روز ساعت ۱۷:۳۰»، آلارم خودکار تنظیم می‌شود " +
                        "و آن عبارت از متن یادداشت حذف می‌شود."
            )
        }
        refreshSpeechLabel()

        // --- مجوزها ---
        section("مجوزهای آلارم")
        card {
            row("🔕", "تنظیمات اعلان", "برای نمایش آلارم روشن باشد") {
                startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                )
            }
            divider()
            row("🪟", "نمایش آلارم روی صفحه", "برای باز شدن خودکار صفحه‌ی آلارم") {
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    Toast.makeText(this, "این تنظیم در گوشی شما پیدا نشد", Toast.LENGTH_LONG).show()
                }
            }
            if (Build.VERSION.SDK_INT >= 34) {
                divider()
                row("📱", "آلارم تمام‌صفحه") {
                    try {
                        startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                                Uri.parse("package:$packageName")
                            )
                        )
                    } catch (e: Exception) {
                        Toast.makeText(this, "این تنظیم در گوشی شما پیدا نشد", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }

        // --- پشتیبان ---
        section("پشتیبان‌گیری")
        card {
            row("💾", "ذخیره‌ی پشتیبان یادداشت‌ها", "قبل از حذف یا نصب مجدد برنامه بگیرید") { exportBackup() }
            divider()
            row("📥", "بازیابی از پشتیبان") { importBackup() }
            divider()
            info("پشتیبان فقط متن یادداشت‌ها و آلارم‌ها را نگه می‌دارد؛ فایل صدای یادداشت‌های صوتی همراهش نیست.")
        }

        // --- نسخه‌ی قدیمی (فقط اگر روی گوشی مانده باشد) ---
        val oldCard = card {
            row("🧹", "حذف نسخه‌ی قدیمی برنامه (تکراری)", "نسخه‌ای با شناسه‌ی قدیمی روی گوشی مانده است") {
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$OLD_PACKAGE")))
            }
        }
        oldRow = oldCard
        oldRow.visibility = View.GONE

        content.addView(TextView(this).apply {
            text = "نسخه‌ی " + Jalali.digits(versionName())
            textSize = 12f
            setTextColor(cSub)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        })
    }

    private fun versionName(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }

    // ---------- اجزای ظاهری ----------

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun tileLp(startMargin: Int) = LinearLayout.LayoutParams(0, dp(92), 1f).apply {
        marginStart = startMargin
    }

    private fun tile(icon: String, label: String, onClick: () -> Unit): View {
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(cAccent, 18)
            isClickable = true
            elevation = dp(3).toFloat()
            setOnClickListener { onClick() }
        }
        v.addView(TextView(this).apply {
            text = icon
            textSize = 26f
            gravity = Gravity.CENTER
        })
        v.addView(TextView(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), 0)
        })
        return v
    }

    private fun section(title: String) {
        content.addView(TextView(this).apply {
            text = title
            textSize = 13f
            setTextColor(cAccent)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(6), dp(20), dp(6), dp(8))
        })
    }

    private var currentCard: LinearLayout? = null

    private fun card(topMargin: Int = 0, build: () -> Unit): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(cCard, 16)
            elevation = dp(2).toFloat()
        }
        content.addView(c, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { this.topMargin = dp(topMargin) })
        currentCard = c
        build()
        currentCard = null
        return c
    }

    private fun divider() {
        currentCard?.addView(View(this).apply { setBackgroundColor(cLine) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply {
                marginStart = dp(64)
            })
    }

    private fun info(text: String) {
        currentCard?.addView(TextView(this).apply {
            this.text = text
            textSize = 12.5f
            setTextColor(cSub)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(16), dp(12), dp(16), dp(14))
        })
    }

    /** یک ردیف تنظیمات: آیکن، عنوان، توضیح/مقدار؛ توضیح (TextView) برگردانده می‌شود تا بعداً عوض شود. */
    private fun row(icon: String, title: String, subtitle: String = "", onClick: () -> Unit): TextView {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            isClickable = true
            setBackgroundResource(android.R.drawable.list_selector_background)
            setOnClickListener { onClick() }
        }
        r.addView(TextView(this).apply {
            text = icon
            textSize = 20f
            gravity = Gravity.CENTER
            background = rounded(0xFFEEF0FA.toInt(), 12)
        }, LinearLayout.LayoutParams(dp(40), dp(40)))

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(cText)
            typeface = Typeface.DEFAULT_BOLD
        })
        val sub = TextView(this).apply {
            text = subtitle
            textSize = 12.5f
            setTextColor(cSub)
            visibility = if (subtitle.isEmpty()) View.GONE else View.VISIBLE
        }
        col.addView(sub)
        r.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = dp(12)
            marginEnd = dp(8)
        })
        r.addView(TextView(this).apply {
            text = "‹"
            textSize = 24f
            setTextColor(0xFFB4B8CC.toInt())
        })
        currentCard?.addView(r)
        return sub
    }

    private fun setSub(tv: TextView, text: String) {
        tv.text = text
        tv.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }

    // ---------- کارها ----------

    private fun addWidget() {
        val m = AppWidgetManager.getInstance(this)
        var started = false
        try {
            if (m.isRequestPinAppWidgetSupported) {
                started = m.requestPinAppWidget(ComponentName(this, NoteWidgetProvider::class.java), null, null)
            }
        } catch (e: Exception) {
            started = false
        }
        if (!started) showWidgetHelp()
    }

    /** بعضی لانچرها (مثل سامسونگ) افزودن ویجت از داخل برنامه را پشتیبانی نمی‌کنند. */
    private fun showWidgetHelp() {
        AlertDialog.Builder(this)
            .setTitle("افزودن ویجت")
            .setMessage(
                "لانچر گوشی شما افزودن ویجت از داخل برنامه را پشتیبانی نمی‌کند. این‌طور اضافه کنید:\n\n" +
                        "۱. روی یک جای خالی صفحه اصلی انگشت را نگه دارید.\n" +
                        "۲. «ویجت‌ها» را بزنید.\n" +
                        "۳. «taghva nazm» را پیدا کنید و ویجت را به صفحه اصلی بکشید.\n" +
                        "۴. لیست ویجت را انتخاب کنید یا لیست جدید بسازید."
            )
            .setPositiveButton("متوجه شدم", null)
            .show()
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    // ---------- لیست‌ها ----------

    private fun showBoards() {
        val boards = Boards.all(this)
        val names = (boards.map { it.name + if (it.id == 0) "  (پیش‌فرض)" else "" } + "＋ لیست جدید…").toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("لیست‌ها")
            .setItems(names) { _, which ->
                if (which == boards.size) askBoardName(null)
                else if (boards[which].id != 0) boardActions(boards[which])
            }
            .setNegativeButton("بستن", null)
            .show()
    }

    private fun boardActions(b: Board) {
        AlertDialog.Builder(this)
            .setTitle(b.name)
            .setItems(arrayOf("تغییر نام", "حذف لیست")) { _, which ->
                if (which == 0) askBoardName(b) else confirmDeleteBoard(b)
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun askBoardName(existing: Board?) {
        val et = EditText(this).apply {
            hint = "نام لیست (مثلاً خرید، کار، خانه)"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(existing?.name ?: "")
            setPadding(48, 32, 48, 32)
        }
        val d = AlertDialog.Builder(this)
            .setTitle(if (existing == null) "لیست جدید" else "تغییر نام لیست")
            .setView(et)
            .setPositiveButton("ثبت", null)
            .setNegativeButton("انصراف", null)
            .create()
        d.show()
        d.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val n = et.text.toString().trim()
            if (n.isEmpty()) {
                Toast.makeText(this, "نام لیست را بنویسید", Toast.LENGTH_SHORT).show()
            } else {
                if (existing == null) Boards.add(this, n) else Boards.rename(this, existing.id, n)
                WidgetUpdater.applyTheme(this)
                d.dismiss()
                showBoards()
            }
        }
    }

    private fun confirmDeleteBoard(b: Board) {
        AlertDialog.Builder(this)
            .setTitle("حذف «" + b.name + "»؟")
            .setMessage("یادداشت‌های این لیست به لیست پیش‌فرض منتقل می‌شوند.")
            .setPositiveButton("حذف") { _, _ ->
                Boards.delete(this, b.id)
                WidgetUpdater.applyTheme(this)
                showBoards()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // ---------- تبدیل صدا به متن ----------

    private fun refreshSpeechLabel() {
        if (!::speechSub.isInitialized) return
        setSub(
            speechSub,
            if (Stt.isReady(this)) "آماده است ✓  (آفلاین)" else "دانلود مدل (حدود ۵۳ مگابایت، فقط یک بار)"
        )
    }

    private fun downloadSpeechModel() {
        if (Stt.isReady(this)) {
            Toast.makeText(this, "مدل آماده است. بعد از ضبط، صدا خودکار به متن تبدیل می‌شود.", Toast.LENGTH_LONG).show()
            return
        }
        val tv = TextView(this).apply {
            text = "در حال دانلود… ۰٪\nلطفاً اینترنت را قطع نکنید."
            setPadding(48, 32, 48, 16)
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("دانلود مدل گفتار")
            .setView(tv)
            .setCancelable(false)
            .create()
        dlg.show()
        Thread {
            var err: String? = null
            try {
                Stt.download(applicationContext) { p ->
                    runOnUiThread {
                        tv.text = "در حال " + (if (p >= 90) "آماده‌سازی" else "دانلود") + "… " +
                                Jalali.digits(p.toString()) + "٪\nلطفاً اینترنت را قطع نکنید."
                    }
                }
            } catch (t: Throwable) {
                err = t.message ?: t.javaClass.simpleName
            }
            runOnUiThread {
                dlg.dismiss()
                refreshSpeechLabel()
                if (err == null) {
                    Toast.makeText(this, "مدل آماده شد. حالا یادداشت صوتی خودکار به متن تبدیل می‌شود.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "دانلود ناموفق بود: $err", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ---------- فونت و صدای آلارم یادداشت صوتی ----------

    private fun pickFont() {
        val names = FontPrefs.presets.map { it.first + " (" + Jalali.digits(it.second.toString()) + ")" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("اندازه‌ی فونت یادداشت‌ها")
            .setItems(names) { _, which ->
                FontPrefs.save(this, FontPrefs.presets[which].second)
                WidgetUpdater.refresh(this)
                fontSub.text = FontPrefs.label(this)
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun pickVoiceAlarm() {
        val names = arrayOf("پخش صدای خود یادداشت صوتی", "پخش آلارم گوشی (همان صدای آلارم انتخاب‌شده)")
        AlertDialog.Builder(this)
            .setTitle("آلارم یادداشت‌های صوتی")
            .setItems(names) { _, which ->
                VoiceAlarmMode.save(this, which == 0)
                voiceAlarmSub.text = VoiceAlarmMode.label(this)
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // ---------- رنگ ویجت ----------

    private fun refreshColorLabel() {
        setSub(colorSub, WidgetThemes.label(this))
    }

    private fun applyColor(color: Int) {
        WidgetThemes.save(this, color)
        WidgetUpdater.applyTheme(this)
        refreshColorLabel()
    }

    private fun pickColor() {
        val names = WidgetThemes.presets.map { it.first }.toMutableList()
        names.add("رنگ دلخواه (کد HEX)…")
        AlertDialog.Builder(this)
            .setTitle("رنگ ویجت")
            .setItems(names.toTypedArray()) { _, which ->
                if (which < WidgetThemes.presets.size) {
                    applyColor(WidgetThemes.presets[which].second)
                } else {
                    askHexColor()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun askHexColor() {
        val et = EditText(this).apply {
            hint = "مثلاً #1E3A5F"
            inputType = InputType.TYPE_CLASS_TEXT
            setText("#")
            setSelection(1)
            setPadding(48, 32, 48, 32)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("رنگ دلخواه")
            .setMessage("کد رنگ را به صورت #RRGGBB وارد کنید.")
            .setView(et)
            .setPositiveButton("اعمال", null)
            .setNegativeButton("انصراف", null)
            .create()
        dialog.show()
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            try {
                val c = Color.parseColor(et.text.toString().trim())
                applyColor(c)
                dialog.dismiss()
            } catch (e: Exception) {
                Toast.makeText(this, "کد رنگ درست نیست", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- صدای آلارم ----------

    private fun refreshSoundLabel() {
        setSub(soundSub, SoundPrefs.label(this))
    }

    private fun pickSound() {
        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "صدای آلارم")
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, SoundPrefs.resolve(this@MainActivity))
        }
        startActivityForResult(i, REQ_SOUND)
    }

    /** یک یادداشت آزمایشی می‌سازد و آلارمش را برای ۱۰ ثانیه بعد می‌گذارد. */
    private fun testAlarm() {
        val n = NoteStore.add(this, "تست آلارم")
        val t = System.currentTimeMillis() + 10_000L
        NoteStore.setAlarm(this, n.id, t)
        AlarmScheduler.schedule(this, n.id, t)
        WidgetUpdater.refresh(this)
        Toast.makeText(this, "۱۰ ثانیه دیگر آلارم می‌زند", Toast.LENGTH_SHORT).show()
    }

    // ---------- پشتیبان‌گیری ----------

    private fun exportBackup() {
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "taghva-nazm-backup.json")
        }
        startActivityForResult(i, REQ_EXPORT)
    }

    private fun importBackup() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(i, REQ_IMPORT)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            REQ_SOUND -> {
                val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                    data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
                }
                SoundPrefs.save(this, uri)
                refreshSoundLabel()
            }
            REQ_EXPORT -> {
                val uri = data.data ?: return
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(NoteStore.exportJson(this).toByteArray()) }
                    Toast.makeText(this, "پشتیبان ذخیره شد", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "ذخیره‌ی پشتیبان ناموفق بود", Toast.LENGTH_LONG).show()
                }
            }
            REQ_IMPORT -> {
                val uri = data.data ?: return
                try {
                    val json = contentResolver.openInputStream(uri)?.use { String(it.readBytes()) } ?: ""
                    val n = NoteStore.importJson(this, json)
                    WidgetUpdater.applyTheme(this)
                    Toast.makeText(this, Jalali.digits(n.toString()) + " یادداشت بازیابی شد", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "این فایل پشتیبان معتبر نیست", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    companion object {
        private const val REQ_SOUND = 21
        private const val REQ_EXPORT = 22
        private const val REQ_IMPORT = 23
        private const val OLD_PACKAGE = "com.example.notewidget"
    }
}
