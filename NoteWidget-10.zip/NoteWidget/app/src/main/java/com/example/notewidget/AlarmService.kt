package com.example.notewidget

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaPlayer
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import java.io.File

/** صدا و لرزش آلارم را پخش می‌کند تا کاربر آلارم را رد یا تعویق کند (حداکثر ۱ دقیقه). */
class AlarmService : Service() {

    private var ringtone: Ringtone? = null
    private var voice: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getLongExtra("id", 0L) ?: 0L
        val note = NoteStore.get(this, id)
        if (note == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        AlarmNotifier.ensureChannels(this)
        val n = AlarmNotifier.build(this, id, note, AlarmNotifier.CHANNEL_SILENT)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                AlarmActions.notifId(id), n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(AlarmActions.notifId(id), n)
        }

        startSound(note)
        startVibration()

        // اگر مجوز «نمایش روی سایر برنامه‌ها» داده شده باشد، صفحه‌ی آلارم مستقیم باز می‌شود
        try {
            if (Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(this, AlarmDialogActivity::class.java)
                        .putExtra("id", id)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        } catch (e: Exception) {
            // اعلان تمام‌صفحه جایگزین است
        }

        handler.postDelayed({ stopSelf() }, 60_000L)
        return START_NOT_STICKY
    }

    /** صدای ضبط‌شده‌ی یادداشت صوتی را (با فاصله‌ی کوتاه) تکرار می‌کند. */
    private fun startVoice(path: String): Boolean {
        return try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(AlarmNotifier.alarmAttributes())
            mp.setDataSource(path)
            mp.setOnCompletionListener {
                handler.postDelayed({
                    try { mp.start() } catch (e: Exception) { /* مهم نیست */ }
                }, 1500L)
            }
            mp.prepare()
            mp.start()
            voice = mp
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun startSound(note: Note) {
        // یادداشت صوتی: بر اساس تنظیم، صدای ضبط‌شده یا آلارم گوشی پخش می‌شود
        if (VoiceAlarmMode.useVoice(this) && note.audio.isNotEmpty() && File(note.audio).exists() &&
            startVoice(note.audio)
        ) return
        try {
            val uri = SoundPrefs.resolve(this) ?: return   // بی‌صدا
            val r = RingtoneManager.getRingtone(this, uri) ?: return
            r.setAudioAttributes(AlarmNotifier.alarmAttributes())
            if (Build.VERSION.SDK_INT >= 28) r.setLooping(true)
            r.play()
            ringtone = r
        } catch (e: Exception) {
            // ادامه بدون صدا
        }
    }

    private fun startVibration() {
        try {
            val v = getSystemService(Vibrator::class.java)
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 600, 400), 0))
            vibrator = v
        } catch (e: Exception) {
            // ادامه بدون لرزش
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { voice?.stop() } catch (e: Exception) {}
        try { voice?.release() } catch (e: Exception) {}
        try { ringtone?.stop() } catch (e: Exception) {}
        try { vibrator?.cancel() } catch (e: Exception) {}
        super.onDestroy()
    }
}
