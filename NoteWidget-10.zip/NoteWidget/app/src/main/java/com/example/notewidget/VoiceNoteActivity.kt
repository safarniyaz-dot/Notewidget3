package com.example.notewidget

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * ضبط یادداشت صوتی (WAV، ۱۶ کیلوهرتز، مونو؛ مناسب تبدیل به متن).
 * اگر مدل گفتار دانلود شده باشد، بعد از ذخیره صدا در پس‌زمینه به متن تبدیل می‌شود
 * و همان متن جای یادداشت را می‌گیرد.
 */
class VoiceNoteActivity : Activity() {

    private var audio: AudioRecord? = null
    private var thread: Thread? = null
    @Volatile private var recording = false
    @Volatile private var totalBytes = 0L
    private var file: File? = null
    private var noteId = 0L
    private var startTime = 0L
    private var dialog: AlertDialog? = null
    private var timerView: TextView? = null
    private var finished = false
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startFlow()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_MIC) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startFlow()
        } else {
            Toast.makeText(
                this, "برای ضبط صدا مجوز میکروفون لازم است. از تنظیمات برنامه آن را روشن کنید.",
                Toast.LENGTH_LONG
            ).show()
            finished = true
            finish()
        }
    }

    private fun startFlow() {
        noteId = System.currentTimeMillis()
        val dir = File(filesDir, "voice").apply { mkdirs() }
        val f = File(dir, "voice_$noteId.wav")
        file = f

        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val bufSize = maxOf(minBuf, SAMPLE_RATE)   // حدود نیم ثانیه
        val ar: AudioRecord
        try {
            ar = AudioRecord(
                MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize
            )
            if (ar.state != AudioRecord.STATE_INITIALIZED) {
                ar.release()
                throw IllegalStateException("not initialized")
            }
        } catch (e: Exception) {
            failStart()
            return
        }
        audio = ar
        recording = true

        val t = Thread {
            try {
                FileOutputStream(f).use { out ->
                    out.write(ByteArray(44))          // جای سرآیند WAV
                    val buf = ByteArray(bufSize)
                    ar.startRecording()
                    while (recording) {
                        val n = ar.read(buf, 0, buf.size)
                        if (n > 0) {
                            out.write(buf, 0, n)
                            totalBytes += n
                            if (totalBytes >= MAX_BYTES) {
                                recording = false
                                runOnUiThread { save() }
                            }
                        } else if (n < 0) {
                            break
                        }
                    }
                    try { ar.stop() } catch (e: Exception) { /* مهم نیست */ }
                }
                writeHeader(f, totalBytes)
            } catch (e: Exception) {
                // فایل ناقص بماند؛ هنگام ذخیره بررسی می‌شود
            } finally {
                try { ar.release() } catch (e: Exception) { /* مهم نیست */ }
            }
        }
        thread = t
        t.start()

        startTime = System.currentTimeMillis()

        val dp = resources.displayMetrics.density
        val pad = (20 * dp).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val tv = TextView(this).apply {
            text = timerText()
            textSize = 18f
        }
        box.addView(tv)
        timerView = tv

        val d = AlertDialog.Builder(this)
            .setTitle("یادداشت صوتی")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("توقف و ذخیره", null)
            .setNegativeButton("انصراف", null)
            .create()
        d.show()
        d.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener { save() }
        d.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener { cancel() }
        dialog = d

        handler.postDelayed(object : Runnable {
            override fun run() {
                if (finished) return
                timerView?.text = timerText()
                handler.postDelayed(this, 500)
            }
        }, 500)
    }

    private fun failStart() {
        Toast.makeText(this, "ضبط صدا شروع نشد", Toast.LENGTH_LONG).show()
        file?.delete()
        finished = true
        finish()
    }

    private fun timerText(): String {
        val sec = ((System.currentTimeMillis() - startTime) / 1000).toInt()
        return "● در حال ضبط…  " + Jalali.digits("%02d:%02d".format(sec / 60, sec % 60))
    }

    /** ضبط را متوقف می‌کند و منتظر بسته شدن فایل می‌ماند. */
    private fun stopRecording() {
        recording = false
        try { thread?.join(3000) } catch (e: InterruptedException) { /* مهم نیست */ }
        thread = null
        audio = null
    }

    private fun writeHeader(f: File, dataLen: Long) {
        RandomAccessFile(f, "rw").use { raf ->
            val bb = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            bb.put("RIFF".toByteArray())
            bb.putInt((36 + dataLen).toInt())
            bb.put("WAVE".toByteArray())
            bb.put("fmt ".toByteArray())
            bb.putInt(16)
            bb.putShort(1)                       // PCM
            bb.putShort(1)                       // مونو
            bb.putInt(SAMPLE_RATE)
            bb.putInt(SAMPLE_RATE * 2)           // byte rate
            bb.putShort(2)                       // block align
            bb.putShort(16)                      // bits
            bb.put("data".toByteArray())
            bb.putInt(dataLen.toInt())
            raf.seek(0)
            raf.write(bb.array())
        }
    }

    private fun save() {
        if (finished) return
        finished = true
        handler.removeCallbacksAndMessages(null)
        stopRecording()

        val f = file
        val minBytes = SAMPLE_RATE * 2 * 7 / 10      // حداقل ۰٫۷ ثانیه
        if (f != null && f.exists() && totalBytes >= minBytes) {
            val auto = Stt.isReady(this)
            NoteStore.add(
                this, if (auto) Transcriber.PLACEHOLDER else Transcriber.PLAIN, f.absolutePath, noteId,
                board = intent.getIntExtra("board", 0)
            )
            WidgetUpdater.refresh(this)
            if (auto) {
                Transcriber.start(this, noteId, f.absolutePath)
                Toast.makeText(this, "ذخیره شد؛ تبدیل صدا به متن در حال انجام است…", Toast.LENGTH_SHORT).show()
            }
        } else {
            f?.delete()
            Toast.makeText(this, "ضبط خیلی کوتاه بود", Toast.LENGTH_SHORT).show()
        }
        dialog?.dismiss()
        finish()
    }

    private fun cancel() {
        if (finished) return
        finished = true
        handler.removeCallbacksAndMessages(null)
        stopRecording()
        file?.delete()
        dialog?.dismiss()
        finish()
    }

    /** اگر وسط ضبط از برنامه خارج شدند (Home)، آنچه ضبط شده ذخیره می‌شود. */
    override fun onStop() {
        super.onStop()
        if (recording && !finished) save()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (!finished) {
            finished = true
            stopRecording()
            file?.delete()
        }
        super.onDestroy()
    }

    companion object {
        private const val REQ_MIC = 31
        private const val SAMPLE_RATE = 16000
        private const val MAX_BYTES = 5L * 60 * SAMPLE_RATE * 2
    }
}
