package com.example.notewidget

import android.content.Context

/** تبدیل صدا به متن آفلاین با Vosk (مدل فارسی). */
object Stt {
    fun isReady(ctx: Context): Boolean = SpeechModel.isReady(ctx)

    /** دانلود مدل (روی نخ پس‌زمینه). */
    fun download(ctx: Context, onProgress: (Int) -> Unit) = SpeechModel.download(ctx, onProgress)
}
