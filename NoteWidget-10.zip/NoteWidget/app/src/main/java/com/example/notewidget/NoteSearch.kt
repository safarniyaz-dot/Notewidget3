package com.example.notewidget

import kotlin.math.ln

/**
 * پرسش و پاسخ آفلاین روی یادداشت‌ها (بدون هوش مصنوعی سنگین): کلمات سؤال با یادداشت‌ها
 * مقایسه می‌شود (امتیازدهی BM25 + ریشه‌یابی ساده‌ی فارسی)، بهترین یادداشت‌ها پیدا می‌شوند
 * و از هر کدام جمله‌ای که بیشترین ارتباط را دارد به‌عنوان پاسخ نشان داده می‌شود.
 * اگر کلمات سؤال به اندازه‌ی کافی در یادداشتی نباشد، «پیدا نشد» برمی‌گردد.
 */
object NoteSearch {

    class Hit(val note: Note, val sentence: String, val score: Double, val coverage: Double)

    private val suffixes = listOf(
        "هایی", "های", "ها", "ات", "ان", "ین", "ام", "اش", "مان", "تان", "شان", "یم", "ی", "م", "ت", "ش"
    )

    private val stop: Set<String> by lazy {
        ("و در به از که این آن را با برای است بود می یک هم تا یا چه چی کی کجا چند چقدر چرا چطور چگونه آیا " +
                "من تو ما شما او ایشان اون اینم همه هر بر نیز اما ولی اگر باید شد شده شود دارد دارم داره هست هستم " +
                "نیست بین پس بعد قبل روی زیر خیلی کنم کن کرد کنید کند گفت گفتم بگو بگید رو چیه چنده کیه کیست " +
                "چیست کجاست چطوره چقدره بوده")
            .split(" ").map { norm(it) }.filter { it.isNotEmpty() }.toSet()
    }

    /** نرمال‌سازی: ی/ک عربی، آ←ا، اعداد فارسی/عربی←لاتین، حذف اعراب و نیم‌فاصله و علائم. */
    fun norm(s: String): String {
        val sb = StringBuilder()
        for (c0 in s) {
            if (c0 in 'ً'..'ٟ' || c0 == '‌') continue
            val c = when (c0) {
                'ي' -> 'ی'
                'ك' -> 'ک'
                'آ', 'أ', 'إ' -> 'ا'
                'ة' -> 'ه'
                in '۰'..'۹' -> '0' + (c0 - '۰')
                in '٠'..'٩' -> '0' + (c0 - '٠')
                else -> c0
            }
            if (c.isLetterOrDigit()) sb.append(c.lowercaseChar()) else sb.append(' ')
        }
        return sb.toString()
    }

    private fun stem(w0: String): String {
        var w = w0
        if (w.startsWith("می") && w.length > 4) w = w.substring(2)
        for (s in suffixes) {
            if (w.endsWith(s) && w.length - s.length >= 3) return w.substring(0, w.length - s.length)
        }
        return w
    }

    fun tokens(s: String): List<String> =
        norm(s).split(' ').filter { it.isNotEmpty() && it !in stop }.map { stem(it) }

    private fun lev1(a0: String, b0: String): Boolean {
        var a = a0
        var b = b0
        if (Math.abs(a.length - b.length) > 1) return false
        if (a.length == b.length) {
            var diff = 0
            for (i in a.indices) if (a[i] != b[i]) diff++
            return diff <= 1
        }
        if (a.length > b.length) { val t = a; a = b; b = t }
        for (i in b.indices) {
            if (b.substring(0, i) + b.substring(i + 1) == a) return true
        }
        return false
    }

    fun matches(q: String, d: String): Boolean =
        q == d || (q.length >= 4 && d.length >= 4 && (d.startsWith(q) || q.startsWith(d) || lev1(q, d)))

    /** کلمات مهم سؤال (بدون کلمات پرسشی و حرف اضافه). */
    fun queryTokens(question: String): List<String> = tokens(question).distinct()

    fun search(notes: List<Note>, question: String): List<Hit> {
        val qt = queryTokens(question)
        if (qt.isEmpty() || notes.isEmpty()) return emptyList()
        val docs = notes.map { tokens(it.text) }
        val n = docs.size
        val avg = maxOf(1.0, docs.sumOf { it.size }.toDouble() / n)

        val idf = qt.map { q ->
            val df = docs.count { d -> d.any { matches(q, it) } }
            ln(1 + (n - df + 0.5) / (df + 0.5))
        }

        class Scored(val index: Int, val score: Double, val coverage: Double)
        val scored = ArrayList<Scored>()
        for ((i, d) in docs.withIndex()) {
            var sc = 0.0
            val hit = HashSet<Int>()
            for ((j, q) in qt.withIndex()) {
                val tf = d.count { matches(q, it) }
                if (tf > 0) {
                    hit.add(j)
                    sc += idf[j] * tf * 2.2 / (tf + 1.2 * (0.25 + 0.75 * d.size / avg))
                }
            }
            // کلمه‌ی دو‌تکه‌ی سؤال (مثل «وای فای») که در یادداشت چسبیده آمده («وایفای»)
            for (j in 0 until qt.size - 1) {
                if (j in hit && (j + 1) in hit) continue
                val joined = qt[j] + qt[j + 1]
                if (d.any { matches(joined, it) }) {
                    for (k in intArrayOf(j, j + 1)) {
                        if (k !in hit) {
                            hit.add(k)
                            sc += idf[k]
                        }
                    }
                }
            }
            val cov = hit.size.toDouble() / qt.size
            val need = if (qt.size == 1) 1.0 else 0.5
            if (hit.isNotEmpty() && cov >= need) scored.add(Scored(i, sc, cov))
        }
        scored.sortByDescending { it.score }

        val splitter = Regex("(?<=[.!?؟؛])\\s+|\\n+")
        return scored.take(3).map { s ->
            val note = notes[s.index]
            val sentences = splitter.split(note.text).map { it.trim() }.filter { it.isNotEmpty() }
            val best = sentences.maxByOrNull { sent ->
                val st = tokens(sent)
                var v = 0.0
                for ((j, q) in qt.withIndex()) if (st.any { matches(q, it) }) v += idf[j]
                v
            } ?: note.text
            Hit(note, best, s.score, s.coverage)
        }
    }
}
