package com.example.notewidget

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.EditText
import android.widget.Toast

/** هنگام اضافه کردن ویجت باز می‌شود: انتخاب اینکه این ویجت کدام لیست را نشان بدهد (یا ساخت لیست جدید). */
class WidgetConfigActivity : Activity() {

    private var widgetId = AppWidgetManager.INVALID_APPWIDGET_ID

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        // اگر کاربر انصراف بدهد، ویجت اضافه نمی‌شود
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        showChoice()
    }

    private fun showChoice() {
        val boards = Boards.all(this)
        val names = (boards.map { it.name } + "＋ ساخت لیست جدید…").toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("این ویجت کدام لیست را نشان بدهد؟")
            .setItems(names) { _, which ->
                if (which < boards.size) done(boards[which].id) else askName()
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun askName() {
        val et = EditText(this).apply {
            hint = "نام لیست (مثلاً خرید، کار، خانه)"
            inputType = InputType.TYPE_CLASS_TEXT
            setPadding(48, 32, 48, 32)
        }
        val d = AlertDialog.Builder(this)
            .setTitle("لیست جدید")
            .setView(et)
            .setPositiveButton("ساخت", null)
            .setNegativeButton("انصراف") { _, _ -> showChoice() }
            .setOnCancelListener { showChoice() }
            .create()
        d.show()
        d.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val n = et.text.toString().trim()
            if (n.isEmpty()) {
                Toast.makeText(this, "نام لیست را بنویسید", Toast.LENGTH_SHORT).show()
            } else {
                d.dismiss()
                done(Boards.add(this, n).id)
            }
        }
    }

    private fun done(board: Int) {
        Boards.setWidgetBoard(this, widgetId, board)
        val m = AppWidgetManager.getInstance(this)
        m.updateAppWidget(widgetId, NoteWidgetProvider.buildViews(this, widgetId))
        m.notifyAppWidgetViewDataChanged(widgetId, R.id.list)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId))
        finish()
    }
}
