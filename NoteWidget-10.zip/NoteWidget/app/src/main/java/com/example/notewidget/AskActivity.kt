package com.example.notewidget

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** «از یادداشت‌هایم بپرس»: سؤال بنویسید؛ پاسخ از میان یادداشت‌ها (آفلاین) پیدا می‌شود. */
class AskActivity : Activity() {

    private val cBg = 0xFFF3F4F9.toInt()
    private val cText = 0xFF1B1F3A.toInt()
    private val cSub = 0xFF70758F.toInt()
    private val cAccent = 0xFF3B4590.toInt()
    private val cGold = 0xFFD9A441.toInt()

    private lateinit var input: EditText
    private lateinit var results: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        actionBar?.hide()
        window.statusBarColor = 0xFF2E3560.toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(cBg)
        }

        root.addView(TextView(this).apply {
            text = "🔎  از یادداشت‌هایم بپرس"
            textSize = 18f
            setTextColor(cGold)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF2E3560.toInt(), 0xFF171A30.toInt())
            )
        })

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(6))
        }
        input = EditText(this).apply {
            hint = "سؤالتان را بنویسید، مثلاً: رمز وای‌فای چیه؟"
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setHorizontallyScrolling(false)
            maxLines = 3
            textSize = 16f
            setTextColor(cText)
            background = rounded(Color.WHITE, 14)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEARCH) { ask(); true } else false
            }
        }
        box.addView(input)
        box.addView(Button(this).apply {
            text = "بپرس"
            setTextColor(Color.WHITE)
            background = rounded(cAccent, 14)
            setOnClickListener { ask() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(10) })
        root.addView(box)

        results = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(24))
        }
        root.addView(ScrollView(this).apply { addView(results) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        showMessage("سؤالتان را بنویسید. پاسخ فقط از میان یادداشت‌های خودتان پیدا می‌شود و همه‌چیز آفلاین است.")
    }

    private fun showMessage(msg: String) {
        results.removeAllViews()
        results.addView(TextView(this).apply {
            text = msg
            textSize = 14f
            setTextColor(cSub)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(6), dp(10), dp(6), dp(10))
        })
    }

    private fun ask() {
        val q = input.text.toString().trim()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        if (q.isEmpty()) return

        val notes = NoteStore.all(this)
        if (notes.isEmpty()) {
            showMessage("هنوز یادداشتی ندارید.")
            return
        }
        val hits = NoteSearch.search(notes, q)
        if (hits.isEmpty()) {
            showMessage(
                "در یادداشت‌های شما پاسخی پیدا نشد.\n\n" +
                        "این جست‌وجو بر پایه‌ی کلمات است. اگر جواب را یادداشت کرده‌اید، " +
                        "سؤال را با کلمات نزدیک به خود یادداشت بپرسید."
            )
            return
        }

        val qt = NoteSearch.queryTokens(q)
        results.removeAllViews()
        for ((i, h) in hits.withIndex()) {
            results.addView(resultCard(h, qt, i == 0), LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) })
        }
    }

    /** کلمات مرتبط با سؤال را داخل جمله پررنگ می‌کند. */
    private fun highlight(sentence: String, qt: List<String>): CharSequence {
        val sp = SpannableString(sentence)
        var pos = 0
        for (word in sentence.split(' ')) {
            val start = sentence.indexOf(word, pos)
            if (start < 0) continue
            pos = start + word.length
            val t = NoteSearch.tokens(word)
            if (t.isNotEmpty() && qt.any { q -> NoteSearch.matches(q, t[0]) }) {
                sp.setSpan(StyleSpan(Typeface.BOLD), start, start + word.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sp.setSpan(BackgroundColorSpan(0x55D9A441), start, start + word.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        return sp
    }

    private fun resultCard(h: NoteSearch.Hit, qt: List<String>, first: Boolean): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 16)
            elevation = dp(2).toFloat()
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        c.addView(TextView(this).apply {
            text = if (first) "پاسخ احتمالی" else "یادداشت مرتبط"
            textSize = 12.5f
            setTextColor(if (first) cGold else cAccent)
            typeface = Typeface.DEFAULT_BOLD
        })
        c.addView(TextView(this).apply {
            text = highlight(h.sentence, qt)
            textSize = if (first) 18f else 16f
            setTextColor(cText)
            setLineSpacing(dp(3).toFloat(), 1f)
            setTextIsSelectable(true)
            setPadding(0, dp(6), 0, dp(6))
        })
        val where = Boards.name(this, h.note.board)
        c.addView(TextView(this).apply {
            text = "از یادداشت " + Jalali.format(h.note.created, false) + "  ·  لیست «" + where + "»"
            textSize = 12f
            setTextColor(cSub)
        })
        if (first && h.note.text.trim() != h.sentence.trim()) {
            c.addView(TextView(this).apply {
                text = highlight(h.note.text.take(500), qt)
                textSize = 14f
                setTextColor(cSub)
                setLineSpacing(dp(3).toFloat(), 1f)
                setPadding(0, dp(8), 0, 0)
            })
        }
        return c
    }
}
