package com.example.notewidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar

data class Note(
    val id: Long,
    val text: String,
    val created: Long,
    val alarm: Long,
    val done: Boolean = false,
    val audio: String = "",      // مسیر فایل صدای ضبط‌شده (برای یادداشت صوتی)
    val transcript: String = "", // متن پیاده‌شده‌ی صدا (اختیاری)
    val repeat: Int = 0,         // روزهای هفته‌ی تکرار آلارم (بیت ۰ = یکشنبه … بیت ۶ = شنبه)؛ ۰ = بدون تکرار
    val rmin: Int = -1,          // ساعت تکرار بر حسب دقیقه از ابتدای روز (فقط برای آلارم تکراری)
    val board: Int = 0           // شماره‌ی لیست (ویجت)؛ ۰ = لیست پیش‌فرض
)

/** محاسبه‌ی زمان آلارم‌های تکراری. */
object Repeat {
    const val ALL = 127

    fun bit(dayOfWeek: Int) = 1 shl (dayOfWeek - 1)      // Calendar.SUNDAY=1 → بیت ۰

    /** اولین زمانِ ساعت:دقیقه‌ی [minuteOfDay] که از [after] دیرتر است و روزش در [mask] باشد. */
    fun next(mask: Int, minuteOfDay: Int, after: Long): Long {
        val c = Calendar.getInstance().apply {
            timeInMillis = after
            set(Calendar.HOUR_OF_DAY, minuteOfDay / 60)
            set(Calendar.MINUTE, minuteOfDay % 60)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        for (i in 0..8) {
            if (c.timeInMillis > after && (mask and bit(c.get(Calendar.DAY_OF_WEEK))) != 0) return c.timeInMillis
            c.add(Calendar.DAY_OF_MONTH, 1)
        }
        return after + 24 * 3600_000L
    }

    /** اولین زمان تکرار که از شروع انتخاب‌شده کمتر نباشد و گذشته هم نباشد. */
    fun first(mask: Int, chosen: Long, now: Long): Long {
        val c = Calendar.getInstance().apply { timeInMillis = chosen }
        val min = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        return next(mask, min, maxOf(chosen - 1, now))
    }

    fun label(mask: Int): String {
        if (mask == ALL) return "هر روز"
        val names = (1..7).filter { mask and bit(it) != 0 }
            .sortedBy { (it + 0) % 7 }      // شنبه اول
            .map { Jalali.weekdayNameOf(it) }
        return "هر " + names.joinToString(" و ")
    }
}

object NoteStore {
    private const val PREFS = "notes"
    private const val KEY = "data"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun fromJson(o: JSONObject) = Note(
        o.getLong("id"), o.getString("text"), o.getLong("created"),
        o.optLong("alarm", 0L), o.optBoolean("done", false), o.optString("audio", ""),
        o.optString("transcript", ""), o.optInt("repeat", 0), o.optInt("rmin", -1), o.optInt("board", 0)
    )

    private fun toJson(n: Note) = JSONObject()
        .put("id", n.id).put("text", n.text).put("created", n.created).put("alarm", n.alarm)
        .put("done", n.done).put("audio", n.audio).put("transcript", n.transcript)
        .put("repeat", n.repeat).put("rmin", n.rmin).put("board", n.board)

    @Synchronized
    fun all(ctx: Context): List<Note> {
        val arr = JSONArray(prefs(ctx).getString(KEY, "[]") ?: "[]")
        return (0 until arr.length()).map { fromJson(arr.getJSONObject(it)) }.sortedByDescending { it.created }
    }

    private fun save(ctx: Context, list: List<Note>) {
        val arr = JSONArray()
        list.forEach { arr.put(toJson(it)) }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    fun get(ctx: Context, id: Long): Note? = all(ctx).firstOrNull { it.id == id }

    @Synchronized
    fun add(
        ctx: Context,
        text: String,
        audio: String = "",
        id: Long = System.currentTimeMillis(),
        transcript: String = "",
        board: Int = 0
    ): Note {
        val n = Note(id, text, id, 0L, false, audio, transcript, 0, -1, board)
        save(ctx, all(ctx) + n)
        return n
    }

    @Synchronized
    fun delete(ctx: Context, id: Long) {
        val note = all(ctx).firstOrNull { it.id == id }
        if (note != null && note.audio.isNotEmpty()) {
            try { File(note.audio).delete() } catch (e: Exception) { /* مهم نیست */ }
        }
        save(ctx, all(ctx).filter { it.id != id })
    }

    /** زمان بعدی آلارم را عوض می‌کند (تنظیم تکرار دست نمی‌خورد؛ با time=0 تکرار هم پاک می‌شود). */
    @Synchronized
    fun setAlarm(ctx: Context, id: Long, time: Long) {
        save(ctx, all(ctx).map {
            if (it.id != id) it
            else if (time == 0L) it.copy(alarm = 0L, repeat = 0, rmin = -1)
            else it.copy(alarm = time)
        })
    }

    /** آلارم همراه با تکرار؛ [repeat]=۰ یعنی فقط یک بار. */
    @Synchronized
    fun setAlarmRepeat(ctx: Context, id: Long, time: Long, repeat: Int) {
        val c = Calendar.getInstance().apply { timeInMillis = time }
        val min = c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
        save(ctx, all(ctx).map {
            if (it.id != id) it
            else it.copy(alarm = time, repeat = repeat, rmin = if (repeat != 0) min else -1)
        })
    }

    @Synchronized
    fun updateText(ctx: Context, id: Long, text: String) {
        save(ctx, all(ctx).map { if (it.id == id) it.copy(text = text) else it })
    }

    @Synchronized
    fun updateTranscript(ctx: Context, id: Long, transcript: String) {
        save(ctx, all(ctx).map { if (it.id == id) it.copy(transcript = transcript) else it })
    }

    @Synchronized
    fun toggleDone(ctx: Context, id: Long) {
        save(ctx, all(ctx).map { if (it.id == id) it.copy(done = !it.done) else it })
    }

    /** یادداشت‌های یک لیست به لیست دیگر منتقل می‌شوند (مثلاً هنگام حذف لیست). */
    @Synchronized
    fun moveBoard(ctx: Context, from: Int, to: Int) {
        save(ctx, all(ctx).map { if (it.board == from) it.copy(board = to) else it })
    }

    // ---------- پشتیبان‌گیری (فقط متن و تنظیمات؛ فایل صدا همراه نیست) ----------

    fun exportJson(ctx: Context): String {
        val notes = JSONArray()
        all(ctx).forEach { notes.put(toJson(it.copy(audio = ""))) }
        return JSONObject().put("app", "taghva.nazm").put("version", 1)
            .put("notes", notes).put("boards", Boards.toJson(ctx)).toString()
    }

    /** پشتیبان را با یادداشت‌های فعلی ادغام می‌کند؛ تعداد یادداشت‌های جدید را برمی‌گرداند. */
    @Synchronized
    fun importJson(ctx: Context, json: String): Int {
        val o = JSONObject(json)
        if (o.optString("app") != "taghva.nazm") throw IllegalArgumentException("not a backup")
        Boards.fromJson(ctx, o.optJSONArray("boards"))
        val have = all(ctx).map { it.id }.toSet()
        val arr = o.getJSONArray("notes")
        val added = mutableListOf<Note>()
        for (i in 0 until arr.length()) {
            val n = fromJson(arr.getJSONObject(i))
            if (n.id !in have) added.add(n)
        }
        save(ctx, all(ctx) + added)
        val now = System.currentTimeMillis()
        added.forEach { n ->
            if (n.alarm > now) AlarmScheduler.schedule(ctx, n.id, n.alarm)
        }
        return added.size
    }
}
