package com.example.notewidget

import java.util.Calendar

/**
 * تحلیل متن یادداشت صوتی: اگر بگویید «آلارم …» و بعد زمان، آلارم همان زمان تنظیم می‌شود.
 * نمونه‌ها:
 *  «آلارم سه شنبه ۱۹ آبان ساعت ۱۲ و ۳۰ دقیقه»   ← تاریخ شمسی
 *  «آلارم فردا / پس فردا ساعت هشت و نیم صبح»
 *  «آلارم سه شنبه ساعت ۱۲ و ۳۰»                  ← اولین سه‌شنبه
 *  «آلارم سه شنبه ها ساعت ۱۲ و نیم»              ← تکرار هر سه‌شنبه
 *  «آلارم هر روز ساعت ۱۷:۳۰»                      ← تکرار روزانه
 *  «آلارم ده دقیقه دیگر»
 * کلمه‌ی «آلارم» و عبارت زمان از متن یادداشت حذف می‌شود.
 */
object VoiceAlarm {

    class Result(val time: Long, val repeat: Int, val text: String)

    private val keywords = setOf("الارم", "alarm")
    private val fillers = setOf(
        "را", "رو", "برای", "برا", "بزن", "بذار", "بزار", "بگذار", "بگذارید", "تنظیم",
        "کن", "کنید", "لطفا", "ست", "بده", "بگذارم"
    )
    private val units = mapOf(
        "صفر" to 0, "یک" to 1, "دو" to 2, "سه" to 3, "چهار" to 4, "پنج" to 5,
        "شش" to 6, "شیش" to 6, "هفت" to 7, "هشت" to 8, "نه" to 9
    )
    private val teens = mapOf(
        "ده" to 10, "یازده" to 11, "دوازده" to 12, "سیزده" to 13, "چهارده" to 14,
        "پانزده" to 15, "شانزده" to 16, "هفده" to 17, "هجده" to 18, "نوزده" to 19
    )
    private val tens = mapOf("بیست" to 20, "سی" to 30, "چهل" to 40, "پنجاه" to 50)
    private val ordinals = mapOf(
        "یکم" to 1, "اول" to 1, "دوم" to 2, "سوم" to 3, "چهارم" to 4, "پنجم" to 5, "ششم" to 6,
        "هفتم" to 7, "هشتم" to 8, "نهم" to 9, "دهم" to 10, "یازدهم" to 11, "دوازدهم" to 12,
        "سیزدهم" to 13, "چهاردهم" to 14, "پانزدهم" to 15, "شانزدهم" to 16, "هفدهم" to 17,
        "هجدهم" to 18, "نوزدهم" to 19, "بیستم" to 20, "سیم" to 30
    )
    // «آبان» و «آذر» بعد از نرمال‌سازی (آ←ا) همین‌طور نوشته می‌شوند
    private val months = mapOf(
        "فروردین" to 1, "اردیبهشت" to 2, "خرداد" to 3, "تیر" to 4, "مرداد" to 5, "شهریور" to 6,
        "مهر" to 7, "ابان" to 8, "اذر" to 9, "دی" to 10, "بهمن" to 11, "اسفند" to 12
    )
    // مقدار = Calendar.DAY_OF_WEEK
    private val wd1 = mapOf(
        "شنبه" to Calendar.SATURDAY, "یکشنبه" to Calendar.SUNDAY, "دوشنبه" to Calendar.MONDAY,
        "سهشنبه" to Calendar.TUESDAY, "چهارشنبه" to Calendar.WEDNESDAY,
        "پنجشنبه" to Calendar.THURSDAY, "جمعه" to Calendar.FRIDAY
    )
    private val wd2 = mapOf(
        ("یک" to "شنبه") to Calendar.SUNDAY, ("دو" to "شنبه") to Calendar.MONDAY,
        ("سه" to "شنبه") to Calendar.TUESDAY, ("چهار" to "شنبه") to Calendar.WEDNESDAY,
        ("پنج" to "شنبه") to Calendar.THURSDAY
    )
    private val hmRegex = Regex("^(\\d{1,2}):(\\d{2})$")
    private val ordRegex = Regex("^(\\d{1,2})(ام|م)$")
    private val laterWords = setOf("دیگر", "دیگه", "بعد")

    private class Num(val v: Int, val nx: Int, val hm: Int = -1)
    private class Wd(val dow: Int, val nx: Int, val plural: Boolean)
    private class Tm(val h: Int, val m: Int, val nx: Int)

    private fun norm(s: String): String {
        val sb = StringBuilder()
        for (c0 in s) {
            if (c0 in 'ً'..'ٟ') continue            // اعراب
            val c = when (c0) {
                'ي' -> 'ی'
                'ك' -> 'ک'
                'آ', 'أ', 'إ' -> 'ا'
                'ة' -> 'ه'
                in '۰'..'۹' -> '0' + (c0 - '۰')
                in '٠'..'٩' -> '0' + (c0 - '٠')
                else -> c0
            }
            if (c.isLetterOrDigit() || c == ':') sb.append(c.lowercaseChar())
        }
        return sb.toString()
    }

    private fun num(t: List<String>, i: Int, ord: Boolean = false): Num? {
        if (i < 0 || i >= t.size) return null
        val w = t[i]
        hmRegex.matchEntire(w)?.let { return Num(it.groupValues[1].toInt(), i + 1, it.groupValues[2].toInt()) }
        if (w.length <= 2 && w.isNotEmpty() && w.all { it.isDigit() }) return Num(w.toInt(), i + 1)
        if (ord) {
            ordRegex.matchEntire(w)?.let { return Num(it.groupValues[1].toInt(), i + 1) }
            ordinals[w]?.let { return Num(it, i + 1) }
        }
        units[w]?.let { return Num(it, i + 1) }
        teens[w]?.let { return Num(it, i + 1) }
        tens[w]?.let { base ->
            if (i + 2 < t.size && t[i + 1] == "و") {
                val u = units[t[i + 2]]
                if (u != null && u > 0) return Num(base + u, i + 3)
            }
            return Num(base, i + 1)
        }
        return null
    }

    /** دقیقه‌ی بعد از ساعت: «و نیم»، «و ربع»، «و سی دقیقه». خروجی: (دقیقه، اندیس بعدی). */
    private fun minutes(t: List<String>, j: Int): Pair<Int, Int> {
        val a = t.getOrNull(j)
        if (a == "ونیم") return 30 to j + 1
        if (a == "و" && j + 1 < t.size) {
            val x = t[j + 1]
            if (x == "نیم" || x == "نیمه") return 30 to j + 2
            if (x == "ربع") return 15 to j + 2
            val m = num(t, j + 1)
            if (m != null && m.hm < 0 && m.v in 0..59) {
                var nx = m.nx
                if (t.getOrNull(nx) == "دقیقه") nx++
                return m.v to nx
            }
        } else if (a == "نیم") {
            return 30 to j + 1
        } else if (a != null && a.length == 2 && a.all { it.isDigit() } && a.toInt() in 0..59) {
            return a.toInt() to j + 1
        }
        return 0 to j
    }

    private fun minus(h: Int, d: Int): Pair<Int, Int> {
        val tot = ((h * 60 - d) % 1440 + 1440) % 1440
        return tot / 60 to tot % 60
    }

    private fun timeAt(t: List<String>, i: Int): Tm? {
        if (t.getOrNull(i) == "ربع" && t.getOrNull(i + 1) == "به") {
            val h = num(t, i + 2)
            if (h != null && h.v in 1..24) {
                val (a, b) = minus(h.v, 15)
                return Tm(a, b, h.nx)
            }
        }
        val a = num(t, i) ?: return null
        if (a.hm >= 0) {
            return if (a.v in 0..23 && a.hm in 0..59) Tm(a.v, a.hm, a.nx) else null
        }
        if (t.getOrNull(a.nx) == "دقیقه" && t.getOrNull(a.nx + 1) == "به") {
            val h = num(t, a.nx + 2)
            if (h != null && h.v in 1..24 && a.v in 1..59) {
                val (x, y) = minus(h.v, a.v)
                return Tm(x, y, h.nx)
            }
        }
        if (a.v !in 0..24) return null
        val (m, nx) = minutes(t, a.nx)
        return Tm(a.v % 24, m, nx)
    }

    private fun weekdayAt(t: List<String>, i: Int): Wd? {
        val w = t.getOrNull(i) ?: return null
        val d: Int
        val nx: Int
        val two = t.getOrNull(i + 1)?.let { wd2[w to it] }
        if (two != null) {
            d = two
            nx = i + 2
        } else if (wd1.containsKey(w)) {
            d = wd1.getValue(w)
            nx = i + 1
        } else {
            if (w.endsWith("ها") && wd1.containsKey(w.dropLast(2))) {
                return Wd(wd1.getValue(w.dropLast(2)), i + 1, true)
            }
            return null
        }
        if (t.getOrNull(nx) == "ها") return Wd(d, nx + 1, true)
        return Wd(d, nx, false)
    }

    /** نتیجه‌ی تحلیل، یا null اگر در متن «آلارم + زمان» نبود. */
    fun parse(text: String, now: Long): Result? {
        val spans = Regex("[^\\s\\u200c]+").findAll(text).map { it.range }.toList()
        val t = spans.map { norm(text.substring(it.first, it.last + 1)) }
        val n = t.size
        val k = t.indexOfFirst { it in keywords }
        if (k < 0) return null

        val used = HashSet<Int>()
        used.add(k)
        var dayOff = -1
        var jdate: IntArray? = null           // [سال یا -1، ماه، روز]
        val weekdays = ArrayList<Int>()
        var plural = false
        var every = false
        var daily = false
        var hour = -1
        var minute = 0
        var pm = false
        var noon = false
        var night = false
        var am = false
        var rel = -1
        var lastWd = false

        var i = k + 1
        while (i < n) {
            val w = t[i]
            if (w.isEmpty() || w in fillers) {
                used.add(i); i++; continue
            }
            // زمان نسبی
            if (w == "ربع" && t.getOrNull(i + 1) in laterWords) {
                rel = 15; used.add(i); used.add(i + 1); i += 2; continue
            }
            if (w == "نیم" && t.getOrNull(i + 1) == "ساعت" && t.getOrNull(i + 2) in laterWords) {
                rel = 30; used.add(i); used.add(i + 1); used.add(i + 2); i += 3; continue
            }
            val a = num(t, i)
            if (a != null && a.hm < 0 && (t.getOrNull(a.nx) == "دقیقه" || t.getOrNull(a.nx) == "ساعت") &&
                t.getOrNull(a.nx + 1) in laterWords
            ) {
                rel = if (t[a.nx] == "دقیقه") a.v else a.v * 60
                for (x in i..a.nx + 1) used.add(x)
                i = a.nx + 2; continue
            }
            // تکرار
            if (w == "هرروز" || w == "روزانه") {
                daily = true; used.add(i); i++; continue
            }
            if (w == "هر") {
                if (t.getOrNull(i + 1) == "روز") {
                    daily = true; used.add(i); used.add(i + 1); i += 2; continue
                }
                if (weekdayAt(t, i + 1) != null) {
                    every = true; used.add(i); i++; continue
                }
                break
            }
            // روز هفته
            val wd = weekdayAt(t, i)
            if (wd != null) {
                weekdays.add(wd.dow)
                plural = plural || wd.plural
                for (x in i until wd.nx) used.add(x)
                i = wd.nx; lastWd = true; continue
            }
            if (w == "و" && lastWd && weekdayAt(t, i + 1) != null) {
                used.add(i); i++; continue
            }
            lastWd = false
            // امروز / فردا / پس فردا
            if (w == "امروز") { dayOff = 0; used.add(i); i++; continue }
            if (w == "فردا") { dayOff = 1; used.add(i); i++; continue }
            if (w == "پسفردا") { dayOff = 2; used.add(i); i++; continue }
            if (w == "پس" && t.getOrNull(i + 1) == "فردا") {
                dayOff = 2; used.add(i); used.add(i + 1); i += 2; continue
            }
            if (w == "امشب") { dayOff = 0; night = true; used.add(i); i++; continue }
            // صبح / ظهر / عصر / شب
            if (w == "بعد" && t.getOrNull(i + 1) == "از" && t.getOrNull(i + 2) == "ظهر") {
                pm = true; used.add(i); used.add(i + 1); used.add(i + 2); i += 3; continue
            }
            if (w == "بعدازظهر" || w == "عصر") { pm = true; used.add(i); i++; continue }
            if (w == "ظهر") { noon = true; used.add(i); i++; continue }
            if (w == "صبح" || w == "بامداد") { am = true; used.add(i); i++; continue }
            if (w == "شب") { night = true; used.add(i); i++; continue }
            // تاریخ شمسی: روز + نام ماه (+ سال)
            val dn = num(t, i, true)
            val monthName = if (dn != null) t.getOrNull(dn.nx) else null
            if (dn != null && monthName != null && dn.hm < 0 && dn.v in 1..31 && months.containsKey(monthName)) {
                val jm = months.getValue(monthName)
                var nx = dn.nx + 1
                var jy = -1
                val y = t.getOrNull(nx)
                if (y != null && y.length == 4 && y.all { it.isDigit() } && y.toInt() in 1300..1500) {
                    jy = y.toInt(); nx++
                }
                jdate = intArrayOf(jy, jm, dn.v)
                for (x in i until nx) used.add(x)
                i = nx; continue
            }
            // ساعت
            if (w == "ساعت") {
                used.add(i); i++
                val tt = timeAt(t, i)
                if (tt != null && hour < 0) {
                    hour = tt.h; minute = tt.m
                    for (x in i until tt.nx) used.add(x)
                    i = tt.nx
                }
                continue
            }
            if (hour < 0) {
                val tt = timeAt(t, i)
                if (tt != null) {
                    hour = tt.h; minute = tt.m
                    for (x in i until tt.nx) used.add(x)
                    i = tt.nx; continue
                }
            }
            break
        }

        // ---------- محاسبه‌ی زمان ----------
        var resultTime = -1L
        var resultMask = 0
        if (rel >= 0) {
            resultTime = now + rel * 60_000L
        } else if (hour >= 0) {
            val h = hour
            val m = minute
            var mask = 0
            if (daily) mask = Repeat.ALL
            else if (weekdays.isNotEmpty() && (plural || every)) {
                for (d in weekdays) mask = mask or Repeat.bit(d)
            }
            val dated = mask != 0 || jdate != null || weekdays.isNotEmpty() || dayOff >= 0
            val hh: Int = if (h > 12 || h == 0) h
            else if (pm) (if (h < 12) h + 12 else 12)
            else if (noon) (if (h in 1..5) h + 12 else h)
            else if (night) (if (h == 12) 0 else if (h >= 6) h + 12 else h)
            else if (am) (if (h == 12) 0 else h)
            else if (dated) h
            else -1

            val today = Calendar.getInstance().apply {
                timeInMillis = now
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            fun at(addDays: Int, hr: Int): Long {
                val c = today.clone() as Calendar
                c.add(Calendar.DAY_OF_MONTH, addDays)
                c.set(Calendar.HOUR_OF_DAY, hr)
                c.set(Calendar.MINUTE, m)
                return c.timeInMillis
            }
            val hr = if (hh >= 0) hh else h

            var when_ = -1L
            if (mask != 0) {
                when_ = Repeat.next(mask, hr * 60 + m, now)
            } else if (jdate != null) {
                val jd = jdate
                val curY = Jalali.fromGregorian(
                    today.get(Calendar.YEAR), today.get(Calendar.MONTH) + 1, today.get(Calendar.DAY_OF_MONTH)
                )[0]
                fun mk(y: Int): Long {
                    val g = Jalali.toGregorian(y, jd[1], jd[2])
                    val c = Calendar.getInstance()
                    c.set(g[0], g[1] - 1, g[2], hr, m, 0)
                    c.set(Calendar.MILLISECOND, 0)
                    return c.timeInMillis
                }
                when_ = mk(if (jd[0] > 0) jd[0] else curY)
                if (when_ <= now && jd[0] <= 0) when_ = mk(curY + 1)
                if (when_ <= now) when_ = -1L
            } else if (weekdays.isNotEmpty()) {
                var best = -1L
                for (d in weekdays) {
                    for (add in 0..7) {
                        val c = at(add, hr)
                        val dow = Calendar.getInstance().apply { timeInMillis = c }.get(Calendar.DAY_OF_WEEK)
                        if (dow == d && c > now) {
                            if (best < 0 || c < best) best = c
                            break
                        }
                    }
                }
                when_ = best
            } else if (dayOff >= 0) {
                when_ = at(dayOff, hr)
                if (when_ <= now) when_ = -1L
            } else if (hh >= 0) {
                when_ = at(0, hh)
                if (when_ <= now) when_ = at(1, hh)
            } else {
                val a1 = at(0, h % 12)
                val b1 = at(0, h % 12 + 12)
                val c = listOf(a1, b1).filter { it > now }
                when_ = if (c.isEmpty()) at(1, h % 12) else c.min()
            }
            if (when_ > 0) {
                resultTime = when_
                resultMask = mask
            }
        }
        if (resultTime < 0) return null

        // ---------- حذف «آلارم» و عبارت زمان از متن ----------
        val sb = StringBuilder()
        var prev = 0
        for (idx in spans.indices) {
            val r = spans[idx]
            val sep = text.substring(prev, r.first)
            prev = r.last + 1
            if (idx in used) continue
            sb.append(sep).append(text.substring(r.first, r.last + 1))
        }
        val cleaned = sb.toString().trim { it.isWhitespace() || it in " ،,.؟?!:؛;-‌" }
        return Result(resultTime, resultMask, cleaned)
    }
}
