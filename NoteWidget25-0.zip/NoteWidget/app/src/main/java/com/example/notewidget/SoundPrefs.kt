package com.example.notewidget

import android.content.Context
import android.media.RingtoneManager
import android.net.Uri

/** صدای انتخاب‌شده‌ی آلارم. کلید نبود = صدای پیش‌فرض گوشی؛ رشته‌ی خالی = بی‌صدا (فقط لرزش). */
object SoundPrefs {
    private const val PREFS = "settings"
    private const val KEY = "sound"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun resolve(ctx: Context): Uri? {
        val s = prefs(ctx).getString(KEY, null)
        if (s == null) {
            return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        }
        if (s.isEmpty()) return null
        return Uri.parse(s)
    }

    fun save(ctx: Context, uri: Uri?) {
        prefs(ctx).edit().putString(KEY, uri?.toString() ?: "").apply()
    }

    fun label(ctx: Context): String {
        val s = prefs(ctx).getString(KEY, null)
        if (s == null) return "پیش‌فرض گوشی"
        if (s.isEmpty()) return "بی‌صدا (فقط لرزش)"
        return try {
            RingtoneManager.getRingtone(ctx, Uri.parse(s))?.getTitle(ctx) ?: "انتخاب‌شده"
        } catch (e: Exception) {
            "انتخاب‌شده"
        }
    }
}
