package com.example.notewidget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.RingtoneManager

object AlarmNotifier {
    const val CHANNEL_SILENT = "alarm_silent_v3"
    const val CHANNEL_SOUND = "alarm_sound_v3"

    fun alarmAttributes(): AudioAttributes =
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)

        // کانال بی‌صدا: صدا و لرزش را AlarmService پخش می‌کند
        val silent = NotificationChannel(
            CHANNEL_SILENT, "آلارم یادداشت‌ها", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            setSound(null, null)
            enableVibration(false)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }

        // کانال پشتیبان (اگر سرویس اجازه‌ی شروع نگرفت): صدا از خود اعلان
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val sound = NotificationChannel(
            CHANNEL_SOUND, "آلارم یادداشت‌ها (پشتیبان)", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            enableVibration(true)
            setSound(uri, alarmAttributes())
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }
        nm.createNotificationChannel(silent)
        nm.createNotificationChannel(sound)
    }

    fun build(ctx: Context, id: Long, note: Note, channel: String): Notification {
        val base = (id % 100_000_000L).toInt() * 5
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        // صفحه‌ی آلارم (تعویق ۵/۱۰/۱۵ دقیقه یا رد آلارم)
        val open = PendingIntent.getActivity(
            ctx, base + 3,
            Intent(ctx, AlarmDialogActivity::class.java)
                .putExtra("id", id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            flags
        )

        fun action(k: Int, minutes: Int, label: String): Notification.Action {
            val pi = PendingIntent.getBroadcast(
                ctx, base + k,
                Intent(ctx, AlarmActionReceiver::class.java)
                    .putExtra("id", id).putExtra("minutes", minutes),
                flags
            )
            return Notification.Action.Builder(
                Icon.createWithResource(ctx, R.drawable.ic_alarm), label, pi
            ).build()
        }

        // کنار زدن اعلان = رد آلارم
        val deleted = PendingIntent.getBroadcast(
            ctx, base + 4,
            Intent(ctx, AlarmActionReceiver::class.java)
                .putExtra("id", id).putExtra("minutes", 0),
            flags
        )

        return Notification.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_alarm)
            .setContentTitle("یادآوری یادداشت")
            .setContentText(note.text)
            .setStyle(Notification.BigTextStyle().bigText(note.text))
            .setContentIntent(open)
            .setFullScreenIntent(open, true)
            .setDeleteIntent(deleted)
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .addAction(action(0, 5, "۵ دقیقه"))
            .addAction(action(1, 10, "۱۰ دقیقه"))
            .addAction(action(2, 15, "۱۵ دقیقه"))
            .build()
    }
}
