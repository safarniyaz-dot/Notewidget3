package com.example.notewidget

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("id", 0L)
        val note = NoteStore.get(ctx, id) ?: return

        AlarmNotifier.ensureChannels(ctx)
        try {
            // سرویس صدا/لرزش را پخش می‌کند و اعلان را نشان می‌دهد
            ctx.startForegroundService(Intent(ctx, AlarmService::class.java).putExtra("id", id))
        } catch (e: Exception) {
            // پشتیبان: اعلان با صدای خود کانال
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.notify(
                AlarmActions.notifId(id),
                AlarmNotifier.build(ctx, id, note, AlarmNotifier.CHANNEL_SOUND)
            )
        }

        NoteStore.setAlarm(ctx, id, 0L)
        WidgetUpdater.refresh(ctx)
    }
}
