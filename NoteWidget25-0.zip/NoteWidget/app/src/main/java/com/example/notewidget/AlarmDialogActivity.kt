package com.example.notewidget

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout

/** پنجره‌ی آلارم: تعویق ۵/۱۰/۱۵ دقیقه یا رد آلارم. */
class AlarmDialogActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra("id", 0L)
        val note = NoteStore.get(this, id)
        if (note == null) {
            AlarmActions.dismiss(this, id)
            finish()
            return
        }

        val dp = resources.displayMetrics.density
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * dp).toInt(), (8 * dp).toInt(), (16 * dp).toInt(), 0)
        }

        val dialog = AlertDialog.Builder(this)
            .setTitle("یادآوری یادداشت")
            .setMessage(note.text)
            .setView(box)
            .create()

        fun addButton(label: String, onClick: () -> Unit) {
            box.addView(Button(this).apply {
                text = label
                setOnClickListener { onClick(); dialog.dismiss() }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }

        addButton("۵ دقیقه بعد") { AlarmActions.snooze(this, id, 5) }
        addButton("۱۰ دقیقه بعد") { AlarmActions.snooze(this, id, 10) }
        addButton("۱۵ دقیقه بعد") { AlarmActions.snooze(this, id, 15) }
        addButton("رد آلارم") { AlarmActions.dismiss(this, id) }

        dialog.setCanceledOnTouchOutside(false)
        dialog.setOnDismissListener { finish() }
        dialog.show()
    }
}
