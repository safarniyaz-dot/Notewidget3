package com.example.notewidget

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StrikethroughSpan
import android.widget.RemoteViews
import android.widget.RemoteViewsService
import java.util.Calendar

/** ردیف‌های لیست: یا عنوان روز، یا یک یادداشت. */
private sealed class Row {
    data class Header(val key: Int, val label: String) : Row()
    data class Item(val note: Note) : Row()
}

class NoteWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = Factory(applicationContext)

    private class Factory(private val ctx: Context) : RemoteViewsFactory {
        private var rows: List<Row> = emptyList()

        private fun dayKey(millis: Long): Int {
            val c = Calendar.getInstance().apply { timeInMillis = millis }
            return c.get(Calendar.YEAR) * 10000 + (c.get(Calendar.MONTH) + 1) * 100 + c.get(Calendar.DAY_OF_MONTH)
        }

        override fun onCreate() {}

        override fun onDataSetChanged() {
            val now = System.currentTimeMillis()
            val todayKey = dayKey(now)
            val yesterdayKey = dayKey(
                Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -1) }.timeInMillis
            )

            val out = mutableListOf<Row>()
            var lastKey = -1
            for (n in NoteStore.all(ctx)) {          // جدیدترین اول
                val k = dayKey(n.created)
                if (k != lastKey) {
                    val prefix = when (k) {
                        todayKey -> "امروز · "
                        yesterdayKey -> "دیروز · "
                        else -> ""
                    }
                    out.add(Row.Header(k, prefix + Jalali.formatDay(n.created)))
                    lastKey = k
                }
                out.add(Row.Item(n))
            }
            rows = out
        }

        override fun onDestroy() {}
        override fun getCount() = rows.size
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 2
        override fun hasStableIds() = true

        override fun getItemId(position: Int): Long = when (val r = rows[position]) {
            is Row.Header -> -r.key.toLong()
            is Row.Item -> r.note.id
        }

        override fun getViewAt(position: Int): RemoteViews {
            return when (val r = rows[position]) {
                is Row.Header -> headerView(r)
                is Row.Item -> itemView(r.note)
            }
        }

        private fun headerView(h: Row.Header): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_header)
            rv.setTextViewText(R.id.header_text, h.label)
            return rv
        }

        private fun itemView(n: Note): RemoteViews {
            val rv = RemoteViews(ctx.packageName, R.layout.widget_item)

            // متن یادداشت؛ اگر انجام شده باشد خط‌خورده و کم‌رنگ
            val title: CharSequence = if (n.done) {
                SpannableString(n.text).apply {
                    setSpan(StrikethroughSpan(), 0, n.text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            } else n.text
            rv.setTextViewText(R.id.title, title)
            rv.setTextColor(R.id.title, if (n.done) Color.parseColor("#80FFFFFF") else Color.WHITE)

            rv.setImageViewResource(
                R.id.btn_check,
                if (n.done) R.drawable.ic_box_checked else R.drawable.ic_box_empty
            )

            rv.setTextViewText(R.id.subtitle, "ایجاد: " + Jalali.format(n.created))

            if (n.alarm > 0) {
                rv.setViewVisibility(R.id.alarm_text, android.view.View.VISIBLE)
                rv.setTextViewText(R.id.alarm_text, "⏰ " + Jalali.formatLong(n.alarm))
                rv.setInt(R.id.btn_alarm, "setColorFilter", Color.parseColor("#D9A441"))
            } else {
                rv.setViewVisibility(R.id.alarm_text, android.view.View.GONE)
                rv.setInt(R.id.btn_alarm, "setColorFilter", Color.WHITE)
            }

            rv.setOnClickFillInIntent(
                R.id.btn_check, Intent().putExtra("type", "toggle").putExtra("id", n.id)
            )
            rv.setOnClickFillInIntent(
                R.id.btn_delete, Intent().putExtra("type", "delete").putExtra("id", n.id)
            )
            rv.setOnClickFillInIntent(
                R.id.btn_alarm, Intent().putExtra("type", "alarm").putExtra("id", n.id)
            )
            return rv
        }
    }
}
