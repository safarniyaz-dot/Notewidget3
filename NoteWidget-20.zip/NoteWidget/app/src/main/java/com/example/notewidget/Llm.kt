package com.example.notewidget

import android.content.Context
import java.io.File

/** مدل‌های زبانی آفلاین (Qwen3، فرمت GGUF) که روی گوشی اجرا می‌شوند. */
class LlmModel(val id: String, val title: String, val file: String, val approxMb: Int, val urls: List<String>)

object LlmModels {
    val all = listOf(
        LlmModel(
            "q06", "کوچک و سریع (Qwen3 ۰.۶B)", "Qwen3-0.6B-Q4_K_M.gguf", 400,
            listOf(
                "https://huggingface.co/unsloth/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q4_K_M.gguf",
                "https://huggingface.co/ggml-org/Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q4_K_M.gguf"
            )
        ),
        LlmModel(
            "q17", "متوسط (Qwen3 ۱.۷B) — پیشنهادی", "Qwen3-1.7B-Q4_K_M.gguf", 1300,
            listOf(
                "https://huggingface.co/unsloth/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf",
                "https://huggingface.co/ggml-org/Qwen3-1.7B-GGUF/resolve/main/Qwen3-1.7B-Q4_K_M.gguf"
            )
        ),
        LlmModel(
            "q4", "قوی‌تر و کندتر (Qwen3 ۴B)", "Qwen3-4B-Q4_K_M.gguf", 2500,
            listOf(
                "https://huggingface.co/Qwen/Qwen3-4B-GGUF/resolve/main/Qwen3-4B-Q4_K_M.gguf",
                "https://huggingface.co/unsloth/Qwen3-4B-GGUF/resolve/main/Qwen3-4B-Q4_K_M.gguf"
            )
        )
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("llm", Context.MODE_PRIVATE)
    fun dir(ctx: Context) = File(ctx.filesDir, "llm")
    fun file(ctx: Context, m: LlmModel) = File(dir(ctx), m.file)
    fun isDownloaded(ctx: Context, m: LlmModel) = file(ctx, m).let { it.exists() && it.length() > 1_000_000 }

    fun selected(ctx: Context): LlmModel? {
        val id = prefs(ctx).getString("sel", null)
        return all.firstOrNull { it.id == id && isDownloaded(ctx, it) }
            ?: all.firstOrNull { isDownloaded(ctx, it) }
    }

    fun select(ctx: Context, m: LlmModel) { prefs(ctx).edit().putString("sel", m.id).apply() }

    fun delete(ctx: Context, m: LlmModel) {
        if (Llm.loadedFile == m.file) Llm.unload()
        file(ctx, m).delete()
    }

    /** دانلود با امتحان آدرس‌های جایگزین. روی نخ پس‌زمینه صدا بزنید. */
    fun download(ctx: Context, m: LlmModel, onProgress: (Int) -> Unit) {
        var last: Throwable? = null
        for (u in m.urls) {
            try {
                Downloader.fetch(u, file(ctx, m), 0, 100, onProgress)
                select(ctx, m)
                return
            } catch (t: Throwable) {
                last = t
            }
        }
        throw RuntimeException(last?.message ?: "دانلود ناموفق")
    }
}

object Llm {
    interface Callback { fun onToken(bytes: ByteArray): Boolean }

    @Volatile var loadedFile: String? = null
        private set

    private val libOk: Boolean by lazy {
        try { System.loadLibrary("llmjni"); true } catch (t: Throwable) { false }
    }

    /** آیا کتابخانه‌ی بومی روی این گوشی (۶۴ بیتی) موجود است؟ */
    fun supported(): Boolean = libOk

    private external fun nativeLoad(libDir: String, path: String, nCtx: Int, threads: Int): Boolean
    private external fun nativeGenerate(prompt: String, maxNew: Int, cb: Callback): Int
    private external fun nativeStop()
    private external fun nativeFree()

    const val CTX = 3072

    @Synchronized
    fun load(ctx: Context, m: LlmModel): Boolean {
        if (!libOk) return false
        if (loadedFile == m.file) return true
        if (loadedFile != null) unload()
        val threads = (Runtime.getRuntime().availableProcessors() - 1).coerceIn(2, 6)
        val ok = try {
            nativeLoad(ctx.applicationInfo.nativeLibraryDir, LlmModels.file(ctx, m).path, CTX, threads)
        } catch (t: Throwable) { false }
        if (ok) loadedFile = m.file
        return ok
    }

    @Synchronized
    fun unload() {
        if (!libOk) return
        try { nativeFree() } catch (t: Throwable) { /* مهم نیست */ }
        loadedFile = null
    }

    fun stop() { if (libOk) try { nativeStop() } catch (t: Throwable) { } }

    /** تولید پاسخ؛ هر تکه‌ی متن به [onText] می‌رسد. خروجی: کد خطا (۰ = موفق، ۱ = متوقف‌شده). */
    fun generate(prompt: String, maxNew: Int, onText: (String) -> Boolean): Int {
        if (!libOk) return -1
        return nativeGenerate(prompt, maxNew, object : Callback {
            override fun onToken(bytes: ByteArray): Boolean = onText(String(bytes, Charsets.UTF_8))
        })
    }

    /** پرامپت قالب Qwen3 (با خاموش کردن «فکر کردن» برای سرعت). */
    fun buildPrompt(question: String, notes: List<Pair<String, String>>): String {
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n")
        sb.append("تو دستیار یادداشت‌های شخصی کاربر هستی. فقط بر اساس یادداشت‌های زیر به فارسی و کوتاه پاسخ بده. ")
        sb.append("اگر جواب در یادداشت‌ها نیست، دقیقاً بگو «در یادداشت‌ها پیدا نشد». چیزی از خودت اضافه نکن.<|im_end|>\n")
        sb.append("<|im_start|>user\nیادداشت‌ها:\n")
        var budget = 3000
        for ((i, n) in notes.withIndex()) {
            val t = n.second.take(minOf(budget, 1400))
            budget -= t.length
            sb.append("[").append(i + 1).append("] (").append(n.first).append(")\n").append(t).append("\n\n")
            if (budget <= 0) break
        }
        sb.append("سؤال: ").append(question).append("<|im_end|>\n")
        sb.append("<|im_start|>assistant\n<think>\n\n</think>\n\n")
        return sb.toString()
    }
}
