package com.example.notewidget

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** «از یادداشت‌هایم بپرس»: سؤال بنویسید؛ پاسخ از میان یادداشت‌ها (آفلاین) پیدا می‌شود. */
class AskActivity : Activity() {

    private val cBg = 0xFFF3F4F9.toInt()
    private val cText = 0xFF1B1F3A.toInt()
    private val cSub = 0xFF70758F.toInt()
    private val cAccent = 0xFF3B4590.toInt()
    private val cGold = 0xFFD9A441.toInt()

    private lateinit var input: EditText
    private lateinit var results: LinearLayout
    private var lastQ = ""
    private var lastHits: List<NoteSearch.Hit> = emptyList()
    private var generating = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        actionBar?.hide()
        window.statusBarColor = 0xFF2E3560.toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(cBg)
        }

        root.addView(TextView(this).apply {
            text = "🔎  از یادداشت‌هایم بپرس"
            textSize = 18f
            setTextColor(cGold)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFF2E3560.toInt(), 0xFF171A30.toInt())
            )
        })

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(6))
        }
        input = EditText(this).apply {
            hint = "سؤالتان را بنویسید، مثلاً: رمز وای‌فای چیه؟"
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setHorizontallyScrolling(false)
            maxLines = 3
            textSize = 16f
            setTextColor(cText)
            background = rounded(Color.WHITE, 14)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEARCH) { ask(); true } else false
            }
        }
        box.addView(input)
        box.addView(Button(this).apply {
            text = "بپرس"
            setTextColor(Color.WHITE)
            background = rounded(cAccent, 14)
            setOnClickListener { ask() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply { topMargin = dp(10) })
        root.addView(box)

        results = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(6), dp(14), dp(24))
        }
        root.addView(ScrollView(this).apply { addView(results) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        showMessage("سؤالتان را بنویسید. پاسخ فقط از میان یادداشت‌های خودتان پیدا می‌شود و همه‌چیز آفلاین است.")
    }

    private fun showMessage(msg: String) {
        results.removeAllViews()
        results.addView(TextView(this).apply {
            text = msg
            textSize = 14f
            setTextColor(cSub)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(6), dp(10), dp(6), dp(10))
        })
    }

    private fun ask() {
        val q = input.text.toString().trim()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        if (q.isEmpty()) return

        val notes = NoteStore.all(this)
        if (notes.isEmpty()) {
            showMessage("هنوز یادداشتی ندارید.")
            return
        }
        val hits = NoteSearch.search(notes, q)
        if (hits.isEmpty()) {
            showMessage(
                "در یادداشت‌های شما پاسخی پیدا نشد.\n\n" +
                        "این جست‌وجو بر پایه‌ی کلمات است. اگر جواب را یادداشت کرده‌اید، " +
                        "سؤال را با کلمات نزدیک به خود یادداشت بپرسید."
            )
            return
        }

        lastQ = q
        lastHits = hits
        val qt = NoteSearch.queryTokens(q)
        results.removeAllViews()
        results.addView(aiButton())
        for ((i, h) in hits.withIndex()) {
            results.addView(resultCard(h, qt, i == 0), LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) })
        }
    }

    private var aiBox: TextView? = null

    private fun aiButton(): View {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val sel = LlmModels.selected(this)
        wrap.addView(Button(this).apply {
            text = "🧠  پاسخ با هوش مصنوعی"
            setTextColor(Color.WHITE)
            background = rounded(cGold, 14)
            setOnClickListener { runAi(wrap) }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
        if (sel == null || !Llm.supported()) {
            wrap.addView(TextView(this).apply {
                text = if (!Llm.supported()) "مدل زبانی روی این گوشی پشتیبانی نمی‌شود."
                else "ابتدا از صفحه‌ی اصلی ← «مدل زبانی آفلاین» یک مدل دانلود کنید."
                textSize = 12f
                setTextColor(cSub)
                setPadding(dp(4), dp(4), dp(4), 0)
            })
        }
        return wrap
    }

    private fun runAi(wrap: LinearLayout) {
        if (generating) { Llm.stop(); return }
        val sel = LlmModels.selected(this)
        if (sel == null || !Llm.supported()) {
            android.widget.Toast.makeText(this, "ابتدا یک مدل زبانی دانلود کنید (صفحه‌ی اصلی).", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        val box = aiBox ?: TextView(this)
        aiBox = box
        (box.parent as? ViewGroup)?.removeView(box)
        box.apply {
            text = "در حال آماده‌سازی مدل… (بار اول چند ثانیه طول می‌کشد)"
            textSize = 17f
            setTextColor(cText)
            setLineSpacing(dp(4).toFloat(), 1f)
            setTextIsSelectable(true)
            background = rounded(0xFFFFF4D6.toInt(), 14)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        wrap.addView(box, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(8) })
        generating = true
        val app = applicationContext
        val notes = lastHits.map { Jalali.format(it.note.created, false) to it.note.text }
        val prompt = Llm.buildPrompt(lastQ, notes)
        Thread {
            val ok = Llm.load(app, sel)
            if (!ok) {
                runOnUiThread {
                    generating = false
                    box.text = "بارگذاری مدل ناموفق بود (شاید حافظه‌ی گوشی کم است). مدل کوچک‌تری امتحان کنید."
                }
                return@Thread
            }
            runOnUiThread { box.text = "" }
            val sb = StringBuilder()
            val rc = try {
                Llm.generate(prompt, 300) { piece ->
                    sb.append(piece)
                    runOnUiThread { box.text = sb.toString().trimStart() }
                    !isDestroyed
                }
            } catch (t: Throwable) { -9 }
            runOnUiThread {
                generating = false
                if (rc < 0) box.text = if (rc == -4) "یادداشت‌های مرتبط برای مدل بیش از حد طولانی است." else "خطا در اجرای مدل (کد $rc)"
                else if (sb.isBlank()) box.text = "پاسخی تولید نشد."
            }
        }.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (generating) Llm.stop()
    }

    /** کلمات مرتبط با سؤال را داخل جمله پررنگ می‌کند. */
    private fun highlight(sentence: String, qt: List<String>): CharSequence {
        val sp = SpannableString(sentence)
        var pos = 0
        for (word in sentence.split(' ')) {
            val start = sentence.indexOf(word, pos)
            if (start < 0) continue
            pos = start + word.length
            val t = NoteSearch.tokens(word)
            if (t.isNotEmpty() && qt.any { q -> NoteSearch.matches(q, t[0]) }) {
                sp.setSpan(StyleSpan(Typeface.BOLD), start, start + word.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sp.setSpan(BackgroundColorSpan(0x55D9A441), start, start + word.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        return sp
    }

    private fun resultCard(h: NoteSearch.Hit, qt: List<String>, first: Boolean): View {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 16)
            elevation = dp(2).toFloat()
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        c.addView(TextView(this).apply {
            text = if (first) "پاسخ احتمالی" else "یادداشت مرتبط"
            textSize = 12.5f
            setTextColor(if (first) cGold else cAccent)
            typeface = Typeface.DEFAULT_BOLD
        })
        val full = SpannableStringBuilder()
        if (h.before.isNotEmpty()) full.append("… ").append(h.before.joinToString("\n")).append("\n")
        val st = full.length
        full.append(highlight(h.sentence, qt))
        full.setSpan(StyleSpan(Typeface.BOLD), st, full.length, Spanned.SPAN_INCLUSIVE_EXCLUSIVE)
        if (h.after.isNotEmpty()) full.append("\n").append(h.after.joinToString("\n")).append(" …")
        c.addView(TextView(this).apply {
            text = full
            textSize = if (first) 17f else 15f
            setTextColor(cText)
            setLineSpacing(dp(4).toFloat(), 1f)
            setTextIsSelectable(true)
            setPadding(0, dp(6), 0, dp(6))
        })
        val where = Boards.name(this, h.note.board)
        c.addView(TextView(this).apply {
            text = "از یادداشت " + Jalali.format(h.note.created, false) + "  ·  لیست «" + where + "»"
            textSize = 12f
            setTextColor(cSub)
        })
        return c
    }
}
