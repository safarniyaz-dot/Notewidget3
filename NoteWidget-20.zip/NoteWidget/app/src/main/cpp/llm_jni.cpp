// پل JNI ساده روی llama.cpp: بارگذاری مدل GGUF، تولید متن به‌صورت جریانی.
#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <string>
#include <vector>
#include "llama.h"
#include "ggml-backend.h"

#define TAG "LlmJni"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static llama_model *g_model = nullptr;
static llama_context *g_ctx = nullptr;
static std::atomic<bool> g_stop{false};
static bool g_backend = false;

// طول بخش معتبر UTF-8 در ابتدای رشته (برای اینکه نیمه‌ی یک نویسه ارسال نشود)
static size_t valid_utf8_prefix(const std::string &s) {
    size_t n = s.size(), i = 0, last = 0;
    while (i < n) {
        unsigned char c = (unsigned char) s[i];
        size_t len = c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 1;
        if (i + len > n) break;
        i += len;
        last = i;
    }
    return last;
}

static jbyteArray to_bytes(JNIEnv *env, const std::string &s) {
    jbyteArray a = env->NewByteArray((jsize) s.size());
    env->SetByteArrayRegion(a, 0, (jsize) s.size(), (const jbyte *) s.data());
    return a;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_notewidget_Llm_nativeLoad(JNIEnv *env, jobject, jstring libDir, jstring path, jint nCtx, jint threads) {
    if (g_ctx) return JNI_TRUE;
    const char *dir = env->GetStringUTFChars(libDir, nullptr);
    const char *p = env->GetStringUTFChars(path, nullptr);
    if (!g_backend) {
        ggml_backend_load_all_from_path(dir);
        llama_backend_init();
        g_backend = true;
    }
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0;
    g_model = llama_model_load_from_file(p, mp);
    env->ReleaseStringUTFChars(libDir, dir);
    env->ReleaseStringUTFChars(path, p);
    if (!g_model) { LOGE("model load failed"); return JNI_FALSE; }
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = (uint32_t) nCtx;
    cp.n_batch = 512;
    cp.n_ubatch = 512;
    cp.n_threads = threads;
    cp.n_threads_batch = threads;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) {
        LOGE("context init failed");
        llama_model_free(g_model);
        g_model = nullptr;
        return JNI_FALSE;
    }
    return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_notewidget_Llm_nativeStop(JNIEnv *, jobject) { g_stop = true; }

extern "C" JNIEXPORT void JNICALL
Java_com_example_notewidget_Llm_nativeFree(JNIEnv *, jobject) {
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}

// پرامپت کامل (با قالب چت) را می‌گیرد؛ هر تکه متن را به callback.onToken(byte[]) می‌دهد.
// اگر callback مقدار false برگرداند یا nativeStop صدا شود متوقف می‌شود. 0 = موفق.
extern "C" JNIEXPORT jint JNICALL
Java_com_example_notewidget_Llm_nativeGenerate(JNIEnv *env, jobject, jstring prompt, jint maxNew, jobject cb) {
    if (!g_ctx || !g_model) return -1;
    g_stop = false;
    jclass cls = env->GetObjectClass(cb);
    jmethodID onTok = env->GetMethodID(cls, "onToken", "([B)Z");
    if (!onTok) return -2;

    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    const char *cp = env->GetStringUTFChars(prompt, nullptr);
    std::string text(cp);
    env->ReleaseStringUTFChars(prompt, cp);

    std::vector<llama_token> toks(text.size() + 16);
    int n = llama_tokenize(vocab, text.c_str(), (int32_t) text.size(), toks.data(), (int32_t) toks.size(), true, true);
    if (n < 0) {
        toks.resize(-n);
        n = llama_tokenize(vocab, text.c_str(), (int32_t) text.size(), toks.data(), (int32_t) toks.size(), true, true);
    }
    if (n <= 0) return -3;
    toks.resize(n);
    uint32_t nCtx = llama_n_ctx(g_ctx);
    if ((uint32_t) n + 8 >= nCtx) return -4;   // پرامپت از حافظه‌ی مدل بزرگ‌تر است

    llama_memory_clear(llama_get_memory(g_ctx), true);

    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(30));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.2f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(1234));

    // پرامپت در تکه‌های n_batch
    int pos = 0;
    const int B = 512;
    while (pos < n) {
        if (g_stop) { llama_sampler_free(smpl); return 1; }
        int cnt = std::min(B, n - pos);
        llama_batch b = llama_batch_get_one(toks.data() + pos, cnt);
        if (llama_decode(g_ctx, b) != 0) { llama_sampler_free(smpl); return -5; }
        pos += cnt;
    }

    std::string pending;
    int rc = 0;
    int total = n;
    for (int i = 0; i < maxNew && (uint32_t) total + 1 < nCtx; i++) {
        if (g_stop) { rc = 1; break; }
        llama_token t = llama_sampler_sample(smpl, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, t)) break;
        char buf[256];
        int len = llama_token_to_piece(vocab, t, buf, sizeof(buf), 0, false);
        if (len > 0) pending.append(buf, len);
        size_t ok = valid_utf8_prefix(pending);
        if (ok > 0) {
            jbyteArray arr = to_bytes(env, pending.substr(0, ok));
            jboolean cont = env->CallBooleanMethod(cb, onTok, arr);
            env->DeleteLocalRef(arr);
            pending.erase(0, ok);
            if (env->ExceptionCheck()) { env->ExceptionClear(); rc = -6; break; }
            if (!cont) { rc = 1; break; }
        }
        llama_batch b = llama_batch_get_one(&t, 1);
        if (llama_decode(g_ctx, b) != 0) { rc = -5; break; }
        total++;
    }
    llama_sampler_free(smpl);
    return rc;
}
