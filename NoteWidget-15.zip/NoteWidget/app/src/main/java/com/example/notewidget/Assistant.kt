package com.example.notewidget

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import java.util.Calendar

/** مغز دستیار صوتی (به سبک بیکسبی): جمله‌ی گفته‌شده را به یک کار آفلاین روی گوشی تبدیل می‌کند. */
object Assistant {
    class Reply(
        val text: String,                                   // متن نمایش‌داده‌شده
        val speak: String = text,                           // متنی که خوانده می‌شود
        val hits: List<NoteSearch.Hit> = emptyList(),
        val canAskAi: Boolean = false,
        val intent: Intent? = null,                         // اگر باشد، خودکار اجرا می‌شود
        val choices: List<Pair<String, Intent>> = emptyList(), // چند گزینه (مثلاً چند مخاطب هم‌نام)
        val needPerm: String? = null                        // مجوزی که باید از کاربر گرفته شود
    )

    private val noteCmd = Regex("^(?:به )?(?:یادداشت(?: جدید)?(?: کن| بنویس)?|بنویس|یادم بنداز|یادم باشه(?: که)?)\\s*(.*)$")

    private fun toks(n: String) = n.split(' ').filter { it.isNotEmpty() }
    private fun has(n: String, vararg words: String) = words.any { n.contains(it) }
    private fun squash(s: String) = NoteSearch.norm(s).replace(" ", "")

    fun handle(ctx: Context, spoken: String, now: Long = System.currentTimeMillis(), denied: Set<String> = emptySet()): Reply {
        var n = NoteSearch.norm(spoken).trim().replace(Regex("\\s+"), " ")
        if (n.isEmpty()) return Reply("چیزی نشنیدم.")
        if (n.contains("تایمر") && !n.contains("الارم")) n = n.replace("تایمر", "الارم")

        // ۱) آلارم / تایمر
        if (n.contains("الارم")) {
            val a = VoiceAlarm.parse(spoken.replace("تایمر", "آلارم"), now)
                ?: return Reply("ساعت یا تاریخ آلارم را متوجه نشدم. مثلاً بگویید: «آلارم فردا ساعت هشت».")
            val note = NoteStore.add(ctx, a.text.ifEmpty { "⏰ آلارم" })
            NoteStore.setAlarmRepeat(ctx, note.id, a.time, a.repeat)
            AlarmScheduler.schedule(ctx, note.id, a.time)
            WidgetUpdater.refresh(ctx)
            val msg = "آلارم تنظیم شد: " + Jalali.formatLong(a.time) +
                    (if (a.repeat != 0) "\n🔁 " + Repeat.label(a.repeat) else "")
            return Reply(msg, "آلارم تنظیم شد")
        }

        // ۲) یادداشت جدید
        val m = noteCmd.find(n)
        if (m != null) {
            val body = m.groupValues[1].trim()
            if (body.isEmpty()) return Reply("بگویید چه چیزی یادداشت کنم؛ مثلاً: «یادداشت شیر بخرم».")
            NoteStore.add(ctx, body)
            WidgetUpdater.refresh(ctx)
            return Reply("یادداشت شد: $body", "یادداشت شد")
        }

        val t = toks(n)

        // ۳) تماس تلفنی
        if (has(n, "زنگ بزن", "تماس بگیر", "شماره بگیر", "تلفن بزن", "زنگ بزنید")) {
            val stopW = setOf("به", "با", "را", "رو", "زنگ", "بزن", "بزنید", "تماس", "بگیر", "بگیرید", "لطفا", "تلفن", "شماره", "برای", "یه", "یک")
            val q = t.filter { it !in stopW }
            return callReply(ctx, q, denied)
        }

        // ۴) پیامک
        if (has(n, "پیام", "اس ام اس", "اسمس") && t.any { it in setOf("بفرست", "بده", "بنویس", "ارسال", "بفرستید", "بنویسید") }) {
            return smsReply(ctx, t)
        }

        // ۵) چراغ قوه
        if (has(n, "چراغ قوه", "فلش", "چراغ") && has(n, "روشن", "خاموش")) {
            return torch(ctx, !n.contains("خاموش"))
        }

        // ۶) صدا
        if (n.contains("صدا") || n.contains("ولوم")) {
            val up = has(n, "زیاد", "بلند", "بالا", "افزایش")
            val down = has(n, "کم", "پایین", "آهسته", "کاهش")
            if (up || down) {
                val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                repeat(2) {
                    am.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                        AudioManager.FLAG_SHOW_UI
                    )
                }
                return Reply(if (up) "صدا بلندتر شد." else "صدا کم شد.")
            }
        }

        // ۷) وای‌فای / بلوتوث / اینترنت (برای تغییر، صفحه‌ی تنظیمات باز می‌شود؛ اندروید اجازه‌ی خاموش و روشن مستقیم نمی‌دهد)
        if (has(n, "وای فای", "وایفای", "بلوتوث", "اینترنت") && has(n, "روشن", "خاموش", "باز کن", "تنظیمات")) {
            val i = when {
                has(n, "بلوتوث") -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                has(n, "اینترنت") && !has(n, "وای") -> Intent(Settings.ACTION_WIRELESS_SETTINGS)
                Build.VERSION.SDK_INT >= 29 -> Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                else -> Intent(Settings.ACTION_WIFI_SETTINGS)
            }
            return Reply("صفحه‌ی تنظیمات باز می‌شود؛ از آنجا روشن یا خاموش کنید.", "تنظیمات را باز می‌کنم", intent = i)
        }

        // ۸) مسیریابی
        if (has(n, "مسیریابی", "مسیر ")) {
            val stopW = setOf("مسیریابی", "مسیر", "به", "تا", "را", "رو", "برو", "ببر", "من", "لطفا", "نشان", "بده", "بزن", "برای")
            val place = t.filter { it !in stopW }.joinToString(" ")
            if (place.isEmpty()) return Reply("مقصد را بگویید؛ مثلاً: «مسیریابی به میدان آزادی».")
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place)))
            return Reply("مسیریابی به «$place»", "مسیریابی را باز می‌کنم", intent = i)
        }

        // ۹) جست‌وجو در اینترنت
        if (has(n, "جستجو کن", "سرچ کن", "گوگل کن", "جستجو")) {
            val stopW = setOf("جستجو", "سرچ", "گوگل", "کن", "در", "را", "رو", "کنید", "بکن", "اینترنت")
            val q = t.filter { it !in stopW }.joinToString(" ")
            if (q.isEmpty()) return Reply("چه چیزی را جست‌وجو کنم؟")
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
            return Reply("جست‌وجو: $q", "جست‌وجو می‌کنم", intent = i)
        }

        // ۱۰) باز کردن برنامه
        if (has(n, "باز کن", "بازکن", "اجرا کن", "باز شو", "اجرا")) {
            val stopW = setOf("باز", "بازکن", "کن", "اجرا", "شو", "را", "رو", "برنامه", "برنامه ی", "لطفا", "اپ", "اپلیکیشن", "کنید", "برو", "به")
            val q = t.filter { it !in stopW }.joinToString(" ")
            if (q.isEmpty()) return Reply("کدام برنامه را باز کنم؟")
            val app = AppFinder.find(ctx, q)
                ?: return Reply("برنامه‌ای با نام «$q» پیدا نکردم.")
            return Reply("باز می‌شود: " + app.first, "باز می‌کنم", intent = app.second)
        }

        // ۱۱) ساعت و تاریخ
        val c = Calendar.getInstance().apply { timeInMillis = now }
        if (n.contains("ساعت") && (n.contains("چند") || n.contains("چیه"))) {
            val tm = Jalali.digits("%02d:%02d".format(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)))
            return Reply("ساعت $tm است.")
        }
        if (n.contains("تاریخ") || n.contains("چندم") || (n.contains("امروز") && n.contains("روز"))) {
            return Reply("امروز " + Jalali.weekdayName(c) + " " + Jalali.formatDay(now) + " است.")
        }

        // ۱۲) پرسش از یادداشت‌ها
        val q = n.replace(Regex("یادداشت\\S*|بپرس|از "), " ").trim().ifEmpty { n }
        val notes = NoteStore.all(ctx)
        if (notes.isEmpty()) return Reply("هنوز یادداشتی ندارید.")
        val hits = NoteSearch.search(notes, q)
        if (hits.isEmpty()) {
            return Reply("در یادداشت‌ها جوابی پیدا نکردم.", canAskAi = true)
        }
        val h = hits[0]
        val ctxText = (h.before + h.sentence + h.after).joinToString("\n")
        return Reply(ctxText, h.sentence, hits, canAskAi = true)
    }

    // ---------- مخاطبین، تماس و پیامک ----------

    private val digitWords = mapOf(
        "صفر" to '0', "یک" to '1', "دو" to '2', "سه" to '3', "چهار" to '4',
        "پنج" to '5', "شش" to '6', "شیش" to '6', "هفت" to '7', "هشت" to '8', "نه" to '9'
    )

    /** اگر کلمات یک شماره‌ی تلفن باشند (رقم یا «صفر نه یک دو …») آن را برمی‌گرداند. */
    private fun asNumber(words: List<String>): String? {
        val sb = StringBuilder()
        for (w in words) {
            if (w.all { it.isDigit() }) sb.append(w)
            else sb.append(digitWords[w] ?: return null)
        }
        return if (sb.length >= 5) sb.toString() else null
    }

    private class Contact(val name: String, val number: String)

    private fun loadContacts(ctx: Context): List<Contact> {
        val out = ArrayList<Contact>()
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                ), null, null, null
            )?.use { cur ->
                while (cur.moveToNext()) {
                    val name = cur.getString(0) ?: continue
                    val num = cur.getString(1) ?: continue
                    out.add(Contact(name, num))
                }
            }
        } catch (e: Exception) { /* بدون مجوز یا خطا */ }
        return out
    }

    /** مخاطب‌هایی که بهترین تطابق را با نام گفته‌شده دارند (حداکثر ۴ نفر، بدون تکرار). */
    private fun findContacts(ctx: Context, query: String): List<Contact> {
        val qq = squash(query)
        val qTok = NoteSearch.tokens(query)
        var best = 0
        val scored = ArrayList<Pair<Int, Contact>>()
        for (c in loadContacts(ctx)) {
            val nn = squash(c.name)
            val dTok = NoteSearch.tokens(c.name)
            val s = when {
                nn == qq -> 3
                qq.length >= 2 && nn.contains(qq) -> 2
                qTok.isNotEmpty() && qTok.all { q -> dTok.any { d -> NoteSearch.matches(q, d) } } -> 1
                else -> 0
            }
            if (s > 0) { scored.add(s to c); if (s > best) best = s }
        }
        val seen = HashSet<String>()
        val res = ArrayList<Contact>()
        for ((s, c) in scored) {
            if (s != best) continue
            val key = squash(c.name)
            if (seen.add(key)) res.add(c)    // هر نام یک بار (اولین شماره)
            if (res.size >= 4) break
        }
        return res
    }

    private fun callIntent(ctx: Context, number: String, denied: Set<String>): Pair<Intent, String?> {
        val uri = Uri.fromParts("tel", number, null)
        val granted = ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        return when {
            granted -> Intent(Intent.ACTION_CALL, uri) to null
            Manifest.permission.CALL_PHONE in denied -> Intent(Intent.ACTION_DIAL, uri) to null
            else -> Intent(Intent.ACTION_DIAL, uri) to Manifest.permission.CALL_PHONE
        }
    }

    private fun callReply(ctx: Context, q: List<String>, denied: Set<String>): Reply {
        if (q.isEmpty()) return Reply("با چه کسی تماس بگیرم؟ مثلاً: «به علی زنگ بزن».")
        val number = asNumber(q)
        if (number != null) {
            val (i, perm) = callIntent(ctx, number, denied)
            if (perm != null) return Reply("برای تماس مستقیم مجوز لازم است.", needPerm = perm)
            return Reply("تماس با $number", "تماس می‌گیرم", intent = i)
        }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return if (Manifest.permission.READ_CONTACTS in denied)
                Reply("برای پیدا کردن مخاطب، مجوز «مخاطبین» لازم است (از تنظیمات برنامه روشن کنید).")
            else Reply("برای پیدا کردن مخاطب مجوز لازم است.", needPerm = Manifest.permission.READ_CONTACTS)
        }
        val name = q.joinToString(" ")
        val found = findContacts(ctx, name)
        if (found.isEmpty()) return Reply("مخاطبی با نام «$name» پیدا نکردم.")
        val (i0, perm) = callIntent(ctx, found[0].number, denied)
        if (perm != null) return Reply("برای تماس مستقیم مجوز لازم است.", needPerm = perm)
        if (found.size == 1) return Reply("تماس با " + found[0].name, "تماس می‌گیرم با " + found[0].name, intent = i0)
        return Reply(
            "چند مخاطب پیدا شد؛ یکی را انتخاب کنید:", "کدام یک؟",
            choices = found.map { it.name to callIntent(ctx, it.number, denied).first }
        )
    }

    private fun smsReply(ctx: Context, t: List<String>): Reply {
        val verbs = setOf("بفرست", "بده", "بنویس", "ارسال", "بفرستید", "بنویسید")
        val vi = t.indexOfFirst { it in verbs }
        val pre = t.subList(0, vi)
        var post = t.subList(vi + 1, t.size)
        val stopW = setOf("به", "پیام", "پیامک", "اس", "ام", "اسمس", "یک", "را", "رو", "برای", "یه")
        var nameT = pre.filter { it !in stopW }
        if (nameT.isEmpty() && post.isNotEmpty() && post[0] in setOf("به", "برای")) {
            val k = post.indexOf("که")
            if (k > 1) { nameT = post.subList(1, k); post = post.subList(k + 1, post.size) }
            else { nameT = post.subList(1, post.size); post = emptyList() }
        } else if (post.firstOrNull() == "که") post = post.subList(1, post.size)
        if (nameT.isEmpty()) return Reply("برای چه کسی پیام بفرستم؟ مثلاً: «به علی پیام بده سلام».")
        val body = post.joinToString(" ")

        fun smsIntent(number: String) = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).apply {
            if (body.isNotEmpty()) putExtra("sms_body", body)
        }
        val number = asNumber(nameT)
        if (number != null) return Reply("پیام به $number: $body", "صفحه‌ی پیام را باز می‌کنم", intent = smsIntent(number))
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return Reply("برای پیدا کردن مخاطب مجوز لازم است.", needPerm = Manifest.permission.READ_CONTACTS)
        }
        val name = nameT.joinToString(" ")
        val found = findContacts(ctx, name)
        if (found.isEmpty()) return Reply("مخاطبی با نام «$name» پیدا نکردم.")
        val shown = "پیام به " + found[0].name + (if (body.isNotEmpty()) ":\n$body" else "") +
                "\n(در صفحه‌ی پیام، خودتان «ارسال» را بزنید)"
        if (found.size == 1) return Reply(shown, "صفحه‌ی پیام را باز می‌کنم", intent = smsIntent(found[0].number))
        return Reply(
            "چند مخاطب پیدا شد؛ یکی را انتخاب کنید:", "کدام یک؟",
            choices = found.map { it.name to smsIntent(it.number) }
        )
    }

    // ---------- چراغ قوه ----------

    private fun torch(ctx: Context, on: Boolean): Reply {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                val ch = cm.getCameraCharacteristics(it)
                ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                        ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: return Reply("این گوشی چراغ قوه ندارد.")
            cm.setTorchMode(id, on)
            Reply(if (on) "چراغ قوه روشن شد." else "چراغ قوه خاموش شد.")
        } catch (e: Exception) {
            Reply("روشن کردن چراغ قوه ممکن نشد.")
        }
    }
}

/** پیدا کردن برنامه‌های نصب‌شده با نام فارسی یا انگلیسی. */
object AppFinder {
    private val aliases = mapOf(
        "واتساپ" to listOf("whatsapp"), "واتس اپ" to listOf("whatsapp"),
        "تلگرام" to listOf("telegram"), "اینستاگرام" to listOf("instagram"),
        "دوربین" to listOf("camera", "دوربین"), "گالری" to listOf("gallery", "photos", "گالری"),
        "تنظیمات" to listOf("settings", "تنظیمات"), "ماشین حساب" to listOf("calculator", "ماشین حساب"),
        "ساعت" to listOf("clock", "ساعت"), "تقویم" to listOf("calendar", "تقویم"),
        "یوتیوب" to listOf("youtube"), "کروم" to listOf("chrome"), "مرورگر" to listOf("chrome", "browser", "internet"),
        "نقشه" to listOf("maps"), "مپ" to listOf("maps"), "گوگل مپ" to listOf("maps"),
        "مخاطبین" to listOf("contacts", "مخاطبین"), "دفترچه تلفن" to listOf("contacts"),
        "پیام" to listOf("messages", "mms", "پیام"), "پیامک" to listOf("messages", "mms", "پیام"),
        "تماس" to listOf("dialer", "phone", "تلفن"), "شماره گیر" to listOf("dialer", "phone"), "تلفن" to listOf("dialer", "phone"),
        "فایل ها" to listOf("my files", "files", "myfiles"), "فایل" to listOf("my files", "files"),
        "ایمیل" to listOf("gmail", "email", "mail"), "جیمیل" to listOf("gmail"),
        "پلی استور" to listOf("play store", "vending"), "گوگل پلی" to listOf("play store", "vending"),
        "اسنپ" to listOf("snapp"), "تپسی" to listOf("tapsi"), "بله" to listOf("bale", "بله"),
        "ایتا" to listOf("eitaa", "ایتا"), "روبیکا" to listOf("rubika", "روبیکا"), "دیوار" to listOf("divar", "دیوار"),
        "یادداشت" to listOf("nazm", "note"), "ضبط صدا" to listOf("voice recorder", "recorder"),
        "موسیقی" to listOf("music", "موسیقی"), "ویدیو" to listOf("video", "ویدیو")
    )

    private fun sq(s: String) = NoteSearch.norm(s).replace(" ", "")

    /** (نام برنامه، Intent اجرا) یا null. */
    fun find(ctx: Context, query: String): Pair<String, Intent>? {
        val q = sq(query)
        if (q.isEmpty()) return null
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0).map {
            Triple(it.loadLabel(pm).toString(), it.activityInfo.packageName, sq(it.loadLabel(pm).toString()))
        }
        val keys = aliases.filterKeys { sq(it) == q || (sq(it).length >= 3 && (q.contains(sq(it)) || sq(it).contains(q) && q.length >= 3)) }
            .values.flatten().map { it.lowercase() }

        var best: Triple<String, String, String>? = null
        var bestScore = 0
        for (a in apps) {
            val label = a.first.lowercase()
            var s = 0
            if (a.third == q) s = 100
            else if (a.third.contains(q) && q.length >= 2) s = 60
            else if (q.contains(a.third) && a.third.length >= 3) s = 50
            for (k in keys) {
                if (label.contains(k) || a.second.lowercase().contains(k.replace(" ", ""))) s = maxOf(s, 70)
            }
            if (s > bestScore) { bestScore = s; best = a }
        }
        val b = best ?: return null
        val i = pm.getLaunchIntentForPackage(b.second) ?: return null
        return b.first to i
    }
}
