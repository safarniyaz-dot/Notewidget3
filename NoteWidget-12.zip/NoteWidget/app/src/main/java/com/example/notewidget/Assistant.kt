package com.example.notewidget

import android.content.Context
import java.util.Calendar

/** مغز ساده‌ی دستیار صوتی: جمله‌ی گفته‌شده را به یک کار آفلاین تبدیل می‌کند. */
object Assistant {
    class Reply(
        val text: String,            // متن نمایش‌داده‌شده
        val speak: String = text,    // متنی که خوانده می‌شود
        val hits: List<NoteSearch.Hit> = emptyList(),
        val canAskAi: Boolean = false
    )

    private val noteCmd = Regex("^(?:به )?(?:یادداشت(?: جدید)?(?: کن| بنویس)?|بنویس|یادم بنداز|یادم باشه(?: که)?)\\s*(.*)$")

    fun handle(ctx: Context, spoken: String, now: Long = System.currentTimeMillis()): Reply {
        val n = NoteSearch.norm(spoken).trim()
        if (n.isEmpty()) return Reply("چیزی نشنیدم.")

        // ۱) آلارم
        if (n.contains("الارم")) {
            val a = VoiceAlarm.parse(spoken, now)
                ?: return Reply("ساعت یا تاریخ آلارم را متوجه نشدم. مثلاً بگویید: «آلارم فردا ساعت هشت».")
            val note = NoteStore.add(ctx, a.text.ifEmpty { "⏰ آلارم" })
            NoteStore.setAlarmRepeat(ctx, note.id, a.time, a.repeat)
            AlarmScheduler.schedule(ctx, note.id, a.time)
            WidgetUpdater.refresh(ctx)
            val msg = "آلارم تنظیم شد: " + Jalali.formatLong(a.time) +
                    (if (a.repeat != 0) "\n🔁 " + Repeat.label(a.repeat) else "")
            return Reply(msg, "آلارم تنظیم شد")
        }

        // ۲) یادداشت جدید
        val m = noteCmd.find(n)
        if (m != null) {
            val body = m.groupValues[1].trim()
            if (body.isEmpty()) return Reply("بگویید چه چیزی یادداشت کنم؛ مثلاً: «یادداشت شیر بخرم».")
            NoteStore.add(ctx, body)
            WidgetUpdater.refresh(ctx)
            return Reply("یادداشت شد: $body", "یادداشت شد")
        }

        // ۳) ساعت و تاریخ
        val c = Calendar.getInstance().apply { timeInMillis = now }
        if (n.contains("ساعت") && (n.contains("چند") || n.contains("چیه"))) {
            val t = Jalali.digits("%02d:%02d".format(c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)))
            return Reply("ساعت $t است.")
        }
        if (n.contains("تاریخ") || n.contains("چندم") || (n.contains("امروز") && n.contains("روز"))) {
            return Reply("امروز " + Jalali.weekdayName(c) + " " + Jalali.formatDay(now) + " است.")
        }

        // ۴) پرسش از یادداشت‌ها
        val q = n.replace(Regex("یادداشت\\S*|بپرس|از "), " ").trim().ifEmpty { n }
        val notes = NoteStore.all(ctx)
        if (notes.isEmpty()) return Reply("هنوز یادداشتی ندارید.")
        val hits = NoteSearch.search(notes, q)
        if (hits.isEmpty()) {
            return Reply("در یادداشت‌ها جوابی پیدا نکردم.", canAskAi = true)
        }
        val h = hits[0]
        val ctxText = (h.before + h.sentence + h.after).joinToString("\n")
        return Reply(ctxText, h.sentence, hits, canAskAi = true)
    }
}
