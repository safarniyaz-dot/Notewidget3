package com.example.notewidget

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.vosk.Recognizer
import java.util.Locale

/** دستیار صوتی آفلاین: گوش می‌دهد (Vosk)، دستور را اجرا می‌کند و پاسخ را نشان می‌دهد. */
class AssistantActivity : Activity() {

    private val cCard = 0xFF22263F.toInt()
    private val cText = 0xFFFFFFFF.toInt()
    private val cSub = 0xFFB3B8D6.toInt()
    private val cGold = 0xFFD9A441.toInt()
    private val cAccent = 0xFF3B4590.toInt()

    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var answer: TextView
    private lateinit var btnRow: LinearLayout

    @Volatile private var listening = false
    @Volatile private var closed = false
    private var lastText = ""
    private var lastReply: Assistant.Reply? = null
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private var generating = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply {
            setBackgroundColor(0x99000000.toInt())
            setOnClickListener { finish() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(cCard, 22)
            setPadding(dp(18), dp(18), dp(18), dp(14))
            isClickable = true
        }
        status = TextView(this).apply {
            textSize = 20f
            setTextColor(cGold)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        heard = TextView(this).apply {
            textSize = 17f
            setTextColor(cSub)
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, 0)
        }
        answer = TextView(this).apply {
            textSize = 17f
            setTextColor(cText)
            setLineSpacing(dp(4).toFloat(), 1f)
            setTextIsSelectable(true)
            visibility = View.GONE
            background = rounded(0xFF2E3560.toInt(), 14)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
        }
        card.addView(status, LinearLayout.LayoutParams(-1, -2))
        card.addView(heard, LinearLayout.LayoutParams(-1, -2))
        card.addView(answer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        card.addView(btnRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        root.addView(card, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            setMargins(dp(12), dp(12), dp(12), dp(24))
        })
        setContentView(root)

        // خواندن پاسخ با صدا، فقط اگر گوشی صدای فارسی داشته باشد
        try {
            tts = TextToSpeech(applicationContext) { st ->
                if (st == TextToSpeech.SUCCESS) {
                    val r = tts?.setLanguage(Locale("fa")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                    ttsOk = r >= TextToSpeech.LANG_AVAILABLE
                }
            }
        } catch (t: Throwable) { tts = null }

        if (!Stt.isReady(this)) {
            status.text = "مدل گفتار دانلود نشده"
            heard.text = "ابتدا از صفحه‌ی اصلی برنامه، «مدل تشخیص گفتار فارسی» را دانلود کنید."
            setButtons(
                "باز کردن برنامه" to { startActivity(Intent(this, MainActivity::class.java)); finish() },
                "بستن" to { finish() }
            )
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            listen()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 7 && res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED) listen()
        else {
            Toast.makeText(this, "برای دستیار صوتی مجوز میکروفون لازم است.", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun setButtons(vararg items: Pair<String, () -> Unit>) {
        btnRow.removeAllViews()
        for ((i, it) in items.withIndex()) {
            btnRow.addView(Button(this).apply {
                text = it.first
                textSize = 14f
                setTextColor(Color.WHITE)
                background = rounded(if (i == 0) cAccent else 0xFF3A3F5C.toInt(), 12)
                setOnClickListener { _ -> it.second() }
            }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (i > 0) marginStart = dp(8) })
        }
    }

    private fun listen() {
        if (listening) return
        tts?.stop()
        answer.visibility = View.GONE
        heard.text = ""
        status.text = "⏳ آماده‌سازی…"
        setButtons("تمام" to { listening = false }, "بستن" to { finish() })
        listening = true
        val app = applicationContext
        Thread {
            val model = try { SpeechModel.get(app) } catch (t: Throwable) {
                runOnUiThread { fail("بارگذاری مدل گفتار ناموفق بود.") }
                return@Thread
            }
            val rate = 16000
            val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val bufSize = maxOf(minBuf, rate)
            val ar: AudioRecord
            try {
                ar = AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, bufSize
                )
                if (ar.state != AudioRecord.STATE_INITIALIZED) { ar.release(); throw IllegalStateException() }
            } catch (t: Throwable) {
                runOnUiThread { fail("میکروفون در دسترس نیست (شاید برنامه‌ی دیگری از آن استفاده می‌کند).") }
                return@Thread
            }
            var result = ""
            try {
                Recognizer(model, 16000f).use { rec ->
                    ar.startRecording()
                    runOnUiThread { status.text = "🎙 بگویید…" }
                    val buf = ByteArray(4000)
                    val start = SystemClock.elapsedRealtime()
                    var gotSpeech = false
                    while (listening && !closed) {
                        val n = ar.read(buf, 0, buf.size)
                        if (n <= 0) break
                        if (rec.acceptWaveForm(buf, n)) {
                            val t = JSONObject(rec.result).optString("text", "").trim()
                            if (t.isNotEmpty()) { result = t; break }
                        } else {
                            val p = JSONObject(rec.partialResult).optString("partial", "")
                            if (p.isNotEmpty()) {
                                gotSpeech = true
                                runOnUiThread { heard.text = p }
                            }
                        }
                        val el = SystemClock.elapsedRealtime() - start
                        if ((!gotSpeech && el > 8000) || el > 25000) break
                    }
                    if (result.isEmpty()) result = JSONObject(rec.finalResult).optString("text", "").trim()
                }
            } catch (t: Throwable) {
                result = ""
            } finally {
                try { ar.stop() } catch (t: Throwable) { }
                ar.release()
            }
            listening = false
            runOnUiThread { if (!closed) onHeard(result) }
        }.start()
    }

    private fun fail(msg: String) {
        listening = false
        status.text = "⚠️"
        heard.text = msg
        setButtons("دوباره" to { listen() }, "بستن" to { finish() })
    }

    private fun onHeard(text: String) {
        lastText = text
        if (text.isBlank()) {
            status.text = "چیزی نشنیدم"
            heard.text = ""
            setButtons("🎙 دوباره" to { listen() }, "بستن" to { finish() })
            return
        }
        status.text = "✅ شنیدم"
        heard.text = "«$text»"
        val r = try { Assistant.handle(applicationContext, text) } catch (t: Throwable) {
            Assistant.Reply("خطا در اجرای دستور.")
        }
        lastReply = r
        answer.text = r.text
        answer.visibility = View.VISIBLE
        if (ttsOk) tts?.speak(r.speak, TextToSpeech.QUEUE_FLUSH, null, "ans")

        val items = ArrayList<Pair<String, () -> Unit>>()
        items.add("🎙 دوباره" to { listen() })
        if (r.canAskAi && Llm.supported() && LlmModels.selected(this) != null) {
            items.add("🧠 هوش مصنوعی" to { runAi() })
        }
        items.add("بستن" to { finish() })
        setButtons(*items.toTypedArray())
    }

    private fun runAi() {
        if (generating) return
        val sel = LlmModels.selected(this) ?: return
        generating = true
        val app = applicationContext
        val hits = lastReply?.hits ?: emptyList()
        val notes = if (hits.isNotEmpty()) hits.map { Jalali.format(it.note.created, false) to it.note.text }
        else NoteStore.all(app).take(8).map { Jalali.format(it.created, false) to it.text }
        val prompt = Llm.buildPrompt(lastText, notes)
        status.text = "🧠 در حال فکر کردن…"
        answer.text = "در حال آماده‌سازی مدل…"
        answer.visibility = View.VISIBLE
        setButtons("بستن" to { Llm.stop(); finish() })
        Thread {
            val err = Llm.load(app, sel)
            if (err != null) {
                runOnUiThread { generating = false; answer.text = "بارگذاری مدل ناموفق بود:\n$err"; setButtons("🎙 دوباره" to { listen() }, "بستن" to { finish() }) }
                return@Thread
            }
            runOnUiThread { answer.text = "" }
            val sb = StringBuilder()
            val rc = try {
                Llm.generate(prompt, 300) { piece ->
                    sb.append(piece)
                    runOnUiThread { answer.text = sb.toString().trimStart() }
                    !closed
                }
            } catch (t: Throwable) { -9 }
            runOnUiThread {
                generating = false
                status.text = "✅ پاسخ"
                if (rc < 0) answer.text = "خطا در اجرای مدل (کد $rc)"
                else if (sb.isBlank()) answer.text = "پاسخی تولید نشد."
                else if (ttsOk) tts?.speak(sb.toString(), TextToSpeech.QUEUE_FLUSH, null, "ai")
                setButtons("🎙 دوباره" to { listen() }, "بستن" to { finish() })
            }
        }.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        closed = true
        listening = false
        if (generating) Llm.stop()
        tts?.stop()
        tts?.shutdown()
    }
}
