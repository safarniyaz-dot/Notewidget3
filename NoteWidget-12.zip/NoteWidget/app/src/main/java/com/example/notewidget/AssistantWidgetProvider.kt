package com.example.notewidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** ویجت «دستیار صوتی»: با یک ضربه میکروفون باز می‌شود. */
class AssistantWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, buildViews(ctx, id))
    }

    companion object {
        fun buildViews(ctx: Context, widgetId: Int): RemoteViews {
            val t = WidgetThemes.current(ctx)
            val rv = RemoteViews(ctx.packageName, R.layout.widget_assistant)
            rv.setInt(R.id.root, "setBackgroundColor", t.row)
            rv.setInt(R.id.mic, "setColorFilter", t.accent)
            rv.setTextColor(R.id.label, t.text)
            val i = Intent(ctx, AssistantActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            val pi = PendingIntent.getActivity(
                ctx, 900000 + widgetId, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.root, pi)
            return rv
        }
    }
}
