package com.example.notewidget

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** صفحه‌ی آلارم (تمام‌صفحه): تعویق ۵/۱۰/۱۵ دقیقه یا رد آلارم. */
class AlarmDialogActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra("id", 0L)
        val note = NoteStore.get(this, id)
        if (note == null) {
            AlarmActions.dismiss(this, id)
            finish()
            return
        }

        val dp = resources.displayMetrics.density
        fun px(v: Int): Int = (v * dp).toInt()
        val bgColor = 0xFF111522.toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(bgColor)
            setPadding(px(24), px(56), px(24), px(32))
        }

        root.addView(TextView(this).apply {
            text = "⏰ یادآوری یادداشت"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(0xFFD9A441.toInt())
        })

        // زمان فعلی با روز هفته‌ی شمسی
        root.addView(TextView(this).apply {
            text = Jalali.formatLong(System.currentTimeMillis())
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xB3FFFFFF.toInt())
            setPadding(0, px(6), 0, 0)
        })

        root.addView(TextView(this).apply {
            text = note.text
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, px(40), 0, if (note.transcript.isNotEmpty()) px(12) else px(40))
        })

        if (note.transcript.isNotEmpty()) {
            root.addView(TextView(this).apply {
                text = "📝 " + note.transcript
                textSize = 16f
                gravity = Gravity.CENTER
                setTextColor(0xCCFFFFFF.toInt())
                setPadding(0, 0, 0, px(32))
            })
        }

        fun addButton(label: String, color: Int, onClick: () -> Unit) {
            val b = Button(this).apply {
                text = label
                textSize = 18f
                setTextColor(Color.WHITE)
                setBackgroundColor(color)
                setOnClickListener {
                    onClick()
                    finish()
                }
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(58))
            lp.topMargin = px(12)
            root.addView(b, lp)
        }

        addButton("۵ دقیقه بعد", 0xFF2E3552.toInt()) { AlarmActions.snooze(this, id, 5) }
        addButton("۱۰ دقیقه بعد", 0xFF2E3552.toInt()) { AlarmActions.snooze(this, id, 10) }
        addButton("۱۵ دقیقه بعد", 0xFF2E3552.toInt()) { AlarmActions.snooze(this, id, 15) }
        addButton("رد آلارم", 0xFFB3261E.toInt()) { AlarmActions.dismiss(this, id) }

        setContentView(ScrollView(this).apply {
            setBackgroundColor(bgColor)
            isFillViewport = true
            addView(root)
        })
    }
}
