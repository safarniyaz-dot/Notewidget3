package com.example.notewidget

import android.content.Context
import android.graphics.Color

/** رنگ‌های محاسبه‌شده از روی یک «رنگ پایه»ی انتخابی کاربر. */
data class WidgetTheme(
    val bg: Int,       // پس‌زمینه‌ی کل ویجت
    val row: Int,      // پس‌زمینه‌ی یادداشت‌ها و نوار افزودن
    val header: Int,   // پس‌زمینه‌ی عنوان روزها
    val text: Int,     // متن اصلی
    val sub: Int,      // متن کم‌رنگ
    val accent: Int,   // رنگ تأکید (نوار، آیکن‌ها، خط ضخیم)
    val line: Int      // خط‌های جداکننده
)

object WidgetThemes {
    private const val PREFS = "settings"
    private const val KEY = "widget_color"

    val DEFAULT: Int = 0xFF22263F.toInt()

    val presets: List<Pair<String, Int>> = listOf(
        "آبی تیره" to 0xFF22263F.toInt(),
        "مشکی" to 0xFF111111.toInt(),
        "سبز تیره" to 0xFF1E3A2F.toInt(),
        "قرمز تیره" to 0xFF4A1F24.toInt(),
        "بنفش" to 0xFF3A2A5C.toInt(),
        "خاکستری" to 0xFF3A3F47.toInt(),
        "سفید" to 0xFFF2F2F2.toInt(),
        "کرم" to 0xFFF5ECD7.toInt()
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun base(ctx: Context): Int = prefs(ctx).getInt(KEY, DEFAULT)

    fun save(ctx: Context, color: Int) {
        prefs(ctx).edit().putInt(KEY, color or 0xFF000000.toInt()).apply()
    }

    fun label(ctx: Context): String {
        val b = base(ctx)
        return presets.firstOrNull { it.second == b }?.first
            ?: "دلخواه (#%06X)".format(b and 0xFFFFFF)
    }

    fun current(ctx: Context): WidgetTheme = build(base(ctx))

    private fun blend(a: Int, b: Int, t: Float): Int {
        fun ch(x: Int, y: Int): Int = (x + (y - x) * t).toInt().coerceIn(0, 255)
        return Color.rgb(
            ch(Color.red(a), Color.red(b)),
            ch(Color.green(a), Color.green(b)),
            ch(Color.blue(a), Color.blue(b))
        )
    }

    private fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    fun build(base: Int): WidgetTheme {
        val lum = (0.299 * Color.red(base) + 0.587 * Color.green(base) + 0.114 * Color.blue(base)) / 255.0
        val dark = lum < 0.55

        val text = if (dark) Color.WHITE else 0xFF1A1A1A.toInt()
        val sub = if (dark) 0xB3FFFFFF.toInt() else 0xB3000000.toInt()
        val accent = if (dark) 0xFFD9A441.toInt() else 0xFF9A6A00.toInt()
        val line = if (dark) 0x55FFFFFF.toInt() else 0x55000000.toInt()

        val rowBase = blend(base, if (dark) Color.WHITE else Color.BLACK, 0.07f)
        val headerBase = blend(base, Color.BLACK, if (dark) 0.25f else 0.10f)

        return WidgetTheme(
            bg = withAlpha(base, 0xE6),
            row = withAlpha(rowBase, 0xE6),
            header = withAlpha(headerBase, 0xF0),
            text = text,
            sub = sub,
            accent = accent,
            line = line
        )
    }
}
