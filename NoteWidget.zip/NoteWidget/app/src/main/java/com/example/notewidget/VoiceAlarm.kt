package com.example.notewidget

import java.util.Calendar

/**
 * اگر در متن یادداشت صوتی کلمه‌ی «آلارم» و بعد یا قبل از آن ساعتی گفته شده باشد،
 * زمان آلارم را برمی‌گرداند. مثال‌ها:
 * «آلارم ساعت هشت و نیم صبح»، «آلارم ۸:۳۰ فردا»، «آلارم ده دقیقه دیگر»،
 * «ساعت پنج عصر آلارم بگذار»، «آلارم ربع به هشت».
 */
object VoiceAlarm {
    private val keywords = setOf("الارم", "alarm")
    private val fillers = setOf("بگذار", "بذار", "بگذارید", "بذارید", "تنظیم", "کن", "بزن")
    private val months = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "ابان", "اذر", "دی", "بهمن", "اسفند")
    private val ordUnits = mapOf("اول" to 1, "یکم" to 1, "دوم" to 2, "سوم" to 3, "چهارم" to 4,
        "پنجم" to 5, "ششم" to 6, "هفتم" to 7, "هشتم" to 8, "نهم" to 9)
    private val ordTeens = mapOf("دهم" to 10, "یازدهم" to 11, "دوازدهم" to 12, "سیزدهم" to 13,
        "چهاردهم" to 14, "پانزدهم" to 15, "شانزدهم" to 16, "هفدهم" to 17, "هجدهم" to 18,
        "نوزدهم" to 19, "بیستم" to 20, "سیام" to 30, "سیم" to 30)
    private val wdWords = mapOf("یکشنبه" to 1, "دوشنبه" to 2, "سشنبه" to 3, "سهشنبه" to 3,
        "چهارشنبه" to 4, "پنجشنبه" to 5, "جمعه" to 6, "شنبه" to 7)
    private val wdPrefix = mapOf("یک" to 1, "دو" to 2, "سه" to 3, "چهار" to 4, "پنج" to 5)

    class Result(val time: Long, val repeat: Int, val minuteOfDay: Int, val cleaned: String)

    private fun normWord(w: String): String {
        val sb = StringBuilder()
        for (c0 in w) {
            if (c0 in 'ً'..'ٟ') continue
            val c = when (c0) {
                'ي' -> 'ی'
                'ك' -> 'ک'
                'آ', 'أ', 'إ' -> 'ا'
                'ة' -> 'ه'
                '٫', '٬' -> '/'
                in '۰'..'۹' -> '0' + (c0 - '۰')
                in '٠'..'٩' -> '0' + (c0 - '٠')
                else -> c0
            }
            if (c.isLetterOrDigit() || c == ':' || c == '/') sb.append(c.lowercaseChar())
        }
        return sb.toString()
    }

    /** روز هفته (Calendar.DAY_OF_WEEK) و تعداد کلمه‌ها، یا null. */
    private fun weekdayAt(t: List<String>, i: Int): Pair<Int, Int>? {
        if (i < 0 || i >= t.size) return null
        val p = wdPrefix[t[i]]
        if (p != null && t.getOrNull(i + 1) == "شنبه") return Pair(p, 2)
        val s = wdWords[t[i]] ?: return null
        return Pair(s, 1)
    }

    private fun dayNum(t: List<String>, i: Int): Num? {
        if (i >= t.size) return null
        val w = t[i]
        ordTeens[w]?.let { return Num(it, i + 1) }
        ordUnits[w]?.let { return Num(it, i + 1) }
        tens[w]?.let { base ->
            if (t.getOrNull(i + 1) == "و") {
                val u = ordUnits[t.getOrNull(i + 2) ?: ""]
                if (u != null) return Num(base + u, i + 3)
            }
        }
        val n = num(t, i) ?: return null
        return if (n.hm < 0 && n.value in 1..31) n else null
    }
    private val units = mapOf(
        "صفر" to 0, "یک" to 1, "دو" to 2, "سه" to 3, "چهار" to 4, "پنج" to 5,
        "شش" to 6, "شیش" to 6, "هفت" to 7, "هشت" to 8, "نه" to 9
    )
    private val teens = mapOf(
        "ده" to 10, "یازده" to 11, "دوازده" to 12, "سیزده" to 13, "چهارده" to 14,
        "پانزده" to 15, "شانزده" to 16, "هفده" to 17, "هجده" to 18, "نوزده" to 19
    )
    private val tens = mapOf("بیست" to 20, "سی" to 30, "چهل" to 40, "پنجاه" to 50)
    private val hmRegex = Regex("^(\\d{1,2}):(\\d{2})$")

    private class Num(val value: Int, val next: Int, val hm: Int = -1)
    private class Parsed(val h: Int, val m: Int, val rel: Int = -1)

    private fun num(t: List<String>, i: Int): Num? {
        if (i < 0 || i >= t.size) return null
        val w = t[i]
        hmRegex.matchEntire(w)?.let { return Num(it.groupValues[1].toInt(), i + 1, it.groupValues[2].toInt()) }
        if (w.length <= 2 && w.all { it.isDigit() }) return Num(w.toInt(), i + 1)
        units[w]?.let { return Num(it, i + 1) }
        teens[w]?.let { return Num(it, i + 1) }
        tens[w]?.let { base ->
            if (i + 2 < t.size && t[i + 1] == "و") {
                val u = units[t[i + 2]]
                if (u != null && u > 0) return Num(base + u, i + 3)
            }
            return Num(base, i + 1)
        }
        return null
    }

    /** دقیقه‌ی بعد از ساعت: «و نیم»، «و ربع»، «و سی دقیقه». */
    private fun minutes(t: List<String>, j: Int): Int {
        if (j < t.size && t[j] == "و" && j + 1 < t.size) {
            val x = t[j + 1]
            if (x == "نیم" || x == "نیمه") return 30
            if (x == "ربع") return 15
            val m = num(t, j + 1)
            if (m != null && m.hm < 0 && m.value in 0..59) return m.value
        } else if (j < t.size && t[j] == "نیم") {
            return 30
        } else if (j < t.size && t[j].length == 2 && t[j].all { it.isDigit() } && t[j].toInt() in 0..59) {
            return t[j].toInt()
        }
        return 0
    }

    private fun minus(h: Int, d: Int): Parsed {
        val tot = ((h * 60 - d) % 1440 + 1440) % 1440
        return Parsed(tot / 60, tot % 60)
    }

    private fun scan(t: List<String>, needSaat: Boolean): Parsed? {
        // «۱۰ دقیقه دیگر» / «۲ ساعت بعد»
        for (i in t.indices) {
            val a = num(t, i) ?: continue
            val u = t.getOrNull(a.next)
            val w = t.getOrNull(a.next + 1)
            if ((u == "دقیقه" || u == "ساعت") && (w == "دیگه" || w == "دیگر" || w == "بعد")) {
                return Parsed(0, 0, if (u == "دقیقه") a.value else a.value * 60)
            }
        }
        val saat = t.indexOf("ساعت")
        if (needSaat && saat < 0) return null
        val start = if (saat >= 0) saat + 1 else 0
        for (i in start until t.size) {
            if (t[i] == "ربع" && t.getOrNull(i + 1) == "به") {
                val h = num(t, i + 2)
                if (h != null && h.value in 1..24) return minus(h.value, 15)
            }
            val a = num(t, i) ?: continue
            if (a.hm >= 0) {
                if (a.value in 0..23 && a.hm in 0..59) return Parsed(a.value, a.hm)
                continue
            }
            if (t.getOrNull(a.next) == "دقیقه" && t.getOrNull(a.next + 1) == "به") {
                val h = num(t, a.next + 2)
                if (h != null && h.value in 1..24 && a.value in 1..59) return minus(h.value, a.value)
            }
            if (a.value !in 0..24) continue
            return Parsed(a.value % 24, minutes(t, a.next))
        }
        return null
    }

    private class DateSpec(val y: Int, val m: Int, val d: Int, val from: Int, val to: Int)

    private fun findDate(t: List<String>, lo: Int, hi: Int, curY: Int): DateSpec? {
        val ymd = Regex("^(\\d{4})/(\\d{1,2})/(\\d{1,2})$")
        val md = Regex("^(\\d{1,2})/(\\d{1,2})$")
        for (i in lo until hi) {
            ymd.matchEntire(t[i])?.let {
                val (y, m, d) = it.destructured
                if (m.toInt() in 1..12 && d.toInt() in 1..31) return DateSpec(y.toInt(), m.toInt(), d.toInt(), i, i)
            }
            md.matchEntire(t[i])?.let {
                val (m, d) = it.destructured
                if (m.toInt() in 1..12 && d.toInt() in 1..31) return DateSpec(0, m.toInt(), d.toInt(), i, i)
            }
            val dn = dayNum(t, i) ?: continue
            var j = dn.next
            if (t.getOrNull(j) == "ماه") j++
            val mi = months.indexOf(t.getOrNull(j) ?: "")
            if (mi < 0) continue
            var end = j
            var y = 0
            val ys = t.getOrNull(j + 1)
            if (ys != null && ys.length == 4 && ys.all { it.isDigit() }) { y = ys.toInt(); end = j + 1 }
            return DateSpec(y, mi + 1, dn.value, i, end)
        }
        return null
    }

    fun parse(text: String, now: Long): Long? = parseFull(text, now)?.time

    /** زمان آلارم، تکرار و متن تمیزشده (بدون «آلارم» و تاریخ) یا null. */
    fun parseFull(text: String, now: Long): Result? {
        val orig = text.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val t = ArrayList<String>(); val oi = ArrayList<Int>()
        orig.forEachIndexed { i, w -> val n = normWord(w); if (n.isNotEmpty()) { t.add(n); oi.add(i) } }
        val k = t.indexOfFirst { it in keywords }
        if (k < 0) return null
        val lo = maxOf(0, k - 10)
        val hi = minOf(t.size, k + 20)
        val used = HashSet<Int>()
        used.add(k)
        var f = k + 1
        while (f < t.size && t[f] in fillers) { used.add(f); f++ }

        // تکرار
        var mask = 0
        for (i in lo until hi) {
            if (t[i] == "هرروز") { mask = 127; used.add(i) }
            if (t[i] != "هر") continue
            var j = i + 1
            if (t.getOrNull(j) == "روز") { mask = 127; used.add(i); used.add(j); continue }
            if (t.getOrNull(j) in setOf("شب", "صبح", "عصر", "ظهر")) { mask = 127; used.add(i); continue }
            var any = false
            while (true) {
                val wd = weekdayAt(t, j) ?: break
                mask = mask or (1 shl (wd.first - 1))
                for (x in j until j + wd.second) used.add(x)
                j += wd.second
                any = true
                if (t.getOrNull(j) == "و" && weekdayAt(t, j + 1) != null) { used.add(j); j++ } else break
            }
            if (any) used.add(i)
        }

        var bareDow = 0
        var date: DateSpec? = null
        var dayOff = 0
        val nowCal = Calendar.getInstance().apply { timeInMillis = now }
        if (mask == 0) {
            for (i in lo until hi) {
                if (i in used) continue
                val wd = weekdayAt(t, i) ?: continue
                bareDow = wd.first
                for (x in i until i + wd.second) used.add(x)
                break
            }
            val nj = Jalali.fromGregorian(nowCal.get(Calendar.YEAR), nowCal.get(Calendar.MONTH) + 1, nowCal.get(Calendar.DAY_OF_MONTH))
            if (bareDow == 0) {
                date = findDate(t, lo, hi, nj[0])
                date?.let { for (x in it.from..it.to) used.add(x) }
            }
            for (i in lo until hi) {
                when (t[i]) {
                    "فردا" -> {
                        used.add(i)
                        if (i > 0 && t[i - 1] == "پس") { used.add(i - 1); dayOff = 2 } else if (dayOff == 0) dayOff = 1
                    }
                    "پسفردا" -> { used.add(i); dayOff = 2 }
                    "امروز" -> used.add(i)
                }
            }
        }
        val explicit = mask != 0 || bareDow != 0 || date != null || dayOff > 0

        val tm = t.mapIndexed { i, s -> if (i in used) "#" else s }
        val pr: Parsed = scan(tm.subList(k + 1, minOf(t.size, k + 13)), false)
            ?: scan(tm.subList(maxOf(0, k - 8), k), true)
            ?: (if (explicit) Parsed(8, 0) else return null)

        val cleaned = run {
            val drop = used.map { oi[it] }.toSet()
            val s = orig.filterIndexed { i, _ -> i !in drop }.joinToString(" ").trim()
            if (s.isEmpty()) text.trim() else s
        }
        if (pr.rel >= 0) return Result(now + pr.rel * 60_000L, 0, -1, cleaned)

        val near = tm.subList(lo, hi)
        val pm = near.contains("عصر") || near.contains("بعدازظهر") ||
                near.indices.any { near[it] == "بعد" && near.getOrNull(it + 1) == "از" && near.getOrNull(it + 2) == "ظهر" }
        val noon = !pm && near.contains("ظهر")
        val night = near.contains("شب") || near.contains("امشب")
        val am = near.contains("صبح") || near.contains("بامداد")

        val h = pr.h
        val hr: Int = when {
            h > 12 || h == 0 -> h
            pm -> if (h < 12) h + 12 else 12
            noon -> if (h in 1..5) h + 12 else h
            night -> if (h == 12) 0 else if (h >= 6) h + 12 else h
            am -> if (h == 12) 0 else h
            explicit -> h
            else -> -1
        }

        fun at(off: Int, hour: Int): Calendar {
            val c = nowCal.clone() as Calendar
            c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            c.add(Calendar.DAY_OF_MONTH, off)
            c.set(Calendar.HOUR_OF_DAY, hour)
            c.set(Calendar.MINUTE, pr.m)
            return c
        }

        if (hr < 0) {
            val a = at(0, h % 12).timeInMillis
            val b = at(0, h % 12 + 12).timeInMillis
            val r = listOf(a, b).filter { it > now }.minOrNull() ?: (a + 24 * 3600_000L)
            return Result(r, 0, -1, cleaned)
        }
        if (mask != 0) {
            val mod = hr * 60 + pr.m
            return Result(Repeat.next(mask, mod, now), mask, mod, cleaned)
        }
        if (date != null) {
            val nj = Jalali.fromGregorian(nowCal.get(Calendar.YEAR), nowCal.get(Calendar.MONTH) + 1, nowCal.get(Calendar.DAY_OF_MONTH))
            fun build(jy: Int): Long {
                val g = Jalali.toGregorian(jy, date.m, minOf(date.d, Jalali.monthLength(jy, date.m)))
                return Calendar.getInstance().apply {
                    set(g[0], g[1] - 1, g[2], hr, pr.m, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
            }
            var r = build(if (date.y > 0) (if (date.y < 100) 1400 + date.y else date.y) else nj[0])
            if (r <= now && date.y == 0) r = build(nj[0] + 1)
            if (r <= now) return null
            return Result(r, 0, -1, cleaned)
        }
        if (bareDow != 0) {
            for (off in 0..7) {
                val c = at(off, hr)
                if (c.get(Calendar.DAY_OF_WEEK) == bareDow && c.timeInMillis > now)
                    return Result(c.timeInMillis, 0, -1, cleaned)
            }
            return null
        }
        val r = at(dayOff, hr).timeInMillis
        return Result(if (r <= now && dayOff == 0) r + 24 * 3600_000L else r, 0, -1, cleaned)
    }
}

/** محاسبه‌ی نوبت بعدی آلارم تکرارشونده (mask: بیت i = روز i+1 از Calendar.DAY_OF_WEEK). */
object Repeat {
    fun next(mask: Int, minuteOfDay: Int, after: Long): Long {
        val base = Calendar.getInstance().apply { timeInMillis = after }
        for (d in 0..7) {
            val c = base.clone() as Calendar
            c.add(Calendar.DAY_OF_MONTH, d)
            c.set(Calendar.HOUR_OF_DAY, minuteOfDay / 60)
            c.set(Calendar.MINUTE, minuteOfDay % 60)
            c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            if (c.timeInMillis > after && (mask shr (c.get(Calendar.DAY_OF_WEEK) - 1)) and 1 == 1)
                return c.timeInMillis
        }
        return after + 24 * 3600_000L
    }
}
