package com.example.notewidget

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import android.view.WindowManager
import android.widget.EditText
import android.widget.NumberPicker
import android.widget.TextView
import android.widget.TimePicker
import android.widget.Toast
import java.util.Calendar

class ItemActionActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra("id", 0L)
        val note = NoteStore.get(this, id)
        if (note == null) {
            finish()
            return
        }
        when (intent.getStringExtra("type")) {
            "toggle" -> {
                NoteStore.toggleDone(this, id)
                WidgetUpdater.refresh(this)
                finish()
                overridePendingTransition(0, 0)
            }
            "delete" -> {
                if (VoicePlayer.playing == note.audio) VoicePlayer.stop(this)
                AlarmScheduler.cancel(this, id)
                NoteStore.delete(this, id)
                WidgetUpdater.refresh(this)
                finish()
            }
            "play" -> {
                if (note.audio.isNotEmpty()) VoicePlayer.toggle(this, note.audio)
                finish()
                overridePendingTransition(0, 0)
            }
            "alarm" -> showPicker(note)
            "edit" -> showEdit(note)
            else -> finish()
        }
    }

    /** ویرایش متن یادداشت. */
    private fun showEdit(note: Note) {
        val dp = resources.displayMetrics.density
        val et = EditText(this).apply {
            setText(note.text)
            setSelection(note.text.length)
            minLines = 3
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                    InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setPadding((20 * dp).toInt(), (16 * dp).toInt(), (20 * dp).toInt(), (16 * dp).toInt())
        }

        val hasAudio = note.audio.isNotEmpty()
        val builder = AlertDialog.Builder(this)
            .setTitle("ویرایش یادداشت")
            .setView(et)
            .setPositiveButton("ذخیره", null)
            .setNegativeButton("انصراف", null)
        if (hasAudio) builder.setNeutralButton("صدا ← متن", null)
        val dialog = builder.create()
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)
        dialog.setOnDismissListener { finish() }
        dialog.show()

        if (hasAudio) {
            dialog.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener {
                when {
                    !Transcriber.canTranscribe(note.audio) ->
                        Toast.makeText(this, "این یادداشت صوتی قدیمی است و قابل تبدیل به متن نیست", Toast.LENGTH_LONG).show()
                    !SpeechModel.isReady(this) ->
                        Toast.makeText(this, "اول از صفحه اصلی برنامه «مدل تبدیل صدا به متن» را دانلود کنید", Toast.LENGTH_LONG).show()
                    else -> {
                        Transcriber.start(this, note.id, note.audio)
                        Toast.makeText(this, "تبدیل شروع شد؛ چند لحظه بعد متن در ویجت نمایش داده می‌شود", Toast.LENGTH_LONG).show()
                        dialog.dismiss()
                    }
                }
            }
        }

        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val text = et.text.toString().trim()
            if (text.isEmpty()) {
                Toast.makeText(this, "متن یادداشت خالی است", Toast.LENGTH_SHORT).show()
            } else {
                NoteStore.updateText(this, note.id, text)
                WidgetUpdater.refresh(this)
                dialog.dismiss()
            }
        }
    }

    /** اندروید ۱۳+: بدون مجوز اعلان، آلارم هیچ نمایشی ندارد. */
    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
    }

    /** اگر اعلان‌ها برای برنامه خاموش باشند، به تنظیمات اعلان می‌رویم. */
    private fun warnIfNotificationsOff() {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.areNotificationsEnabled()) {
            Toast.makeText(
                this, "اعلان‌های برنامه خاموش است؛ آن را روشن کنید تا آلارم نمایش داده شود",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        }
    }

    private fun showPicker(note: Note) {
        askNotificationPermission()
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_alarm, null)
        val npY = v.findViewById<NumberPicker>(R.id.np_year)
        val npM = v.findViewById<NumberPicker>(R.id.np_month)
        val npD = v.findViewById<NumberPicker>(R.id.np_day)
        val tp = v.findViewById<TimePicker>(R.id.time)
        val tvWeekday = v.findViewById<TextView>(R.id.tv_weekday)

        val now = System.currentTimeMillis()
        val base = Calendar.getInstance().apply {
            timeInMillis = if (note.alarm > now) note.alarm else now + 3_600_000L
        }
        val today = Calendar.getInstance()
        val nowJ = Jalali.fromGregorian(
            today.get(Calendar.YEAR), today.get(Calendar.MONTH) + 1, today.get(Calendar.DAY_OF_MONTH)
        )
        val j = Jalali.fromGregorian(
            base.get(Calendar.YEAR), base.get(Calendar.MONTH) + 1, base.get(Calendar.DAY_OF_MONTH)
        )

        npY.minValue = nowJ[0]
        npY.maxValue = nowJ[0] + 10
        npY.value = j[0]

        npM.minValue = 1
        npM.maxValue = 12
        npM.displayedValues = Jalali.monthNames
        npM.value = j[1]

        npD.minValue = 1
        npD.maxValue = Jalali.monthLength(j[0], j[1])
        npD.value = j[2]

        // روز هفته‌ی تاریخ انتخاب‌شده (مثلاً «شنبه»)
        fun updateWeekday() {
            tvWeekday.text = Jalali.weekdayName(npY.value, npM.value, npD.value)
        }
        updateWeekday()

        val onChange = NumberPicker.OnValueChangeListener { _, _, _ ->
            npD.maxValue = Jalali.monthLength(npY.value, npM.value)
            updateWeekday()
        }
        npY.setOnValueChangedListener(onChange)
        npM.setOnValueChangedListener(onChange)
        npD.setOnValueChangedListener(onChange)

        tp.setIs24HourView(true)
        tp.hour = base.get(Calendar.HOUR_OF_DAY)
        tp.minute = base.get(Calendar.MINUTE)

        val builder = AlertDialog.Builder(this)
            .setTitle("آلارم (تاریخ شمسی)")
            .setView(v)
            .setPositiveButton("ثبت", null)
            .setNegativeButton("انصراف", null)
        if (note.alarm > 0) builder.setNeutralButton("حذف آلارم", null)

        val dialog = builder.create()
        dialog.setOnDismissListener { finish() }
        dialog.show()

        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val g = Jalali.toGregorian(npY.value, npM.value, npD.value)
            val c = Calendar.getInstance().apply {
                set(g[0], g[1] - 1, g[2], tp.hour, tp.minute, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (c.timeInMillis <= System.currentTimeMillis()) {
                Toast.makeText(this, "این زمان گذشته است", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            NoteStore.setAlarm(this, note.id, c.timeInMillis)
            AlarmScheduler.schedule(this, note.id, c.timeInMillis)
            WidgetUpdater.refresh(this)
            Toast.makeText(this, "آلارم: " + Jalali.formatLong(c.timeInMillis), Toast.LENGTH_LONG).show()
            if (Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            ) warnIfNotificationsOff()
            dialog.dismiss()
        }

        if (note.alarm > 0) {
            dialog.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener {
                AlarmScheduler.cancel(this, note.id)
                NoteStore.setAlarm(this, note.id, 0L)
                WidgetUpdater.refresh(this)
                dialog.dismiss()
            }
        }
    }
}
