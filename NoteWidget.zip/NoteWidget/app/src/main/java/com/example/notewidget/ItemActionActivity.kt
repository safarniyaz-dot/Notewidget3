package com.example.notewidget

import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.NumberPicker
import android.widget.TimePicker
import android.widget.Toast
import java.util.Calendar

class ItemActionActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getLongExtra("id", 0L)
        val note = NoteStore.get(this, id)
        if (note == null) {
            finish()
            return
        }
        when (intent.getStringExtra("type")) {
            "toggle" -> {
                NoteStore.toggleDone(this, id)
                WidgetUpdater.refresh(this)
                finish()
                overridePendingTransition(0, 0)
            }
            "delete" -> {
                AlarmScheduler.cancel(this, id)
                NoteStore.delete(this, id)
                WidgetUpdater.refresh(this)
                finish()
            }
            "alarm" -> showPicker(note)
            else -> finish()
        }
    }

    private fun showPicker(note: Note) {
        val v = LayoutInflater.from(this).inflate(R.layout.dialog_alarm, null)
        val npY = v.findViewById<NumberPicker>(R.id.np_year)
        val npM = v.findViewById<NumberPicker>(R.id.np_month)
        val npD = v.findViewById<NumberPicker>(R.id.np_day)
        val tp = v.findViewById<TimePicker>(R.id.time)

        val now = System.currentTimeMillis()
        val base = Calendar.getInstance().apply {
            timeInMillis = if (note.alarm > now) note.alarm else now + 3_600_000L
        }
        val today = Calendar.getInstance()
        val nowJ = Jalali.fromGregorian(
            today.get(Calendar.YEAR), today.get(Calendar.MONTH) + 1, today.get(Calendar.DAY_OF_MONTH)
        )
        val j = Jalali.fromGregorian(
            base.get(Calendar.YEAR), base.get(Calendar.MONTH) + 1, base.get(Calendar.DAY_OF_MONTH)
        )

        npY.minValue = nowJ[0]
        npY.maxValue = nowJ[0] + 10
        npY.value = j[0]

        npM.minValue = 1
        npM.maxValue = 12
        npM.displayedValues = Jalali.monthNames
        npM.value = j[1]

        npD.minValue = 1
        npD.maxValue = Jalali.monthLength(j[0], j[1])
        npD.value = j[2]

        val updateDays = NumberPicker.OnValueChangeListener { _, _, _ ->
            npD.maxValue = Jalali.monthLength(npY.value, npM.value)
        }
        npY.setOnValueChangedListener(updateDays)
        npM.setOnValueChangedListener(updateDays)

        tp.setIs24HourView(true)
        tp.hour = base.get(Calendar.HOUR_OF_DAY)
        tp.minute = base.get(Calendar.MINUTE)

        val builder = AlertDialog.Builder(this)
            .setTitle("آلارم (تاریخ شمسی)")
            .setView(v)
            .setPositiveButton("ثبت", null)
            .setNegativeButton("انصراف", null)
        if (note.alarm > 0) builder.setNeutralButton("حذف آلارم", null)

        val dialog = builder.create()
        dialog.setOnDismissListener { finish() }
        dialog.show()

        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val g = Jalali.toGregorian(npY.value, npM.value, npD.value)
            val c = Calendar.getInstance().apply {
                set(g[0], g[1] - 1, g[2], tp.hour, tp.minute, 0)
                set(Calendar.MILLISECOND, 0)
            }
            if (c.timeInMillis <= System.currentTimeMillis()) {
                Toast.makeText(this, "این زمان گذشته است", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            NoteStore.setAlarm(this, note.id, c.timeInMillis)
            AlarmScheduler.schedule(this, note.id, c.timeInMillis)
            WidgetUpdater.refresh(this)
            Toast.makeText(this, "آلارم: " + Jalali.formatLong(c.timeInMillis), Toast.LENGTH_LONG).show()
            dialog.dismiss()
        }

        if (note.alarm > 0) {
            dialog.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener {
                AlarmScheduler.cancel(this, note.id)
                NoteStore.setAlarm(this, note.id, 0L)
                WidgetUpdater.refresh(this)
                dialog.dismiss()
            }
        }
    }
}
