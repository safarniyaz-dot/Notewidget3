package com.example.notewidget

import android.content.Context
import org.vosk.Model
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** مدل آفلاین تشخیص گفتار فارسی (Vosk). یک بار دانلود می‌شود و بعد از آن بدون اینترنت کار می‌کند. */
object SpeechModel {
    const val URL = "https://alphacephei.com/vosk/models/vosk-model-small-fa-0.42.zip"
    private const val NAME = "vosk-model-small-fa-0.42"
    private const val MARKER = ".ready"

    @Volatile private var model: Model? = null

    private fun root(ctx: Context) = File(ctx.filesDir, "vosk")
    fun dir(ctx: Context) = File(root(ctx), NAME)
    fun isReady(ctx: Context) = File(dir(ctx), MARKER).exists()

    /** دانلود و استخراج (روی نخ پس‌زمینه صدا بزنید). پیشرفت ۰ تا ۱۰۰. اگر خطا بدهد Exception پرتاب می‌شود. */
    fun download(ctx: Context, onProgress: (Int) -> Unit) {
        val base = root(ctx).apply { mkdirs() }
        val zip = File(base, "model.zip")
        var conn = URL(URL).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        var redirects = 0
        while (conn.responseCode in 300..399 && redirects < 5) {
            val loc = conn.getHeaderField("Location") ?: break
            conn.disconnect()
            conn = URL(loc).openConnection() as HttpURLConnection
            conn.connectTimeout = 20000
            conn.readTimeout = 30000
            redirects++
        }
        if (conn.responseCode != 200) throw RuntimeException("HTTP " + conn.responseCode)
        val total = conn.contentLengthLong
        conn.inputStream.use { input ->
            FileOutputStream(zip).use { out ->
                val buf = ByteArray(64 * 1024)
                var done = 0L
                var last = -1
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    if (total > 0) {
                        val p = (done * 90 / total).toInt()
                        if (p != last) { last = p; onProgress(p) }
                    }
                }
            }
        }
        conn.disconnect()

        // استخراج (با جلوگیری از مسیرهای خطرناک داخل zip)
        val canonRoot = base.canonicalPath + File.separator
        ZipInputStream(zip.inputStream().buffered()).use { zin ->
            while (true) {
                val e = zin.nextEntry ?: break
                val target = File(base, e.name)
                if (!target.canonicalPath.startsWith(canonRoot)) continue
                if (e.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).use { o -> zin.copyTo(o) }
                }
            }
        }
        zip.delete()
        onProgress(98)
        if (!dir(ctx).isDirectory) throw RuntimeException("مدل پیدا نشد")
        File(dir(ctx), MARKER).writeText("ok")
        onProgress(100)
    }

    @Synchronized
    fun get(ctx: Context): Model {
        model?.let { return it }
        val m = Model(dir(ctx).absolutePath)
        model = m
        return m
    }
}
