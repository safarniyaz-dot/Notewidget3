package com.example.notewidget

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.KeyEvent
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout

/** با زدن «افزودن یادداشت…» کیبورد باز می‌شود؛ تایپ کنید و Done بزنید تا یادداشت اضافه شود. */
class AddNoteActivity : Activity() {

    private lateinit var et: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density

        val root = FrameLayout(this).apply {
            setBackgroundColor(0x66000000)
            setOnClickListener { finish() }
        }

        et = EditText(this).apply {
            hint = "افزودن یادداشت…"
            setHintTextColor(0x99FFFFFF.toInt())
            setTextColor(Color.WHITE)
            setBackgroundColor(0xFF22263F.toInt())
            textSize = 18f
            setPadding((16 * dp).toInt(), (14 * dp).toInt(), (16 * dp).toInt(), (14 * dp).toInt())
            // بدون فلگ چندخطی تا دکمه Done روی کیبورد نمایش داده شود
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_DONE
            setHorizontallyScrolling(false)
            maxLines = 4
            setOnEditorActionListener { _, actionId, event ->
                if (actionId == EditorInfo.IME_ACTION_DONE ||
                    (event != null && event.keyCode == KeyEvent.KEYCODE_ENTER &&
                            event.action == KeyEvent.ACTION_DOWN)
                ) {
                    save()
                    true
                } else false
            }
        }

        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            val m = (16 * dp).toInt()
            setMargins(m, (72 * dp).toInt(), m, 0)
        }
        root.addView(et, lp)
        setContentView(root)

        et.requestFocus()
        et.post {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun save() {
        val text = et.text.toString().trim()
        if (text.isNotEmpty()) {
            NoteStore.add(this, text)
            WidgetUpdater.refresh(this)
        }
        finish()
    }
}
