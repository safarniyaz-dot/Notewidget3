package com.example.notewidget

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.text.SpannableString
import android.text.Spanned
import android.text.style.StrikethroughSpan
import android.widget.RemoteViews
import android.widget.RemoteViewsService

class NoteWidgetService : RemoteViewsService() {
    override fun onGetViewFactory(intent: Intent): RemoteViewsFactory = Factory(applicationContext)

    private class Factory(private val ctx: Context) : RemoteViewsFactory {
        private var items: List<Note> = emptyList()

        override fun onCreate() {}
        override fun onDataSetChanged() { items = NoteStore.all(ctx) }
        override fun onDestroy() {}
        override fun getCount() = items.size
        override fun getLoadingView(): RemoteViews? = null
        override fun getViewTypeCount() = 1
        override fun getItemId(position: Int) = items[position].id
        override fun hasStableIds() = true

        override fun getViewAt(position: Int): RemoteViews {
            val n = items[position]
            val rv = RemoteViews(ctx.packageName, R.layout.widget_item)

            // متن یادداشت؛ اگر انجام شده باشد خط‌خورده و کم‌رنگ
            val title: CharSequence = if (n.done) {
                SpannableString(n.text).apply {
                    setSpan(StrikethroughSpan(), 0, n.text.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
            } else n.text
            rv.setTextViewText(R.id.title, title)
            rv.setTextColor(R.id.title, if (n.done) Color.parseColor("#80FFFFFF") else Color.WHITE)

            rv.setImageViewResource(
                R.id.btn_check,
                if (n.done) R.drawable.ic_box_checked else R.drawable.ic_box_empty
            )

            rv.setTextViewText(R.id.subtitle, "ایجاد: " + Jalali.format(n.created))

            if (n.alarm > 0) {
                rv.setViewVisibility(R.id.alarm_text, android.view.View.VISIBLE)
                rv.setTextViewText(R.id.alarm_text, "⏰ " + Jalali.formatLong(n.alarm))
                rv.setInt(R.id.btn_alarm, "setColorFilter", Color.parseColor("#D9A441"))
            } else {
                rv.setViewVisibility(R.id.alarm_text, android.view.View.GONE)
                rv.setInt(R.id.btn_alarm, "setColorFilter", Color.WHITE)
            }

            rv.setOnClickFillInIntent(
                R.id.btn_check, Intent().putExtra("type", "toggle").putExtra("id", n.id)
            )
            rv.setOnClickFillInIntent(
                R.id.btn_delete, Intent().putExtra("type", "delete").putExtra("id", n.id)
            )
            rv.setOnClickFillInIntent(
                R.id.btn_alarm, Intent().putExtra("type", "alarm").putExtra("id", n.id)
            )
            return rv
        }
    }
}
