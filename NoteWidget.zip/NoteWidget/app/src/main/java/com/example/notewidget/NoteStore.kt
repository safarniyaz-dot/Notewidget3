package com.example.notewidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Note(
    val id: Long,
    val text: String,
    val created: Long,
    val alarm: Long,
    val done: Boolean = false,
    val audio: String = "",     // مسیر فایل صدای ضبط‌شده (برای یادداشت صوتی)
    val transcript: String = "", // متن پیاده‌شده‌ی صدا (اختیاری)
    val repeat: Int = 0,        // ماسک روزهای هفته (بیت i = Calendar.DAY_OF_WEEK i+1)؛ ۰ = بدون تکرار
    val mod: Int = 0,           // دقیقه‌ی روز برای آلارم تکرارشونده
    val group: Int = 0          // شناسه‌ی ویجت (۰ = ویجت اول)
)

object NoteStore {
    private const val PREFS = "notes"
    private const val KEY = "data"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun all(ctx: Context): List<Note> {
        val arr = JSONArray(prefs(ctx).getString(KEY, "[]") ?: "[]")
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Note(
                o.getLong("id"), o.getString("text"), o.getLong("created"),
                o.optLong("alarm", 0L), o.optBoolean("done", false), o.optString("audio", ""),
                o.optString("transcript", ""),
                o.optInt("repeat", 0), o.optInt("mod", 0), o.optInt("group", 0)
            )
        }.sortedByDescending { it.created }
    }

    private fun save(ctx: Context, list: List<Note>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("id", it.id).put("text", it.text)
                    .put("created", it.created).put("alarm", it.alarm)
                    .put("done", it.done).put("audio", it.audio).put("transcript", it.transcript)
                    .put("repeat", it.repeat).put("mod", it.mod).put("group", it.group)
            )
        }
        prefs(ctx).edit().putString(KEY, arr.toString()).apply()
    }

    fun get(ctx: Context, id: Long): Note? = all(ctx).firstOrNull { it.id == id }

    @Synchronized
    fun add(
        ctx: Context,
        text: String,
        audio: String = "",
        id: Long = System.currentTimeMillis(),
        transcript: String = "",
        group: Int = 0
    ): Note {
        val n = Note(id, text, id, 0L, false, audio, transcript, 0, 0, group)
        save(ctx, all(ctx) + n)
        return n
    }

    @Synchronized
    fun delete(ctx: Context, id: Long) {
        val note = all(ctx).firstOrNull { it.id == id }
        if (note != null && note.audio.isNotEmpty()) {
            try { File(note.audio).delete() } catch (e: Exception) { /* مهم نیست */ }
        }
        save(ctx, all(ctx).filter { it.id != id })
    }

    @Synchronized
    fun setAlarm(ctx: Context, id: Long, time: Long) {
        save(ctx, all(ctx).map { if (it.id == id) it.copy(alarm = time) else it })
    }

    /** آلارم با تکرار؛ mask=0 یعنی یک‌بار. زمان بعدی از روی mask محاسبه می‌شود. */
    @Synchronized
    fun setAlarmFull(ctx: Context, id: Long, time: Long, mask: Int, mod: Int) {
        save(ctx, all(ctx).map {
            if (it.id == id) it.copy(alarm = time, repeat = mask, mod = if (mask == 0) 0 else mod) else it
        })
    }

    /** حذف کامل آلارم و تکرار. */
    @Synchronized
    fun clearAlarm(ctx: Context, id: Long) = setAlarmFull(ctx, id, 0L, 0, 0)

    @Synchronized
    fun removeGroup(ctx: Context, group: Int) {
        all(ctx).filter { it.group == group && group != 0 }.forEach { delete(ctx, it.id) }
    }

    @Synchronized
    fun updateText(ctx: Context, id: Long, text: String) {
        save(ctx, all(ctx).map { if (it.id == id) it.copy(text = text) else it })
    }

    @Synchronized
    fun updateTranscript(ctx: Context, id: Long, transcript: String) {
        save(ctx, all(ctx).map { if (it.id == id) it.copy(transcript = transcript) else it })
    }

    @Synchronized
    fun toggleDone(ctx: Context, id: Long) {
        save(ctx, all(ctx).map { if (it.id == id) it.copy(done = !it.done) else it })
    }
}
