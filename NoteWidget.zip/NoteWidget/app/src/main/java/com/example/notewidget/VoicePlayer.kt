package com.example.notewidget

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.widget.Toast

/** پخش صدای یادداشت صوتی از داخل ویجت (پخش/توقف). */
object VoicePlayer {
    private var player: MediaPlayer? = null

    @Volatile
    var playing: String? = null
        private set

    fun toggle(ctx: Context, path: String) {
        val app = ctx.applicationContext
        if (playing == path) {
            stop(app)
            return
        }
        stop(app)
        try {
            val p = MediaPlayer()
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            p.setDataSource(path)
            p.prepare()
            p.setOnCompletionListener { stop(app) }
            p.start()
            player = p
            playing = path
        } catch (e: Exception) {
            player = null
            playing = null
            Toast.makeText(app, "پخش صدا ممکن نشد", Toast.LENGTH_SHORT).show()
        }
        WidgetUpdater.refresh(app)
    }

    fun stop(ctx: Context) {
        val p = player
        player = null
        playing = null
        if (p != null) {
            try { p.stop() } catch (e: Exception) { /* مهم نیست */ }
            try { p.release() } catch (e: Exception) { /* مهم نیست */ }
        }
        WidgetUpdater.refresh(ctx.applicationContext)
    }
}
