package com.example.notewidget

import android.content.Context

/** تنها موتور تبدیل صدا به متن: Vosk (آفلاین). */
object Stt {
    const val TITLE = "Vosk فارسی"

    fun isReady(ctx: Context): Boolean = SpeechModel.isReady(ctx)

    /** دانلود مدل (روی نخ پس‌زمینه). */
    fun download(ctx: Context, onProgress: (Int) -> Unit) = SpeechModel.download(ctx, onProgress)
}
