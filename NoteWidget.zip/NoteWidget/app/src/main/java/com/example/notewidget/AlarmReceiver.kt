package com.example.notewidget

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.RingtoneManager

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("id", 0L)
        val note = NoteStore.get(ctx, id) ?: return

        val nm = ctx.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(CHANNEL, "آلارم یادداشت‌ها", NotificationManager.IMPORTANCE_HIGH).apply {
            enableVibration(true)
            setSound(
                RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
        }
        nm.createNotificationChannel(channel)

        val base = (id % 100_000_000L).toInt() * 4

        // با زدن روی اعلان، پنجره‌ی ۴ گزینه‌ای (۵/۱۰/۱۵ دقیقه + رد آلارم) باز می‌شود
        val open = PendingIntent.getActivity(
            ctx, base + 3,
            Intent(ctx, AlarmDialogActivity::class.java).putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        fun action(k: Int, minutes: Int, label: String): Notification.Action {
            val pi = PendingIntent.getBroadcast(
                ctx, base + k,
                Intent(ctx, AlarmActionReceiver::class.java)
                    .putExtra("id", id).putExtra("minutes", minutes),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return Notification.Action.Builder(
                Icon.createWithResource(ctx, R.drawable.ic_alarm), label, pi
            ).build()
        }

        val n = Notification.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_alarm)
            .setContentTitle("یادآوری یادداشت")
            .setContentText(note.text)
            .setStyle(Notification.BigTextStyle().bigText(note.text))
            .setContentIntent(open)
            .setCategory(Notification.CATEGORY_ALARM)
            .addAction(action(0, 5, "۵ دقیقه"))
            .addAction(action(1, 10, "۱۰ دقیقه"))
            .addAction(action(2, 15, "۱۵ دقیقه"))
            .build()
        // صدا تا زمانی که اعلان بسته نشده تکرار شود
        n.flags = n.flags or Notification.FLAG_INSISTENT
        nm.notify(AlarmActions.notifId(id), n)

        NoteStore.setAlarm(ctx, id, 0L)
        WidgetUpdater.refresh(ctx)
    }

    companion object {
        const val CHANNEL = "alarms_v2"
    }
}
