package com.example.notewidget

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONObject
import org.vosk.Recognizer
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.Executors

/** تبدیل فایل WAV (۱۶ کیلوهرتز، مونو) به متن، در پس‌زمینه و کاملاً آفلاین (Vosk). */
object Transcriber {
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    const val PLACEHOLDER = "🎤 در حال تبدیل صدا به متن…"
    const val PLAIN = "🎤 یادداشت صوتی"
    private const val FAILED = "🎤 یادداشت صوتی (تبدیل به متن ناموفق بود)"
    private const val EMPTY = "🎤 یادداشت صوتی (متنی تشخیص داده نشد)"

    fun canTranscribe(path: String) = path.endsWith(".wav", ignoreCase = true)

    fun start(ctx: Context, noteId: Long, wavPath: String, onDone: ((Boolean) -> Unit)? = null) {
        val app = ctx.applicationContext
        exec.execute {
            var ok: Boolean
            var text = ""
            try {
                text = run(app, wavPath).trim()
                ok = true
            } catch (e: Throwable) {
                ok = false
            }
            if (NoteStore.get(app, noteId) != null) {
                val shown = if (ok && text.isNotEmpty()) applyVoiceAlarm(app, noteId, text) else text
                NoteStore.updateText(app, noteId, if (!ok) FAILED else if (text.isEmpty()) EMPTY else shown)
                NoteStore.updateTranscript(app, noteId, text)
                WidgetUpdater.refresh(app)
            }
            if (onDone != null) main.post { onDone(ok) }
        }
    }

    /** اگر در متن «آلارم» و زمان آمده بود، آلارم را می‌گذارد و کلمه‌ی آلارم/تاریخ را از متن حذف می‌کند. */
    private fun applyVoiceAlarm(app: Context, noteId: Long, text: String): String {
        val r = VoiceAlarm.parseFull(text, System.currentTimeMillis()) ?: return text
        NoteStore.setAlarmFull(app, noteId, r.time, r.repeat, r.minuteOfDay)
        AlarmScheduler.schedule(app, noteId, r.time)
        main.post {
            Toast.makeText(app, "آلارم تنظیم شد: " + Jalali.formatLong(r.time) +
                    (if (r.repeat != 0) " (تکرار)" else ""), Toast.LENGTH_LONG).show()
        }
        return r.cleaned
    }

    private fun run(ctx: Context, wavPath: String): String = runVosk(ctx, wavPath)

    private fun runVosk(ctx: Context, wavPath: String): String {
        val model = SpeechModel.get(ctx)
        val sb = StringBuilder()
        fun add(json: String) {
            val t = JSONObject(json).optString("text", "").trim()
            if (t.isNotEmpty()) {
                if (sb.isNotEmpty()) sb.append(' ')
                sb.append(t)
            }
        }
        Recognizer(model, 16000f).use { rec ->
            RandomAccessFile(File(wavPath), "r").use { raf ->
                raf.seek(44)   // رد شدن از سرآیند WAV
                val buf = ByteArray(8000)
                while (true) {
                    val n = raf.read(buf)
                    if (n <= 0) break
                    if (rec.acceptWaveForm(buf, n)) add(rec.result)
                }
                add(rec.finalResult)
            }
        }
        return sb.toString()
    }
}
