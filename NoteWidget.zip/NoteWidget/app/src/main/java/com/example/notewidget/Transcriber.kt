package com.example.notewidget

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.Recognizer
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.Executors

/** تبدیل فایل WAV (۱۶ کیلوهرتز، مونو) به متن با Vosk، در پس‌زمینه و کاملاً آفلاین. */
object Transcriber {
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    fun canTranscribe(path: String) = path.endsWith(".wav", ignoreCase = true)

    fun start(ctx: Context, noteId: Long, wavPath: String, onDone: ((Boolean) -> Unit)? = null) {
        val app = ctx.applicationContext
        exec.execute {
            var ok = false
            try {
                val text = run(app, wavPath)
                if (NoteStore.get(app, noteId) != null) {
                    NoteStore.updateTranscript(app, noteId, text)
                    WidgetUpdater.refresh(app)
                }
                ok = true
            } catch (e: Throwable) {
                ok = false
            }
            if (onDone != null) main.post { onDone(ok) }
        }
    }

    private fun run(ctx: Context, wavPath: String): String {
        val model = SpeechModel.get(ctx)
        val sb = StringBuilder()
        fun add(json: String) {
            val t = JSONObject(json).optString("text", "").trim()
            if (t.isNotEmpty()) {
                if (sb.isNotEmpty()) sb.append(' ')
                sb.append(t)
            }
        }
        Recognizer(model, 16000f).use { rec ->
            RandomAccessFile(File(wavPath), "r").use { raf ->
                raf.seek(44)   // رد شدن از سرآیند WAV
                val buf = ByteArray(8000)
                while (true) {
                    val n = raf.read(buf)
                    if (n <= 0) break
                    if (rec.acceptWaveForm(buf, n)) add(rec.result)
                }
                add(rec.finalResult)
            }
        }
        return sb.toString()
    }
}
