package com.example.notewidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

object WidgetUpdater {
    /** فقط لیست یادداشت‌ها را دوباره می‌سازد. */
    fun refresh(ctx: Context) {
        val m = AppWidgetManager.getInstance(ctx)
        val ids = m.getAppWidgetIds(ComponentName(ctx, NoteWidgetProvider::class.java))
        m.notifyAppWidgetViewDataChanged(ids, R.id.list)
    }

    /** بعد از تغییر رنگ: کل ویجت (قاب + لیست) دوباره ساخته می‌شود. */
    fun applyTheme(ctx: Context) {
        val m = AppWidgetManager.getInstance(ctx)
        val ids = m.getAppWidgetIds(ComponentName(ctx, NoteWidgetProvider::class.java))
        for (id in ids) m.updateAppWidget(id, NoteWidgetProvider.buildViews(ctx, id))
        m.notifyAppWidgetViewDataChanged(ids, R.id.list)
    }
}

object WidgetGroups {
    const val EXTRA = "group"
    private fun p(ctx: Context) = ctx.getSharedPreferences("widget_groups", Context.MODE_PRIVATE)
    /** ویجت اول گروه ۰ (یادداشت‌های قدیمی)، بقیه گروه جدا. */
    @Synchronized
    fun of(ctx: Context, id: Int): Int {
        val pr = p(ctx)
        if (pr.contains("w$id")) return pr.getInt("w$id", 0)
        val g = if (pr.all.isEmpty()) 0 else id
        pr.edit().putInt("w$id", g).apply()
        return g
    }
    @Synchronized
    fun remove(ctx: Context, id: Int) {
        val g = p(ctx).getInt("w$id", 0)
        p(ctx).edit().remove("w$id").apply()
        if (g != 0) NoteStore.removeGroup(ctx, g)
    }
}

class NoteWidgetProvider : AppWidgetProvider() {

    override fun onDeleted(ctx: Context, ids: IntArray) {
        for (id in ids) WidgetGroups.remove(ctx, id)
    }

    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, buildViews(ctx, id))
    }

    companion object {
        fun buildViews(ctx: Context, widgetId: Int): RemoteViews {
            val group = WidgetGroups.of(ctx, widgetId)
            val t = WidgetThemes.current(ctx)
            val rv = RemoteViews(ctx.packageName, R.layout.widget_notes)

            val svc = Intent(ctx, NoteWidgetService::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                putExtra(WidgetGroups.EXTRA, group)
                data = Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
            }
            rv.setRemoteAdapter(R.id.list, svc)
            rv.setEmptyView(R.id.list, R.id.empty)

            // رنگ‌ها
            rv.setInt(R.id.root, "setBackgroundColor", t.bg)
            rv.setInt(R.id.add_bar, "setBackgroundColor", t.row)
            rv.setTextColor(R.id.add, t.sub)
            rv.setInt(R.id.btn_mic, "setColorFilter", t.text)
            rv.setInt(R.id.thick_line, "setBackgroundColor", t.accent)
            rv.setTextColor(R.id.empty, t.sub)

            // کلیک روی دکمه‌ها و متن هر ردیف (حذف / آلارم / ویرایش / انجام شد)
            // NEW_TASK + CLEAR_TASK: صفحه در تسک جدا باز می‌شود (صفحه‌ی دیگری پشتش نمی‌ماند)
            val newTask = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            val template = PendingIntent.getActivity(
                ctx, widgetId * 4, Intent(ctx, ItemActionActivity::class.java).addFlags(newTask),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            rv.setPendingIntentTemplate(R.id.list, template)

            // کلیک روی «افزودن یادداشت…»
            val add = PendingIntent.getActivity(
                ctx, widgetId * 4 + 1, Intent(ctx, AddNoteActivity::class.java).addFlags(newTask).putExtra(WidgetGroups.EXTRA, group),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.add, add)

            // کلیک روی میکروفون: ضبط یادداشت صوتی
            val mic = PendingIntent.getActivity(
                ctx, widgetId * 4 + 2, Intent(ctx, VoiceNoteActivity::class.java).addFlags(newTask).putExtra(WidgetGroups.EXTRA, group),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.btn_mic, mic)
            return rv
        }
    }
}
