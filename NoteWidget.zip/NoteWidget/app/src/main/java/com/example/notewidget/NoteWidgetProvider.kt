package com.example.notewidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

object WidgetUpdater {
    fun refresh(ctx: Context) {
        val m = AppWidgetManager.getInstance(ctx)
        val ids = m.getAppWidgetIds(ComponentName(ctx, NoteWidgetProvider::class.java))
        m.notifyAppWidgetViewDataChanged(ids, R.id.list)
    }
}

class NoteWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, build(ctx, id))
    }

    private fun build(ctx: Context, widgetId: Int): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_notes)

        val svc = Intent(ctx, NoteWidgetService::class.java).apply {
            putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            data = Uri.parse(toUri(Intent.URI_INTENT_SCHEME))
        }
        rv.setRemoteAdapter(R.id.list, svc)
        rv.setEmptyView(R.id.list, R.id.empty)

        // کلیک روی دکمه‌های هر ردیف (حذف / آلارم)
        val template = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, ItemActionActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
        )
        rv.setPendingIntentTemplate(R.id.list, template)

        // کلیک روی «افزودن یادداشت…»
        val add = PendingIntent.getActivity(
            ctx, 1, Intent(ctx, AddNoteActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.add, add)
        return rv
    }
}
