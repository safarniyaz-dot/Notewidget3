package com.example.notewidget

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

object AlarmActions {
    fun notifId(id: Long): Int = (id % Int.MAX_VALUE).toInt()

    /** رد آلارم: فقط اعلان را می‌بندد. */
    fun dismiss(ctx: Context, id: Long) {
        ctx.getSystemService(NotificationManager::class.java).cancel(notifId(id))
    }

    /** تعویق آلارم به [minutes] دقیقه بعد. */
    fun snooze(ctx: Context, id: Long, minutes: Int) {
        dismiss(ctx, id)
        if (NoteStore.get(ctx, id) == null) return
        val t = System.currentTimeMillis() + minutes * 60_000L
        NoteStore.setAlarm(ctx, id, t)
        AlarmScheduler.schedule(ctx, id, t)
        WidgetUpdater.refresh(ctx)
    }
}

/** دکمه‌های داخل اعلان (۵/۱۰/۱۵ دقیقه). */
class AlarmActionReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val id = intent.getLongExtra("id", 0L)
        val minutes = intent.getIntExtra("minutes", 0)
        if (minutes > 0) AlarmActions.snooze(ctx, id, minutes) else AlarmActions.dismiss(ctx, id)
    }
}
