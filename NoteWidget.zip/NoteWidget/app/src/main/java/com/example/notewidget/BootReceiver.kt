package com.example.notewidget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val now = System.currentTimeMillis()
        NoteStore.all(ctx).filter { it.alarm > now }.forEach {
            AlarmScheduler.schedule(ctx, it.id, it.alarm)
        }
        WidgetUpdater.refresh(ctx)
    }
}
