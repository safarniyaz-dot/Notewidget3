package com.example.notewidget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val now = System.currentTimeMillis()
        NoteStore.all(ctx).forEach {
            if (it.alarm > now) {
                AlarmScheduler.schedule(ctx, it.id, it.alarm)
            } else if (it.repeat != 0) {
                val t = Repeat.next(it.repeat, it.mod, now)
                NoteStore.setAlarmFull(ctx, it.id, t, it.repeat, it.mod)
                AlarmScheduler.schedule(ctx, it.id, t)
            }
        }
        WidgetUpdater.refresh(ctx)
    }
}
