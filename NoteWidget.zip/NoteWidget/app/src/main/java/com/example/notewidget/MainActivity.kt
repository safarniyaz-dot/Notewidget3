package com.example.notewidget

import android.Manifest
import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 96, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "ویجت یادداشت با آلارم شمسی\n\n" +
                    "۱. روی صفحه اصلی گوشی نگه دارید و «ویجت‌ها» را بزنید.\n" +
                    "۲. ویجت «یادداشت» را به صفحه اصلی بکشید.\n" +
                    "۳. روی «افزودن یادداشت…» بزنید و یادداشت بنویسید.\n" +
                    "۴. با آیکن ساعت کنار هر یادداشت، آلارم شمسی تنظیم کنید."
            textSize = 16f
            setLineSpacing(8f, 1f)
        })
        root.addView(Button(this).apply {
            text = "افزودن یادداشت"
            setOnClickListener { startActivity(Intent(this@MainActivity, AddNoteActivity::class.java)) }
        })
        root.addView(Button(this).apply {
            text = "افزودن ویجت به صفحه اصلی"
            setOnClickListener {
                val m = AppWidgetManager.getInstance(this@MainActivity)
                if (m.isRequestPinAppWidgetSupported) {
                    m.requestPinAppWidget(
                        ComponentName(this@MainActivity, NoteWidgetProvider::class.java), null, null
                    )
                } else {
                    Toast.makeText(this@MainActivity, "ویجت را از منوی ویجت‌ها اضافه کنید", Toast.LENGTH_LONG).show()
                }
            }
        })
        setContentView(root)
    }
}
