package com.example.notewidget

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var soundBtn: Button
    private lateinit var colorBtn: Button
    private lateinit var oldBtn: Button
    private lateinit var speechBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(48, 96, 48, 48)
        }

        root.addView(TextView(this).apply {
            text = "ویجت یادداشت با آلارم شمسی\n\n" +
                    "۱. روی صفحه اصلی گوشی نگه دارید و «ویجت‌ها» را بزنید.\n" +
                    "۲. ویجت «taghva.nazm» را به صفحه اصلی بکشید.\n" +
                    "۳. روی «افزودن یادداشت…» بزنید و یادداشت بنویسید.\n" +
                    "۴. برای ویرایش یادداشت، روی متن آن بزنید.\n" +
                    "۵. با آیکن میکروفون بالای ویجت، یادداشت صوتی ضبط کنید (عنوان را هم می‌توانید بنویسید). برای تبدیل خودکار صدا به متن، یک بار «مدل تبدیل صدا به متن» را دانلود کنید.\n" +
                    "۶. با آیکن ساعت کنار هر یادداشت، آلارم شمسی تنظیم کنید؛ برای یادداشت صوتی، همان صدا در آلارم پخش می‌شود."
            textSize = 16f
            setLineSpacing(8f, 1f)
        })

        fun addButton(label: String, onClick: () -> Unit): Button {
            val b = Button(this).apply {
                text = label
                setOnClickListener { onClick() }
            }
            root.addView(b)
            return b
        }

        addButton("افزودن یادداشت") {
            startActivity(Intent(this, AddNoteActivity::class.java))
        }

        addButton("ضبط یادداشت صوتی") {
            startActivity(Intent(this, VoiceNoteActivity::class.java))
        }

        addButton("افزودن ویجت به صفحه اصلی") {
            val m = AppWidgetManager.getInstance(this)
            if (m.isRequestPinAppWidgetSupported) {
                m.requestPinAppWidget(ComponentName(this, NoteWidgetProvider::class.java), null, null)
            } else {
                Toast.makeText(this, "ویجت را از منوی ویجت‌ها اضافه کنید", Toast.LENGTH_LONG).show()
            }
        }

        // رنگ ویجت
        colorBtn = addButton("") { pickColor() }
        refreshColorLabel()

        // انتخاب صدای آلارم
        soundBtn = addButton("") { pickSound() }
        refreshSoundLabel()

        // مدل آفلاین تبدیل صدا به متن
        speechBtn = addButton("") { downloadSpeechModel() }
        refreshSpeechLabel()

        addButton("تست آلارم (۱۰ ثانیه دیگر)") { testAlarm() }

        // فقط وقتی نسخه‌ی قدیمی برنامه (با شناسه‌ی دیگر) روی گوشی مانده باشد دیده می‌شود
        oldBtn = addButton("حذف نسخه قدیمی برنامه (تکراری)") {
            startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:$OLD_PACKAGE")))
        }
        oldBtn.visibility = View.GONE

        addButton("تنظیمات اعلان (برای آلارم)") {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                    .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        }

        addButton("نمایش آلارم روی صفحه (روشن کنید)") {
            try {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                Toast.makeText(this, "این تنظیم در گوشی شما پیدا نشد", Toast.LENGTH_LONG).show()
            }
        }

        if (Build.VERSION.SDK_INT >= 34) {
            addButton("اجازه آلارم تمام‌صفحه") {
                try {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                            Uri.parse("package:$packageName")
                        )
                    )
                } catch (e: Exception) {
                    Toast.makeText(this, "این تنظیم در گوشی شما پیدا نشد", Toast.LENGTH_LONG).show()
                }
            }
        }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        oldBtn.visibility = if (isInstalled(OLD_PACKAGE)) View.VISIBLE else View.GONE
    }

    private fun isInstalled(pkg: String): Boolean = try {
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    // ---------- تبدیل صدا به متن (آفلاین) ----------

    private fun refreshSpeechLabel() {
        speechBtn.text = if (SpeechModel.isReady(this))
            "تبدیل صدا به متن: آماده (آفلاین) ✓"
        else
            "دانلود مدل تبدیل صدا به متن فارسی (حدود ۵۳ مگابایت، یک بار)"
    }

    private fun downloadSpeechModel() {
        if (SpeechModel.isReady(this)) {
            Toast.makeText(this, "مدل آماده است. بعد از ضبط، صدا خودکار به متن تبدیل می‌شود.", Toast.LENGTH_LONG).show()
            return
        }
        val tv = TextView(this).apply {
            text = "در حال دانلود… ۰٪\nلطفاً اینترنت را قطع نکنید."
            setPadding(48, 32, 48, 16)
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("دانلود مدل گفتار")
            .setView(tv)
            .setCancelable(false)
            .create()
        dlg.show()
        Thread {
            var err: String? = null
            try {
                SpeechModel.download(applicationContext) { p ->
                    runOnUiThread {
                        tv.text = "در حال " + (if (p >= 90) "آماده‌سازی" else "دانلود") + "… " +
                                Jalali.digits(p.toString()) + "٪\nلطفاً اینترنت را قطع نکنید."
                    }
                }
            } catch (e: Throwable) {
                err = e.message ?: e.javaClass.simpleName
            }
            runOnUiThread {
                dlg.dismiss()
                refreshSpeechLabel()
                if (err == null) {
                    Toast.makeText(this, "مدل آماده شد. حالا یادداشت صوتی خودکار به متن تبدیل می‌شود.", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "دانلود ناموفق بود: $err", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ---------- رنگ ویجت ----------

    private fun refreshColorLabel() {
        colorBtn.text = "رنگ ویجت: " + WidgetThemes.label(this)
    }

    private fun applyColor(color: Int) {
        WidgetThemes.save(this, color)
        WidgetUpdater.applyTheme(this)
        refreshColorLabel()
    }

    private fun pickColor() {
        val names = WidgetThemes.presets.map { it.first }.toMutableList()
        names.add("رنگ دلخواه (کد HEX)…")
        AlertDialog.Builder(this)
            .setTitle("رنگ ویجت")
            .setItems(names.toTypedArray()) { _, which ->
                if (which < WidgetThemes.presets.size) {
                    applyColor(WidgetThemes.presets[which].second)
                } else {
                    askHexColor()
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun askHexColor() {
        val et = EditText(this).apply {
            hint = "مثلاً #1E3A5F"
            inputType = InputType.TYPE_CLASS_TEXT
            setText("#")
            setSelection(1)
            setPadding(48, 32, 48, 32)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("رنگ دلخواه")
            .setMessage("کد رنگ را به صورت #RRGGBB وارد کنید.")
            .setView(et)
            .setPositiveButton("اعمال", null)
            .setNegativeButton("انصراف", null)
            .create()
        dialog.show()
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            try {
                val c = Color.parseColor(et.text.toString().trim())
                applyColor(c)
                dialog.dismiss()
            } catch (e: Exception) {
                Toast.makeText(this, "کد رنگ درست نیست", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ---------- صدای آلارم ----------

    private fun refreshSoundLabel() {
        soundBtn.text = "صدای آلارم: " + SoundPrefs.label(this)
    }

    private fun pickSound() {
        val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
            putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM)
            putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "صدای آلارم")
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
            putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, SoundPrefs.resolve(this@MainActivity))
        }
        startActivityForResult(i, REQ_SOUND)
    }

    /** یک یادداشت آزمایشی می‌سازد و آلارمش را برای ۱۰ ثانیه بعد می‌گذارد. */
    private fun testAlarm() {
        val n = NoteStore.add(this, "تست آلارم")
        val t = System.currentTimeMillis() + 10_000L
        NoteStore.setAlarm(this, n.id, t)
        AlarmScheduler.schedule(this, n.id, t)
        WidgetUpdater.refresh(this)
        Toast.makeText(this, "۱۰ ثانیه دیگر آلارم می‌زند", Toast.LENGTH_SHORT).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SOUND && resultCode == RESULT_OK && data != null) {
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            SoundPrefs.save(this, uri)
            refreshSoundLabel()
        }
    }

    companion object {
        private const val REQ_SOUND = 21
        private const val OLD_PACKAGE = "com.example.notewidget"
    }
}
