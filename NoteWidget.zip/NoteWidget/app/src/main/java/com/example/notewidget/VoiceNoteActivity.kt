package com.example.notewidget

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.io.File

/** ضبط یادداشت صوتی: با زدن میکروفون روی ویجت باز می‌شود، ضبط شروع می‌شود، «توقف و ذخیره» یادداشت را می‌سازد. */
class VoiceNoteActivity : Activity() {

    private var recorder: MediaRecorder? = null
    private var file: File? = null
    private var noteId = 0L
    private var startTime = 0L
    private var dialog: AlertDialog? = null
    private var finished = false
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startFlow()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_MIC) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startFlow()
        } else {
            Toast.makeText(
                this, "برای ضبط صدا مجوز میکروفون لازم است. از تنظیمات برنامه آن را روشن کنید.",
                Toast.LENGTH_LONG
            ).show()
            finished = true
            finish()
        }
    }

    private fun startFlow() {
        noteId = System.currentTimeMillis()
        val dir = File(filesDir, "voice").apply { mkdirs() }
        val f = File(dir, "voice_$noteId.m4a")
        file = f

        try {
            val r: MediaRecorder = if (Build.VERSION.SDK_INT >= 31) {
                MediaRecorder(this)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(64000)
            r.setAudioSamplingRate(44100)
            r.setMaxDuration(MAX_MS)
            r.setOutputFile(f.absolutePath)
            r.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) save()
            }
            r.prepare()
            r.start()
            recorder = r
        } catch (e: Exception) {
            Toast.makeText(this, "ضبط صدا شروع نشد", Toast.LENGTH_LONG).show()
            releaseRecorder()
            f.delete()
            finished = true
            finish()
            return
        }

        startTime = System.currentTimeMillis()

        val d = AlertDialog.Builder(this)
            .setTitle("یادداشت صوتی")
            .setMessage(timerText())
            .setCancelable(false)
            .setPositiveButton("توقف و ذخیره", null)
            .setNegativeButton("انصراف", null)
            .create()
        d.show()
        d.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener { save() }
        d.getButton(DialogInterface.BUTTON_NEGATIVE).setOnClickListener { cancel() }
        dialog = d

        handler.postDelayed(object : Runnable {
            override fun run() {
                if (finished) return
                dialog?.setMessage(timerText())
                handler.postDelayed(this, 500)
            }
        }, 500)
    }

    private fun timerText(): String {
        val sec = ((System.currentTimeMillis() - startTime) / 1000).toInt()
        return "● در حال ضبط…  " + Jalali.digits("%02d:%02d".format(sec / 60, sec % 60))
    }

    /** ضبط را متوقف می‌کند؛ اگر فایل سالم بسته شود true برمی‌گرداند. */
    private fun releaseRecorder(): Boolean {
        val r = recorder ?: return false
        recorder = null
        var ok = true
        try {
            r.stop()
        } catch (e: RuntimeException) {
            ok = false      // ضبط خیلی کوتاه بوده
        }
        try { r.release() } catch (e: Exception) { /* مهم نیست */ }
        return ok
    }

    private fun save() {
        if (finished) return
        finished = true
        handler.removeCallbacksAndMessages(null)

        val longEnough = System.currentTimeMillis() - startTime >= 700
        val ok = releaseRecorder()
        val f = file
        if (ok && longEnough && f != null && f.exists() && f.length() > 0) {
            NoteStore.add(this, "🎤 یادداشت صوتی", f.absolutePath, noteId)
            WidgetUpdater.refresh(this)
        } else {
            f?.delete()
            Toast.makeText(this, "ضبط خیلی کوتاه بود", Toast.LENGTH_SHORT).show()
        }
        dialog?.dismiss()
        finish()
    }

    private fun cancel() {
        if (finished) return
        finished = true
        handler.removeCallbacksAndMessages(null)
        releaseRecorder()
        file?.delete()
        dialog?.dismiss()
        finish()
    }

    /** اگر وسط ضبط از برنامه خارج شدند (Home)، آنچه ضبط شده ذخیره می‌شود. */
    override fun onStop() {
        super.onStop()
        if (recorder != null && !finished) save()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (!finished) {
            finished = true
            releaseRecorder()
            file?.delete()
        }
        super.onDestroy()
    }

    companion object {
        private const val REQ_MIC = 31
        private const val MAX_MS = 5 * 60 * 1000
    }
}
