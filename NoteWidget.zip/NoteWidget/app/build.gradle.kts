plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.notewidget"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.taghva.nazm"
        minSdk = 26
        targetSdk = 34
        // شماره‌ی نسخه از زمان ساخت (به دقیقه) گرفته می‌شود تا هر ساخت جدید همیشه از نسخه‌ی نصب‌شده بالاتر باشد
        // و گوشی آن را «آپدیت» بشناسد (نه کاهش نسخه).
        versionCode = (System.currentTimeMillis() / 60000L).toInt()
        versionName = "1.7.1"

        // فقط معماری‌های رایج گوشی‌ها (حجم برنامه کمتر می‌شود)
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
        // مدل زبانی (llama.cpp) فقط برای گوشی‌های ۶۴ بیتی ساخته می‌شود؛ روی ۳۲ بیتی برنامه بقیه‌ی کارها را بدون آن انجام می‌دهد
        externalNativeBuild {
            cmake {
                abiFilters += listOf("arm64-v8a")
                // حتی در ساخت debug، کتابخانه‌های بومی بهینه و بدون اطلاعات اشکال‌زدایی ساخته شوند (حجم بسیار کمتر)
                arguments += listOf("-DANDROID_STL=c++_shared", "-DCMAKE_BUILD_TYPE=Release")
                cFlags += listOf("-O3", "-g0")
                cppFlags += listOf("-O3", "-g0")
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    // کتابخانه‌های بومی باید روی دیسک استخراج شوند تا llama.cpp بتواند نسخه‌ی مناسب CPU را بارگذاری کند
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }

    // کلید ثابت برای امضای APK: همه‌ی ساخت‌ها یک امضا دارند و نصب روی نسخه قبلی خطا نمی‌دهد
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storeType = "pkcs12"
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
            enableV1Signing = true
            enableV2Signing = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // تبدیل گفتار به متن آفلاین (Vosk)
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.+")
}
