plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.notewidget"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.taghva.nazm"
        minSdk = 26
        targetSdk = 34
        versionCode = 20
        versionName = "2.0"
    }

    // کلید ثابت برای امضای APK: همه‌ی ساخت‌ها یک امضا دارند و نصب روی نسخه قبلی خطا نمی‌دهد
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storeType = "pkcs12"
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // تبدیل گفتار به متن آفلاین (Vosk)
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.+")
}
