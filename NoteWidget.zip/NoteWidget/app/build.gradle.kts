plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.notewidget"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.taghva.nazm"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.3"
    }

    // کلید ثابت برای امضای APK: همه‌ی ساخت‌ها یک امضا دارند و نصب روی نسخه قبلی خطا نمی‌دهد
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storeType = "pkcs12"
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
